using Microsoft.Mxc.Sdk;
using Microsoft.Mxc.Sdk.V1;
// Spawn a 90 s sleep with egress allowed (slirp provider), then force full GCs; report how it ended.
var gc = args.Length > 1 && args[1] == "gc";
var req = new ContainerRequest("/bin/sh -c 'sleep 300; echo SLEEP_DONE'") {
  Filesystem = new FilesystemPolicy { ReadwritePaths = { args[0] } },
  Network = new NetworkPolicy { Egress = new NetworkEgressPolicy { Default = NetworkAction.Allow } },
  WorkingDirectory = args[0], InheritDefaultEnvironment = true, TimeoutMs = 360000 };
using var p = await MxcContainer.SpawnAsync(req);
req = null;
p.StandardInput?.Close();
var o = p.StandardOutput!.CopyToAsync(Console.OpenStandardOutput());
var start = DateTime.UtcNow;
var stress = gc ? Task.Run(async () => { while (true) { GC.Collect(); GC.WaitForPendingFinalizers(); GC.Collect(); await Task.Delay(500); } }) : Task.CompletedTask;
var r = await p.WaitAsync();
await o;
Console.WriteLine($"gc={gc} exit={r.ExitCode} timedout={r.TimedOut} after={(DateTime.UtcNow - start).TotalSeconds:F0}s");
