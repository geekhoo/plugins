using System.Reflection;
var asm = typeof(Microsoft.Mxc.Sdk.V1.MxcContainer).Assembly;
foreach (var t in asm.GetTypes().Where(t => t.IsPublic && (t.Name.Contains("WaitResult") || t.Name.Contains("ExitReason") || t.Name.Contains("Outcome") || t.Name == "ExecutionMetadata" || t.Name.Contains("Termination") || t.Name.Contains("Exit"))))
{
    Console.WriteLine($"type {t.FullName}");
    foreach (var p in t.GetProperties()) Console.WriteLine($"  prop {p.PropertyType.Name} {p.Name}");
    if (t.IsEnum) Console.WriteLine("  values " + string.Join(",", Enum.GetNames(t)));
}
