using System;
using System.Runtime.InteropServices;
using Microsoft.Mxc.Sdk.Native;

namespace Microsoft.Mxc.Sdk;

internal sealed class MxcWriteStreamHandle : SafeHandle
{
	public override bool IsInvalid => handle == IntPtr.Zero;

	internal unsafe MxcWriteStream* Ptr => (MxcWriteStream*)handle;

	private MxcWriteStreamHandle()
		: base(IntPtr.Zero, ownsHandle: true)
	{
	}

	internal unsafe static MxcWriteStreamHandle FromRaw(MxcWriteStream* ptr)
	{
		MxcWriteStreamHandle mxcWriteStreamHandle = new MxcWriteStreamHandle();
		mxcWriteStreamHandle.SetHandle((nint)ptr);
		return mxcWriteStreamHandle;
	}

	protected unsafe override bool ReleaseHandle()
	{
		NativeMethods.mxc_write_stream_free((MxcWriteStream*)handle);
		return true;
	}
}
