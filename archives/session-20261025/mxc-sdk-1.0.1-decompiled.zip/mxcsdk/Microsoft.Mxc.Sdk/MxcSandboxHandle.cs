using System;
using System.Runtime.InteropServices;
using Microsoft.Mxc.Sdk.Native;

namespace Microsoft.Mxc.Sdk;

internal sealed class MxcSandboxHandle : SafeHandle
{
	public override bool IsInvalid => handle == IntPtr.Zero;

	internal unsafe MxcSandbox* Ptr => (MxcSandbox*)handle;

	private MxcSandboxHandle()
		: base(IntPtr.Zero, ownsHandle: true)
	{
	}

	internal unsafe static MxcSandboxHandle FromRaw(MxcSandbox* ptr)
	{
		MxcSandboxHandle mxcSandboxHandle = new MxcSandboxHandle();
		mxcSandboxHandle.SetHandle((nint)ptr);
		return mxcSandboxHandle;
	}

	protected unsafe override bool ReleaseHandle()
	{
		NativeMethods.mxc_sandbox_free((MxcSandbox*)handle);
		return true;
	}
}
