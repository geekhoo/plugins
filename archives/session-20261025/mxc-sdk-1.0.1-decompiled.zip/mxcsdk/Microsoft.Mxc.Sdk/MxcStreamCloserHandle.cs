using System;
using System.Runtime.InteropServices;
using Microsoft.Mxc.Sdk.Native;

namespace Microsoft.Mxc.Sdk;

internal sealed class MxcStreamCloserHandle : SafeHandle
{
	public override bool IsInvalid => handle == IntPtr.Zero;

	internal unsafe MxcStreamCloser* Ptr => (MxcStreamCloser*)handle;

	private MxcStreamCloserHandle()
		: base(IntPtr.Zero, ownsHandle: true)
	{
	}

	internal unsafe static MxcStreamCloserHandle FromRaw(MxcStreamCloser* ptr)
	{
		MxcStreamCloserHandle mxcStreamCloserHandle = new MxcStreamCloserHandle();
		mxcStreamCloserHandle.SetHandle((nint)ptr);
		return mxcStreamCloserHandle;
	}

	protected unsafe override bool ReleaseHandle()
	{
		NativeMethods.mxc_stream_closer_free((MxcStreamCloser*)handle);
		return true;
	}
}
