using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Json.Serialization.Metadata;
using Microsoft.Mxc.Sdk.Generated;
using Microsoft.Mxc.Sdk.V1;

namespace Microsoft.Mxc.Sdk;

[JsonSourceGenerationOptions(PropertyNamingPolicy = JsonKnownNamingPolicy.CamelCase, DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull)]
[JsonSerializable(typeof(OneShotRequest))]
[JsonSerializable(typeof(ContainerRequest))]
[JsonSerializable(typeof(ProvisionRequest))]
[JsonSerializable(typeof(Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest))]
[JsonSerializable(typeof(Microsoft.Mxc.Sdk.V1.WslcProvisionRequest))]
[JsonSerializable(typeof(ExecutionRequest))]
[JsonSerializable(typeof(ProcessNetworkPolicy))]
[JsonSerializable(typeof(RunOptions))]
[JsonSerializable(typeof(SpawnOptions))]
[JsonSerializable(typeof(SpawnWithPtyOptions))]
[JsonSerializable(typeof(ProvisionOptions))]
[JsonSerializable(typeof(StartOptions))]
[JsonSerializable(typeof(StopOptions))]
[JsonSerializable(typeof(DeprovisionOptions))]
[JsonSerializable(typeof(SpawnInContainerOptions))]
[JsonSerializable(typeof(RunInContainerOptions))]
[JsonSerializable(typeof(SpawnInContainerWithPtyOptions))]
[JsonSerializable(typeof(MxcPtySize))]
[JsonSerializable(typeof(Containment))]
[JsonSerializable(typeof(Containment.Process), TypeInfoPropertyName = "SdkContainmentProcess")]
[JsonSerializable(typeof(Containment.ProcessContainer), TypeInfoPropertyName = "SdkContainmentProcessContainer")]
[JsonSerializable(typeof(Containment.Seatbelt), TypeInfoPropertyName = "SdkContainmentSeatbelt")]
[JsonSerializable(typeof(Containment.Lxc), TypeInfoPropertyName = "SdkContainmentLxc")]
[JsonSerializable(typeof(Containment.Bubblewrap), TypeInfoPropertyName = "SdkContainmentBubblewrap")]
[JsonSerializable(typeof(Containment.Wslc), TypeInfoPropertyName = "SdkContainmentWslc")]
[JsonSerializable(typeof(Containment.IsolationSession), TypeInfoPropertyName = "SdkContainmentIsolationSession")]
[JsonSerializable(typeof(ProcessContainerUiPolicy))]
[JsonSerializable(typeof(ProcessContainerFilesystemPolicy))]
[JsonSerializable(typeof(ProcessContainerNetworkPolicy))]
[JsonSerializable(typeof(WslcPortMapping))]
[JsonSerializable(typeof(FilesystemPolicy))]
[JsonSerializable(typeof(NetworkPolicy))]
[JsonSerializable(typeof(UiPolicy))]
[JsonSerializable(typeof(CaptureDenialsPolicy))]
[JsonSerializable(typeof(TelemetryConfig))]
[JsonSerializable(typeof(NetworkEgressPolicy))]
[JsonSerializable(typeof(NetworkIngressPolicy))]
[JsonSerializable(typeof(NetworkRuntimeConfig))]
[JsonSerializable(typeof(NetworkRulePolicy))]
[JsonSerializable(typeof(NetworkPeerPolicy))]
[JsonSerializable(typeof(NetworkPortPolicy))]
[JsonSerializable(typeof(NativeAvailableBackend[]))]
[JsonSerializable(typeof(NativePlatformSupport))]
[JsonSerializable(typeof(NativeProbeOutput))]
[JsonSerializable(typeof(NativeProbeFacts))]
[JsonSerializable(typeof(ExecutionMetadata))]
[JsonSerializable(typeof(CaptureDenialsResult))]
[JsonSerializable(typeof(CaptureDenialsError))]
[JsonSerializable(typeof(IsolationSessionProvisionMetadata))]
[JsonSerializable(typeof(ProvisionMetadata))]
[JsonSerializable(typeof(ValidationResult))]
[JsonSerializable(typeof(LifecycleResult))]
[JsonSerializable(typeof(ProvisionResult))]
[JsonSerializable(typeof(ContainerId))]
[JsonSerializable(typeof(string[]))]
[JsonSerializable(typeof(List<string>))]
[JsonSerializable(typeof(Dictionary<string, string>))]
[JsonSerializable(typeof(bool))]
[JsonSerializable(typeof(bool?))]
[GeneratedCode("System.Text.Json.SourceGeneration", "8.0.15.405")]
internal sealed class MxcJsonContext : JsonSerializerContext, IJsonTypeInfoResolver
{
	private JsonTypeInfo<bool>? _Boolean;

	private JsonTypeInfo<bool?>? _NullableBoolean;

	private JsonTypeInfo<CaptureDenials>? _CaptureDenials;

	private JsonTypeInfo<Fallback>? _Fallback;

	private JsonTypeInfo<Filesystem>? _Filesystem;

	private JsonTypeInfo<Lifecycle>? _Lifecycle;

	private JsonTypeInfo<Lxc>? _Lxc;

	private JsonTypeInfo<Network>? _Network;

	private JsonTypeInfo<NetworkEgress>? _NetworkEgress;

	private JsonTypeInfo<NetworkIngress>? _NetworkIngress;

	private JsonTypeInfo<NetworkPeer>? _NetworkPeer;

	private JsonTypeInfo<NetworkPort>? _NetworkPort;

	private JsonTypeInfo<NetworkRule>? _NetworkRule;

	private JsonTypeInfo<OneShotRequest>? _OneShotRequest;

	private JsonTypeInfo<OneShotWslc>? _OneShotWslc;

	private JsonTypeInfo<PortMapping>? _PortMapping;

	private JsonTypeInfo<Process>? _Process;

	private JsonTypeInfo<ProcessContainer>? _ProcessContainer;

	private JsonTypeInfo<ProcessContainerFilesystem>? _ProcessContainerFilesystem;

	private JsonTypeInfo<ProcessContainerNetwork>? _ProcessContainerNetwork;

	private JsonTypeInfo<ProcessContainerUi>? _ProcessContainerUi;

	private JsonTypeInfo<RuntimeConfig>? _RuntimeConfig;

	private JsonTypeInfo<Seatbelt>? _Seatbelt;

	private JsonTypeInfo<Telemetry>? _Telemetry;

	private JsonTypeInfo<Ui>? _Ui;

	private JsonTypeInfo<CaptureDenialsError>? _CaptureDenialsError;

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.CaptureDenialsMode>? _CaptureDenialsMode;

	private JsonTypeInfo<CaptureDenialsPolicy>? _CaptureDenialsPolicy;

	private JsonTypeInfo<CaptureDenialsResult>? _CaptureDenialsResult;

	private JsonTypeInfo<ClipboardPolicy>? _ClipboardPolicy;

	private JsonTypeInfo<ContainerId>? _ContainerId;

	private JsonTypeInfo<ContainerRequest>? _ContainerRequest;

	private JsonTypeInfo<Containment>? _Containment;

	private JsonTypeInfo<Containment.Bubblewrap>? _SdkContainmentBubblewrap;

	private JsonTypeInfo<Containment.IsolationSession>? _SdkContainmentIsolationSession;

	private JsonTypeInfo<Containment.Lxc>? _SdkContainmentLxc;

	private JsonTypeInfo<Containment.Process>? _SdkContainmentProcess;

	private JsonTypeInfo<Containment.ProcessContainer>? _SdkContainmentProcessContainer;

	private JsonTypeInfo<Containment.Seatbelt>? _SdkContainmentSeatbelt;

	private JsonTypeInfo<Containment.Wslc>? _SdkContainmentWslc;

	private JsonTypeInfo<DeprovisionOptions>? _DeprovisionOptions;

	private JsonTypeInfo<ExecutionMetadata>? _ExecutionMetadata;

	private JsonTypeInfo<ExecutionRequest>? _ExecutionRequest;

	private JsonTypeInfo<FilesystemPolicy>? _FilesystemPolicy;

	private JsonTypeInfo<IsolationSessionProvisionMetadata>? _IsolationSessionProvisionMetadata;

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest>? _IsolationSessionProvisionRequest;

	private JsonTypeInfo<LifecycleResult>? _LifecycleResult;

	private JsonTypeInfo<MxcPtySize>? _MxcPtySize;

	private JsonTypeInfo<MxcPtySize?>? _NullableMxcPtySize;

	private JsonTypeInfo<NativeAvailableBackend>? _NativeAvailableBackend;

	private JsonTypeInfo<NativeAvailableBackend[]>? _NativeAvailableBackendArray;

	private JsonTypeInfo<NativePlatformSupport>? _NativePlatformSupport;

	private JsonTypeInfo<NativeProbeFacts>? _NativeProbeFacts;

	private JsonTypeInfo<NativeProbeOutput>? _NativeProbeOutput;

	private JsonTypeInfo<NativeUiCapabilitySupport>? _NativeUiCapabilitySupport;

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkAction>? _NetworkAction;

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkAction?>? _NullableNetworkAction;

	private JsonTypeInfo<NetworkEgressPolicy>? _NetworkEgressPolicy;

	private JsonTypeInfo<NetworkIngressPolicy>? _NetworkIngressPolicy;

	private JsonTypeInfo<NetworkPeerPolicy>? _NetworkPeerPolicy;

	private JsonTypeInfo<NetworkPolicy>? _NetworkPolicy;

	private JsonTypeInfo<NetworkPortPolicy>? _NetworkPortPolicy;

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkProtocol>? _NetworkProtocol;

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkProtocol?>? _NullableNetworkProtocol;

	private JsonTypeInfo<NetworkRulePolicy>? _NetworkRulePolicy;

	private JsonTypeInfo<NetworkRuntimeConfig>? _NetworkRuntimeConfig;

	private JsonTypeInfo<ProcessContainerFilesystemPolicy>? _ProcessContainerFilesystemPolicy;

	private JsonTypeInfo<ProcessContainerNetworkPolicy>? _ProcessContainerNetworkPolicy;

	private JsonTypeInfo<ProcessContainerSystemSettings>? _ProcessContainerSystemSettings;

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation>? _ProcessContainerUiIsolation;

	private JsonTypeInfo<ProcessContainerUiPolicy>? _ProcessContainerUiPolicy;

	private JsonTypeInfo<ProcessNetworkPolicy>? _ProcessNetworkPolicy;

	private JsonTypeInfo<ProvisionMetadata>? _ProvisionMetadata;

	private JsonTypeInfo<ProvisionOptions>? _ProvisionOptions;

	private JsonTypeInfo<ProvisionRequest>? _ProvisionRequest;

	private JsonTypeInfo<ProvisionResult>? _ProvisionResult;

	private JsonTypeInfo<RunInContainerOptions>? _RunInContainerOptions;

	private JsonTypeInfo<RunOptions>? _RunOptions;

	private JsonTypeInfo<SpawnInContainerOptions>? _SpawnInContainerOptions;

	private JsonTypeInfo<SpawnInContainerWithPtyOptions>? _SpawnInContainerWithPtyOptions;

	private JsonTypeInfo<SpawnOptions>? _SpawnOptions;

	private JsonTypeInfo<SpawnWithPtyOptions>? _SpawnWithPtyOptions;

	private JsonTypeInfo<StartOptions>? _StartOptions;

	private JsonTypeInfo<StopOptions>? _StopOptions;

	private JsonTypeInfo<TelemetryConfig>? _TelemetryConfig;

	private JsonTypeInfo<UiPolicy>? _UiPolicy;

	private JsonTypeInfo<ValidationResult>? _ValidationResult;

	private JsonTypeInfo<WslcPortMapping>? _WslcPortMapping;

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.WslcProvisionRequest>? _WslcProvisionRequest;

	private JsonTypeInfo<Dictionary<string, string>>? _DictionaryStringString;

	private JsonTypeInfo<List<NetworkPeer>>? _ListNetworkPeer;

	private JsonTypeInfo<List<NetworkPort>>? _ListNetworkPort;

	private JsonTypeInfo<List<NetworkRule>>? _ListNetworkRule;

	private JsonTypeInfo<List<PortMapping>>? _ListPortMapping;

	private JsonTypeInfo<List<NetworkPeerPolicy>>? _ListNetworkPeerPolicy;

	private JsonTypeInfo<List<NetworkPortPolicy>>? _ListNetworkPortPolicy;

	private JsonTypeInfo<List<NetworkRulePolicy>>? _ListNetworkRulePolicy;

	private JsonTypeInfo<List<WslcPortMapping>>? _ListWslcPortMapping;

	private JsonTypeInfo<List<string>>? _ListString;

	private JsonTypeInfo<int>? _Int32;

	private JsonTypeInfo<object>? _Object;

	private JsonTypeInfo<string>? _String;

	private JsonTypeInfo<string[]>? _StringArray;

	private JsonTypeInfo<uint>? _UInt32;

	private JsonTypeInfo<uint?>? _NullableUInt32;

	private JsonTypeInfo<ulong>? _UInt64;

	private JsonTypeInfo<ulong?>? _NullableUInt64;

	private JsonTypeInfo<ushort>? _UInt16;

	private JsonTypeInfo<ushort?>? _NullableUInt16;

	private static readonly JsonSerializerOptions s_defaultOptions = new JsonSerializerOptions
	{
		DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
		PropertyNamingPolicy = JsonNamingPolicy.CamelCase
	};

	private static readonly JsonEncodedText PropName_mode = JsonEncodedText.Encode("mode");

	private static readonly JsonEncodedText PropName_outputPath = JsonEncodedText.Encode("outputPath");

	private static readonly JsonEncodedText PropName_retainEtl = JsonEncodedText.Encode("retainEtl");

	private static readonly JsonEncodedText PropName_allowDaclMutation = JsonEncodedText.Encode("allowDaclMutation");

	private static readonly JsonEncodedText PropName_deniedPaths = JsonEncodedText.Encode("deniedPaths");

	private static readonly JsonEncodedText PropName_readonlyPaths = JsonEncodedText.Encode("readonlyPaths");

	private static readonly JsonEncodedText PropName_readwritePaths = JsonEncodedText.Encode("readwritePaths");

	private static readonly JsonEncodedText PropName_destroyOnExit = JsonEncodedText.Encode("destroyOnExit");

	private static readonly JsonEncodedText PropName_preservePolicy = JsonEncodedText.Encode("preservePolicy");

	private static readonly JsonEncodedText PropName_distribution = JsonEncodedText.Encode("distribution");

	private static readonly JsonEncodedText PropName_release = JsonEncodedText.Encode("release");

	private static readonly JsonEncodedText PropName_egress = JsonEncodedText.Encode("egress");

	private static readonly JsonEncodedText PropName_ingress = JsonEncodedText.Encode("ingress");

	private static readonly JsonEncodedText PropName_allow = JsonEncodedText.Encode("allow");

	private static readonly JsonEncodedText PropName_default = JsonEncodedText.Encode("default");

	private static readonly JsonEncodedText PropName_deny = JsonEncodedText.Encode("deny");

	private static readonly JsonEncodedText PropName_hostLoopback = JsonEncodedText.Encode("hostLoopback");

	private static readonly JsonEncodedText PropName_cidr = JsonEncodedText.Encode("cidr");

	private static readonly JsonEncodedText PropName_except = JsonEncodedText.Encode("except");

	private static readonly JsonEncodedText PropName_endPort = JsonEncodedText.Encode("endPort");

	private static readonly JsonEncodedText PropName_port = JsonEncodedText.Encode("port");

	private static readonly JsonEncodedText PropName_protocol = JsonEncodedText.Encode("protocol");

	private static readonly JsonEncodedText PropName_ports = JsonEncodedText.Encode("ports");

	private static readonly JsonEncodedText PropName_to = JsonEncodedText.Encode("to");

	private static readonly JsonEncodedText PropName_cpuCount = JsonEncodedText.Encode("cpuCount");

	private static readonly JsonEncodedText PropName_gpu = JsonEncodedText.Encode("gpu");

	private static readonly JsonEncodedText PropName_image = JsonEncodedText.Encode("image");

	private static readonly JsonEncodedText PropName_imageTarPath = JsonEncodedText.Encode("imageTarPath");

	private static readonly JsonEncodedText PropName_memoryMb = JsonEncodedText.Encode("memoryMb");

	private static readonly JsonEncodedText PropName_portMappings = JsonEncodedText.Encode("portMappings");

	private static readonly JsonEncodedText PropName_storagePath = JsonEncodedText.Encode("storagePath");

	private static readonly JsonEncodedText PropName_targetOs = JsonEncodedText.Encode("targetOs");

	private static readonly JsonEncodedText PropName_containerPort = JsonEncodedText.Encode("containerPort");

	private static readonly JsonEncodedText PropName_windowsPort = JsonEncodedText.Encode("windowsPort");

	private static readonly JsonEncodedText PropName_commandLine = JsonEncodedText.Encode("commandLine");

	private static readonly JsonEncodedText PropName_cwd = JsonEncodedText.Encode("cwd");

	private static readonly JsonEncodedText PropName_env = JsonEncodedText.Encode("env");

	private static readonly JsonEncodedText PropName_inheritDefaultEnv = JsonEncodedText.Encode("inheritDefaultEnv");

	private static readonly JsonEncodedText PropName_timeout = JsonEncodedText.Encode("timeout");

	private static readonly JsonEncodedText PropName_capabilities = JsonEncodedText.Encode("capabilities");

	private static readonly JsonEncodedText PropName_captureDenials = JsonEncodedText.Encode("captureDenials");

	private static readonly JsonEncodedText PropName_filesystem = JsonEncodedText.Encode("filesystem");

	private static readonly JsonEncodedText PropName_learningMode = JsonEncodedText.Encode("learningMode");

	private static readonly JsonEncodedText PropName_leastPrivilege = JsonEncodedText.Encode("leastPrivilege");

	private static readonly JsonEncodedText PropName_network = JsonEncodedText.Encode("network");

	private static readonly JsonEncodedText PropName_ui = JsonEncodedText.Encode("ui");

	private static readonly JsonEncodedText PropName_enumeratePaths = JsonEncodedText.Encode("enumeratePaths");

	private static readonly JsonEncodedText PropName_allowedProxyPeer = JsonEncodedText.Encode("allowedProxyPeer");

	private static readonly JsonEncodedText PropName_desktopSystemControl = JsonEncodedText.Encode("desktopSystemControl");

	private static readonly JsonEncodedText PropName_ime = JsonEncodedText.Encode("ime");

	private static readonly JsonEncodedText PropName_isolation = JsonEncodedText.Encode("isolation");

	private static readonly JsonEncodedText PropName_systemSettings = JsonEncodedText.Encode("systemSettings");

	private static readonly JsonEncodedText PropName_networkProxy = JsonEncodedText.Encode("networkProxy");

	private static readonly JsonEncodedText PropName_extraMachLookups = JsonEncodedText.Encode("extraMachLookups");

	private static readonly JsonEncodedText PropName_guiAccess = JsonEncodedText.Encode("guiAccess");

	private static readonly JsonEncodedText PropName_keychainAccess = JsonEncodedText.Encode("keychainAccess");

	private static readonly JsonEncodedText PropName_nestedPty = JsonEncodedText.Encode("nestedPty");

	private static readonly JsonEncodedText PropName_profileOverride = JsonEncodedText.Encode("profileOverride");

	private static readonly JsonEncodedText PropName_enabled = JsonEncodedText.Encode("enabled");

	private static readonly JsonEncodedText PropName_clipboard = JsonEncodedText.Encode("clipboard");

	private static readonly JsonEncodedText PropName_disable = JsonEncodedText.Encode("disable");

	private static readonly JsonEncodedText PropName_injection = JsonEncodedText.Encode("injection");

	private static readonly JsonEncodedText PropName_message = JsonEncodedText.Encode("message");

	private static readonly JsonEncodedText PropName_etlPath = JsonEncodedText.Encode("etlPath");

	private static readonly JsonEncodedText PropName_type = JsonEncodedText.Encode("type");

	private static readonly JsonEncodedText PropName_exitCode = JsonEncodedText.Encode("exitCode");

	private static readonly JsonEncodedText PropName_totalDenials = JsonEncodedText.Encode("totalDenials");

	private static readonly JsonEncodedText PropName_deniedResourcesTruncated = JsonEncodedText.Encode("deniedResourcesTruncated");

	private static readonly JsonEncodedText PropName_value = JsonEncodedText.Encode("value");

	private static readonly JsonEncodedText PropName_command = JsonEncodedText.Encode("command");

	private static readonly JsonEncodedText PropName_timeoutMs = JsonEncodedText.Encode("timeoutMs");

	private static readonly JsonEncodedText PropName_containment = JsonEncodedText.Encode("containment");

	private static readonly JsonEncodedText PropName_containerName = JsonEncodedText.Encode("containerName");

	private static readonly JsonEncodedText PropName_workingDirectory = JsonEncodedText.Encode("workingDirectory");

	private static readonly JsonEncodedText PropName_environment = JsonEncodedText.Encode("environment");

	private static readonly JsonEncodedText PropName_telemetry = JsonEncodedText.Encode("telemetry");

	private static readonly JsonEncodedText PropName_captureDenialsError = JsonEncodedText.Encode("captureDenialsError");

	private static readonly JsonEncodedText PropName_inheritDefaultEnvironment = JsonEncodedText.Encode("inheritDefaultEnvironment");

	private static readonly JsonEncodedText PropName_clearPolicyOnExit = JsonEncodedText.Encode("clearPolicyOnExit");

	private static readonly JsonEncodedText PropName_agentUserName = JsonEncodedText.Encode("agentUserName");

	private static readonly JsonEncodedText PropName_agentUserSid = JsonEncodedText.Encode("agentUserSid");

	private static readonly JsonEncodedText PropName_ephemeralWorkspacePath = JsonEncodedText.Encode("ephemeralWorkspacePath");

	private static readonly JsonEncodedText PropName_appId = JsonEncodedText.Encode("appId");

	private static readonly JsonEncodedText PropName_warnings = JsonEncodedText.Encode("warnings");

	private static readonly JsonEncodedText PropName_rows = JsonEncodedText.Encode("rows");

	private static readonly JsonEncodedText PropName_columns = JsonEncodedText.Encode("columns");

	private static readonly JsonEncodedText PropName_backend = JsonEncodedText.Encode("backend");

	private static readonly JsonEncodedText PropName_tier = JsonEncodedText.Encode("tier");

	private static readonly JsonEncodedText PropName_isSupported = JsonEncodedText.Encode("isSupported");

	private static readonly JsonEncodedText PropName_reason = JsonEncodedText.Encode("reason");

	private static readonly JsonEncodedText PropName_availableMethods = JsonEncodedText.Encode("availableMethods");

	private static readonly JsonEncodedText PropName_baseContainerApiPresent = JsonEncodedText.Encode("baseContainerApiPresent");

	private static readonly JsonEncodedText PropName_nativeCaptureAvailable = JsonEncodedText.Encode("nativeCaptureAvailable");

	private static readonly JsonEncodedText PropName_guardedCaptureAvailable = JsonEncodedText.Encode("guardedCaptureAvailable");

	private static readonly JsonEncodedText PropName_bfscfgPresent = JsonEncodedText.Encode("bfscfgPresent");

	private static readonly JsonEncodedText PropName_bfsCompiledIn = JsonEncodedText.Encode("bfsCompiledIn");

	private static readonly JsonEncodedText PropName_baseContainerSupportsDenyPaths = JsonEncodedText.Encode("baseContainerSupportsDenyPaths");

	private static readonly JsonEncodedText PropName_baseContainerSupportsEnumeratePaths = JsonEncodedText.Encode("baseContainerSupportsEnumeratePaths");

	private static readonly JsonEncodedText PropName_baseContainerSupportsIngressHostLoopbackAllow = JsonEncodedText.Encode("baseContainerSupportsIngressHostLoopbackAllow");

	private static readonly JsonEncodedText PropName_baseContainerSupportsIdentitylessLoopbackProxy = JsonEncodedText.Encode("baseContainerSupportsIdentitylessLoopbackProxy");

	private static readonly JsonEncodedText PropName_isolationSessionAvailable = JsonEncodedText.Encode("isolationSessionAvailable");

	private static readonly JsonEncodedText PropName_hyperlightAvailable = JsonEncodedText.Encode("hyperlightAvailable");

	private static readonly JsonEncodedText PropName_uiCapabilities = JsonEncodedText.Encode("uiCapabilities");

	private static readonly JsonEncodedText PropName_needsDaclAugmentation = JsonEncodedText.Encode("needsDaclAugmentation");

	private static readonly JsonEncodedText PropName_probes = JsonEncodedText.Encode("probes");

	private static readonly JsonEncodedText PropName_error = JsonEncodedText.Encode("error");

	private static readonly JsonEncodedText PropName_canBlockClipboardRead = JsonEncodedText.Encode("canBlockClipboardRead");

	private static readonly JsonEncodedText PropName_canBlockClipboardWrite = JsonEncodedText.Encode("canBlockClipboardWrite");

	private static readonly JsonEncodedText PropName_canBlockInputInjection = JsonEncodedText.Encode("canBlockInputInjection");

	private static readonly JsonEncodedText PropName_canBlockInputMethodChanges = JsonEncodedText.Encode("canBlockInputMethodChanges");

	private static readonly JsonEncodedText PropName_canBlockExternalUiObjects = JsonEncodedText.Encode("canBlockExternalUiObjects");

	private static readonly JsonEncodedText PropName_canBlockGlobalUiNamespace = JsonEncodedText.Encode("canBlockGlobalUiNamespace");

	private static readonly JsonEncodedText PropName_canBlockDesktopSwitching = JsonEncodedText.Encode("canBlockDesktopSwitching");

	private static readonly JsonEncodedText PropName_canBlockLogoffOrShutdown = JsonEncodedText.Encode("canBlockLogoffOrShutdown");

	private static readonly JsonEncodedText PropName_canBlockSystemParameterChanges = JsonEncodedText.Encode("canBlockSystemParameterChanges");

	private static readonly JsonEncodedText PropName_canBlockDisplaySettingsChanges = JsonEncodedText.Encode("canBlockDisplaySettingsChanges");

	private static readonly JsonEncodedText PropName_runtimeConfig = JsonEncodedText.Encode("runtimeConfig");

	private static readonly JsonEncodedText PropName_containerId = JsonEncodedText.Encode("containerId");

	private static readonly JsonEncodedText PropName_metadata = JsonEncodedText.Encode("metadata");

	private static readonly JsonEncodedText PropName_size = JsonEncodedText.Encode("size");

	private static readonly JsonEncodedText PropName_allowInputInjection = JsonEncodedText.Encode("allowInputInjection");

	public JsonTypeInfo<bool> Boolean => _Boolean ?? (_Boolean = (JsonTypeInfo<bool>)Options.GetTypeInfo(typeof(bool)));

	public JsonTypeInfo<bool?> NullableBoolean => _NullableBoolean ?? (_NullableBoolean = (JsonTypeInfo<bool?>)Options.GetTypeInfo(typeof(bool?)));

	public JsonTypeInfo<CaptureDenials> CaptureDenials => _CaptureDenials ?? (_CaptureDenials = (JsonTypeInfo<CaptureDenials>)Options.GetTypeInfo(typeof(CaptureDenials)));

	public JsonTypeInfo<Fallback> Fallback => _Fallback ?? (_Fallback = (JsonTypeInfo<Fallback>)Options.GetTypeInfo(typeof(Fallback)));

	public JsonTypeInfo<Filesystem> Filesystem => _Filesystem ?? (_Filesystem = (JsonTypeInfo<Filesystem>)Options.GetTypeInfo(typeof(Filesystem)));

	public JsonTypeInfo<Lifecycle> Lifecycle => _Lifecycle ?? (_Lifecycle = (JsonTypeInfo<Lifecycle>)Options.GetTypeInfo(typeof(Lifecycle)));

	public JsonTypeInfo<Lxc> Lxc => _Lxc ?? (_Lxc = (JsonTypeInfo<Lxc>)Options.GetTypeInfo(typeof(Lxc)));

	public JsonTypeInfo<Network> Network => _Network ?? (_Network = (JsonTypeInfo<Network>)Options.GetTypeInfo(typeof(Network)));

	public JsonTypeInfo<NetworkEgress> NetworkEgress => _NetworkEgress ?? (_NetworkEgress = (JsonTypeInfo<NetworkEgress>)Options.GetTypeInfo(typeof(NetworkEgress)));

	public JsonTypeInfo<NetworkIngress> NetworkIngress => _NetworkIngress ?? (_NetworkIngress = (JsonTypeInfo<NetworkIngress>)Options.GetTypeInfo(typeof(NetworkIngress)));

	public JsonTypeInfo<NetworkPeer> NetworkPeer => _NetworkPeer ?? (_NetworkPeer = (JsonTypeInfo<NetworkPeer>)Options.GetTypeInfo(typeof(NetworkPeer)));

	public JsonTypeInfo<NetworkPort> NetworkPort => _NetworkPort ?? (_NetworkPort = (JsonTypeInfo<NetworkPort>)Options.GetTypeInfo(typeof(NetworkPort)));

	public JsonTypeInfo<NetworkRule> NetworkRule => _NetworkRule ?? (_NetworkRule = (JsonTypeInfo<NetworkRule>)Options.GetTypeInfo(typeof(NetworkRule)));

	public JsonTypeInfo<OneShotRequest> OneShotRequest => _OneShotRequest ?? (_OneShotRequest = (JsonTypeInfo<OneShotRequest>)Options.GetTypeInfo(typeof(OneShotRequest)));

	public JsonTypeInfo<OneShotWslc> OneShotWslc => _OneShotWslc ?? (_OneShotWslc = (JsonTypeInfo<OneShotWslc>)Options.GetTypeInfo(typeof(OneShotWslc)));

	public JsonTypeInfo<PortMapping> PortMapping => _PortMapping ?? (_PortMapping = (JsonTypeInfo<PortMapping>)Options.GetTypeInfo(typeof(PortMapping)));

	public JsonTypeInfo<Process> Process => _Process ?? (_Process = (JsonTypeInfo<Process>)Options.GetTypeInfo(typeof(Process)));

	public JsonTypeInfo<ProcessContainer> ProcessContainer => _ProcessContainer ?? (_ProcessContainer = (JsonTypeInfo<ProcessContainer>)Options.GetTypeInfo(typeof(ProcessContainer)));

	public JsonTypeInfo<ProcessContainerFilesystem> ProcessContainerFilesystem => _ProcessContainerFilesystem ?? (_ProcessContainerFilesystem = (JsonTypeInfo<ProcessContainerFilesystem>)Options.GetTypeInfo(typeof(ProcessContainerFilesystem)));

	public JsonTypeInfo<ProcessContainerNetwork> ProcessContainerNetwork => _ProcessContainerNetwork ?? (_ProcessContainerNetwork = (JsonTypeInfo<ProcessContainerNetwork>)Options.GetTypeInfo(typeof(ProcessContainerNetwork)));

	public JsonTypeInfo<ProcessContainerUi> ProcessContainerUi => _ProcessContainerUi ?? (_ProcessContainerUi = (JsonTypeInfo<ProcessContainerUi>)Options.GetTypeInfo(typeof(ProcessContainerUi)));

	public JsonTypeInfo<RuntimeConfig> RuntimeConfig => _RuntimeConfig ?? (_RuntimeConfig = (JsonTypeInfo<RuntimeConfig>)Options.GetTypeInfo(typeof(RuntimeConfig)));

	public JsonTypeInfo<Seatbelt> Seatbelt => _Seatbelt ?? (_Seatbelt = (JsonTypeInfo<Seatbelt>)Options.GetTypeInfo(typeof(Seatbelt)));

	public JsonTypeInfo<Telemetry> Telemetry => _Telemetry ?? (_Telemetry = (JsonTypeInfo<Telemetry>)Options.GetTypeInfo(typeof(Telemetry)));

	public JsonTypeInfo<Ui> Ui => _Ui ?? (_Ui = (JsonTypeInfo<Ui>)Options.GetTypeInfo(typeof(Ui)));

	public JsonTypeInfo<CaptureDenialsError> CaptureDenialsError => _CaptureDenialsError ?? (_CaptureDenialsError = (JsonTypeInfo<CaptureDenialsError>)Options.GetTypeInfo(typeof(CaptureDenialsError)));

	public JsonTypeInfo<Microsoft.Mxc.Sdk.V1.CaptureDenialsMode> CaptureDenialsMode => _CaptureDenialsMode ?? (_CaptureDenialsMode = (JsonTypeInfo<Microsoft.Mxc.Sdk.V1.CaptureDenialsMode>)Options.GetTypeInfo(typeof(Microsoft.Mxc.Sdk.V1.CaptureDenialsMode)));

	public JsonTypeInfo<CaptureDenialsPolicy> CaptureDenialsPolicy => _CaptureDenialsPolicy ?? (_CaptureDenialsPolicy = (JsonTypeInfo<CaptureDenialsPolicy>)Options.GetTypeInfo(typeof(CaptureDenialsPolicy)));

	public JsonTypeInfo<CaptureDenialsResult> CaptureDenialsResult => _CaptureDenialsResult ?? (_CaptureDenialsResult = (JsonTypeInfo<CaptureDenialsResult>)Options.GetTypeInfo(typeof(CaptureDenialsResult)));

	public JsonTypeInfo<ClipboardPolicy> ClipboardPolicy => _ClipboardPolicy ?? (_ClipboardPolicy = (JsonTypeInfo<ClipboardPolicy>)Options.GetTypeInfo(typeof(ClipboardPolicy)));

	public JsonTypeInfo<ContainerId> ContainerId => _ContainerId ?? (_ContainerId = (JsonTypeInfo<ContainerId>)Options.GetTypeInfo(typeof(ContainerId)));

	public JsonTypeInfo<ContainerRequest> ContainerRequest => _ContainerRequest ?? (_ContainerRequest = (JsonTypeInfo<ContainerRequest>)Options.GetTypeInfo(typeof(ContainerRequest)));

	public JsonTypeInfo<Containment> Containment => _Containment ?? (_Containment = (JsonTypeInfo<Containment>)Options.GetTypeInfo(typeof(Containment)));

	public JsonTypeInfo<Containment.Bubblewrap> SdkContainmentBubblewrap => _SdkContainmentBubblewrap ?? (_SdkContainmentBubblewrap = (JsonTypeInfo<Containment.Bubblewrap>)Options.GetTypeInfo(typeof(Containment.Bubblewrap)));

	public JsonTypeInfo<Containment.IsolationSession> SdkContainmentIsolationSession => _SdkContainmentIsolationSession ?? (_SdkContainmentIsolationSession = (JsonTypeInfo<Containment.IsolationSession>)Options.GetTypeInfo(typeof(Containment.IsolationSession)));

	public JsonTypeInfo<Containment.Lxc> SdkContainmentLxc => _SdkContainmentLxc ?? (_SdkContainmentLxc = (JsonTypeInfo<Containment.Lxc>)Options.GetTypeInfo(typeof(Containment.Lxc)));

	public JsonTypeInfo<Containment.Process> SdkContainmentProcess => _SdkContainmentProcess ?? (_SdkContainmentProcess = (JsonTypeInfo<Containment.Process>)Options.GetTypeInfo(typeof(Containment.Process)));

	public JsonTypeInfo<Containment.ProcessContainer> SdkContainmentProcessContainer => _SdkContainmentProcessContainer ?? (_SdkContainmentProcessContainer = (JsonTypeInfo<Containment.ProcessContainer>)Options.GetTypeInfo(typeof(Containment.ProcessContainer)));

	public JsonTypeInfo<Containment.Seatbelt> SdkContainmentSeatbelt => _SdkContainmentSeatbelt ?? (_SdkContainmentSeatbelt = (JsonTypeInfo<Containment.Seatbelt>)Options.GetTypeInfo(typeof(Containment.Seatbelt)));

	public JsonTypeInfo<Containment.Wslc> SdkContainmentWslc => _SdkContainmentWslc ?? (_SdkContainmentWslc = (JsonTypeInfo<Containment.Wslc>)Options.GetTypeInfo(typeof(Containment.Wslc)));

	public JsonTypeInfo<DeprovisionOptions> DeprovisionOptions => _DeprovisionOptions ?? (_DeprovisionOptions = (JsonTypeInfo<DeprovisionOptions>)Options.GetTypeInfo(typeof(DeprovisionOptions)));

	public JsonTypeInfo<ExecutionMetadata> ExecutionMetadata => _ExecutionMetadata ?? (_ExecutionMetadata = (JsonTypeInfo<ExecutionMetadata>)Options.GetTypeInfo(typeof(ExecutionMetadata)));

	public JsonTypeInfo<ExecutionRequest> ExecutionRequest => _ExecutionRequest ?? (_ExecutionRequest = (JsonTypeInfo<ExecutionRequest>)Options.GetTypeInfo(typeof(ExecutionRequest)));

	public JsonTypeInfo<FilesystemPolicy> FilesystemPolicy => _FilesystemPolicy ?? (_FilesystemPolicy = (JsonTypeInfo<FilesystemPolicy>)Options.GetTypeInfo(typeof(FilesystemPolicy)));

	public JsonTypeInfo<IsolationSessionProvisionMetadata> IsolationSessionProvisionMetadata => _IsolationSessionProvisionMetadata ?? (_IsolationSessionProvisionMetadata = (JsonTypeInfo<IsolationSessionProvisionMetadata>)Options.GetTypeInfo(typeof(IsolationSessionProvisionMetadata)));

	public JsonTypeInfo<Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest> IsolationSessionProvisionRequest => _IsolationSessionProvisionRequest ?? (_IsolationSessionProvisionRequest = (JsonTypeInfo<Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest>)Options.GetTypeInfo(typeof(Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest)));

	public JsonTypeInfo<LifecycleResult> LifecycleResult => _LifecycleResult ?? (_LifecycleResult = (JsonTypeInfo<LifecycleResult>)Options.GetTypeInfo(typeof(LifecycleResult)));

	public JsonTypeInfo<MxcPtySize> MxcPtySize => _MxcPtySize ?? (_MxcPtySize = (JsonTypeInfo<MxcPtySize>)Options.GetTypeInfo(typeof(MxcPtySize)));

	public JsonTypeInfo<MxcPtySize?> NullableMxcPtySize => _NullableMxcPtySize ?? (_NullableMxcPtySize = (JsonTypeInfo<MxcPtySize?>)Options.GetTypeInfo(typeof(MxcPtySize?)));

	public JsonTypeInfo<NativeAvailableBackend> NativeAvailableBackend => _NativeAvailableBackend ?? (_NativeAvailableBackend = (JsonTypeInfo<NativeAvailableBackend>)Options.GetTypeInfo(typeof(NativeAvailableBackend)));

	public JsonTypeInfo<NativeAvailableBackend[]> NativeAvailableBackendArray => _NativeAvailableBackendArray ?? (_NativeAvailableBackendArray = (JsonTypeInfo<NativeAvailableBackend[]>)Options.GetTypeInfo(typeof(NativeAvailableBackend[])));

	public JsonTypeInfo<NativePlatformSupport> NativePlatformSupport => _NativePlatformSupport ?? (_NativePlatformSupport = (JsonTypeInfo<NativePlatformSupport>)Options.GetTypeInfo(typeof(NativePlatformSupport)));

	public JsonTypeInfo<NativeProbeFacts> NativeProbeFacts => _NativeProbeFacts ?? (_NativeProbeFacts = (JsonTypeInfo<NativeProbeFacts>)Options.GetTypeInfo(typeof(NativeProbeFacts)));

	public JsonTypeInfo<NativeProbeOutput> NativeProbeOutput => _NativeProbeOutput ?? (_NativeProbeOutput = (JsonTypeInfo<NativeProbeOutput>)Options.GetTypeInfo(typeof(NativeProbeOutput)));

	public JsonTypeInfo<NativeUiCapabilitySupport> NativeUiCapabilitySupport => _NativeUiCapabilitySupport ?? (_NativeUiCapabilitySupport = (JsonTypeInfo<NativeUiCapabilitySupport>)Options.GetTypeInfo(typeof(NativeUiCapabilitySupport)));

	public JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkAction> NetworkAction => _NetworkAction ?? (_NetworkAction = (JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkAction>)Options.GetTypeInfo(typeof(Microsoft.Mxc.Sdk.V1.NetworkAction)));

	public JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkAction?> NullableNetworkAction => _NullableNetworkAction ?? (_NullableNetworkAction = (JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkAction?>)Options.GetTypeInfo(typeof(Microsoft.Mxc.Sdk.V1.NetworkAction?)));

	public JsonTypeInfo<NetworkEgressPolicy> NetworkEgressPolicy => _NetworkEgressPolicy ?? (_NetworkEgressPolicy = (JsonTypeInfo<NetworkEgressPolicy>)Options.GetTypeInfo(typeof(NetworkEgressPolicy)));

	public JsonTypeInfo<NetworkIngressPolicy> NetworkIngressPolicy => _NetworkIngressPolicy ?? (_NetworkIngressPolicy = (JsonTypeInfo<NetworkIngressPolicy>)Options.GetTypeInfo(typeof(NetworkIngressPolicy)));

	public JsonTypeInfo<NetworkPeerPolicy> NetworkPeerPolicy => _NetworkPeerPolicy ?? (_NetworkPeerPolicy = (JsonTypeInfo<NetworkPeerPolicy>)Options.GetTypeInfo(typeof(NetworkPeerPolicy)));

	public JsonTypeInfo<NetworkPolicy> NetworkPolicy => _NetworkPolicy ?? (_NetworkPolicy = (JsonTypeInfo<NetworkPolicy>)Options.GetTypeInfo(typeof(NetworkPolicy)));

	public JsonTypeInfo<NetworkPortPolicy> NetworkPortPolicy => _NetworkPortPolicy ?? (_NetworkPortPolicy = (JsonTypeInfo<NetworkPortPolicy>)Options.GetTypeInfo(typeof(NetworkPortPolicy)));

	public JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkProtocol> NetworkProtocol => _NetworkProtocol ?? (_NetworkProtocol = (JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkProtocol>)Options.GetTypeInfo(typeof(Microsoft.Mxc.Sdk.V1.NetworkProtocol)));

	public JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkProtocol?> NullableNetworkProtocol => _NullableNetworkProtocol ?? (_NullableNetworkProtocol = (JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkProtocol?>)Options.GetTypeInfo(typeof(Microsoft.Mxc.Sdk.V1.NetworkProtocol?)));

	public JsonTypeInfo<NetworkRulePolicy> NetworkRulePolicy => _NetworkRulePolicy ?? (_NetworkRulePolicy = (JsonTypeInfo<NetworkRulePolicy>)Options.GetTypeInfo(typeof(NetworkRulePolicy)));

	public JsonTypeInfo<NetworkRuntimeConfig> NetworkRuntimeConfig => _NetworkRuntimeConfig ?? (_NetworkRuntimeConfig = (JsonTypeInfo<NetworkRuntimeConfig>)Options.GetTypeInfo(typeof(NetworkRuntimeConfig)));

	public JsonTypeInfo<ProcessContainerFilesystemPolicy> ProcessContainerFilesystemPolicy => _ProcessContainerFilesystemPolicy ?? (_ProcessContainerFilesystemPolicy = (JsonTypeInfo<ProcessContainerFilesystemPolicy>)Options.GetTypeInfo(typeof(ProcessContainerFilesystemPolicy)));

	public JsonTypeInfo<ProcessContainerNetworkPolicy> ProcessContainerNetworkPolicy => _ProcessContainerNetworkPolicy ?? (_ProcessContainerNetworkPolicy = (JsonTypeInfo<ProcessContainerNetworkPolicy>)Options.GetTypeInfo(typeof(ProcessContainerNetworkPolicy)));

	public JsonTypeInfo<ProcessContainerSystemSettings> ProcessContainerSystemSettings => _ProcessContainerSystemSettings ?? (_ProcessContainerSystemSettings = (JsonTypeInfo<ProcessContainerSystemSettings>)Options.GetTypeInfo(typeof(ProcessContainerSystemSettings)));

	public JsonTypeInfo<Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation> ProcessContainerUiIsolation => _ProcessContainerUiIsolation ?? (_ProcessContainerUiIsolation = (JsonTypeInfo<Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation>)Options.GetTypeInfo(typeof(Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation)));

	public JsonTypeInfo<ProcessContainerUiPolicy> ProcessContainerUiPolicy => _ProcessContainerUiPolicy ?? (_ProcessContainerUiPolicy = (JsonTypeInfo<ProcessContainerUiPolicy>)Options.GetTypeInfo(typeof(ProcessContainerUiPolicy)));

	public JsonTypeInfo<ProcessNetworkPolicy> ProcessNetworkPolicy => _ProcessNetworkPolicy ?? (_ProcessNetworkPolicy = (JsonTypeInfo<ProcessNetworkPolicy>)Options.GetTypeInfo(typeof(ProcessNetworkPolicy)));

	public JsonTypeInfo<ProvisionMetadata> ProvisionMetadata => _ProvisionMetadata ?? (_ProvisionMetadata = (JsonTypeInfo<ProvisionMetadata>)Options.GetTypeInfo(typeof(ProvisionMetadata)));

	public JsonTypeInfo<ProvisionOptions> ProvisionOptions => _ProvisionOptions ?? (_ProvisionOptions = (JsonTypeInfo<ProvisionOptions>)Options.GetTypeInfo(typeof(ProvisionOptions)));

	public JsonTypeInfo<ProvisionRequest> ProvisionRequest => _ProvisionRequest ?? (_ProvisionRequest = (JsonTypeInfo<ProvisionRequest>)Options.GetTypeInfo(typeof(ProvisionRequest)));

	public JsonTypeInfo<ProvisionResult> ProvisionResult => _ProvisionResult ?? (_ProvisionResult = (JsonTypeInfo<ProvisionResult>)Options.GetTypeInfo(typeof(ProvisionResult)));

	public JsonTypeInfo<RunInContainerOptions> RunInContainerOptions => _RunInContainerOptions ?? (_RunInContainerOptions = (JsonTypeInfo<RunInContainerOptions>)Options.GetTypeInfo(typeof(RunInContainerOptions)));

	public JsonTypeInfo<RunOptions> RunOptions => _RunOptions ?? (_RunOptions = (JsonTypeInfo<RunOptions>)Options.GetTypeInfo(typeof(RunOptions)));

	public JsonTypeInfo<SpawnInContainerOptions> SpawnInContainerOptions => _SpawnInContainerOptions ?? (_SpawnInContainerOptions = (JsonTypeInfo<SpawnInContainerOptions>)Options.GetTypeInfo(typeof(SpawnInContainerOptions)));

	public JsonTypeInfo<SpawnInContainerWithPtyOptions> SpawnInContainerWithPtyOptions => _SpawnInContainerWithPtyOptions ?? (_SpawnInContainerWithPtyOptions = (JsonTypeInfo<SpawnInContainerWithPtyOptions>)Options.GetTypeInfo(typeof(SpawnInContainerWithPtyOptions)));

	public JsonTypeInfo<SpawnOptions> SpawnOptions => _SpawnOptions ?? (_SpawnOptions = (JsonTypeInfo<SpawnOptions>)Options.GetTypeInfo(typeof(SpawnOptions)));

	public JsonTypeInfo<SpawnWithPtyOptions> SpawnWithPtyOptions => _SpawnWithPtyOptions ?? (_SpawnWithPtyOptions = (JsonTypeInfo<SpawnWithPtyOptions>)Options.GetTypeInfo(typeof(SpawnWithPtyOptions)));

	public JsonTypeInfo<StartOptions> StartOptions => _StartOptions ?? (_StartOptions = (JsonTypeInfo<StartOptions>)Options.GetTypeInfo(typeof(StartOptions)));

	public JsonTypeInfo<StopOptions> StopOptions => _StopOptions ?? (_StopOptions = (JsonTypeInfo<StopOptions>)Options.GetTypeInfo(typeof(StopOptions)));

	public JsonTypeInfo<TelemetryConfig> TelemetryConfig => _TelemetryConfig ?? (_TelemetryConfig = (JsonTypeInfo<TelemetryConfig>)Options.GetTypeInfo(typeof(TelemetryConfig)));

	public JsonTypeInfo<UiPolicy> UiPolicy => _UiPolicy ?? (_UiPolicy = (JsonTypeInfo<UiPolicy>)Options.GetTypeInfo(typeof(UiPolicy)));

	public JsonTypeInfo<ValidationResult> ValidationResult => _ValidationResult ?? (_ValidationResult = (JsonTypeInfo<ValidationResult>)Options.GetTypeInfo(typeof(ValidationResult)));

	public JsonTypeInfo<WslcPortMapping> WslcPortMapping => _WslcPortMapping ?? (_WslcPortMapping = (JsonTypeInfo<WslcPortMapping>)Options.GetTypeInfo(typeof(WslcPortMapping)));

	public JsonTypeInfo<Microsoft.Mxc.Sdk.V1.WslcProvisionRequest> WslcProvisionRequest => _WslcProvisionRequest ?? (_WslcProvisionRequest = (JsonTypeInfo<Microsoft.Mxc.Sdk.V1.WslcProvisionRequest>)Options.GetTypeInfo(typeof(Microsoft.Mxc.Sdk.V1.WslcProvisionRequest)));

	public JsonTypeInfo<Dictionary<string, string>> DictionaryStringString => _DictionaryStringString ?? (_DictionaryStringString = (JsonTypeInfo<Dictionary<string, string>>)Options.GetTypeInfo(typeof(Dictionary<string, string>)));

	public JsonTypeInfo<List<NetworkPeer>> ListNetworkPeer => _ListNetworkPeer ?? (_ListNetworkPeer = (JsonTypeInfo<List<NetworkPeer>>)Options.GetTypeInfo(typeof(List<NetworkPeer>)));

	public JsonTypeInfo<List<NetworkPort>> ListNetworkPort => _ListNetworkPort ?? (_ListNetworkPort = (JsonTypeInfo<List<NetworkPort>>)Options.GetTypeInfo(typeof(List<NetworkPort>)));

	public JsonTypeInfo<List<NetworkRule>> ListNetworkRule => _ListNetworkRule ?? (_ListNetworkRule = (JsonTypeInfo<List<NetworkRule>>)Options.GetTypeInfo(typeof(List<NetworkRule>)));

	public JsonTypeInfo<List<PortMapping>> ListPortMapping => _ListPortMapping ?? (_ListPortMapping = (JsonTypeInfo<List<PortMapping>>)Options.GetTypeInfo(typeof(List<PortMapping>)));

	public JsonTypeInfo<List<NetworkPeerPolicy>> ListNetworkPeerPolicy => _ListNetworkPeerPolicy ?? (_ListNetworkPeerPolicy = (JsonTypeInfo<List<NetworkPeerPolicy>>)Options.GetTypeInfo(typeof(List<NetworkPeerPolicy>)));

	public JsonTypeInfo<List<NetworkPortPolicy>> ListNetworkPortPolicy => _ListNetworkPortPolicy ?? (_ListNetworkPortPolicy = (JsonTypeInfo<List<NetworkPortPolicy>>)Options.GetTypeInfo(typeof(List<NetworkPortPolicy>)));

	public JsonTypeInfo<List<NetworkRulePolicy>> ListNetworkRulePolicy => _ListNetworkRulePolicy ?? (_ListNetworkRulePolicy = (JsonTypeInfo<List<NetworkRulePolicy>>)Options.GetTypeInfo(typeof(List<NetworkRulePolicy>)));

	public JsonTypeInfo<List<WslcPortMapping>> ListWslcPortMapping => _ListWslcPortMapping ?? (_ListWslcPortMapping = (JsonTypeInfo<List<WslcPortMapping>>)Options.GetTypeInfo(typeof(List<WslcPortMapping>)));

	public JsonTypeInfo<List<string>> ListString => _ListString ?? (_ListString = (JsonTypeInfo<List<string>>)Options.GetTypeInfo(typeof(List<string>)));

	public JsonTypeInfo<int> Int32 => _Int32 ?? (_Int32 = (JsonTypeInfo<int>)Options.GetTypeInfo(typeof(int)));

	public JsonTypeInfo<object> Object => _Object ?? (_Object = (JsonTypeInfo<object>)Options.GetTypeInfo(typeof(object)));

	public JsonTypeInfo<string> String => _String ?? (_String = (JsonTypeInfo<string>)Options.GetTypeInfo(typeof(string)));

	public JsonTypeInfo<string[]> StringArray => _StringArray ?? (_StringArray = (JsonTypeInfo<string[]>)Options.GetTypeInfo(typeof(string[])));

	public JsonTypeInfo<uint> UInt32 => _UInt32 ?? (_UInt32 = (JsonTypeInfo<uint>)Options.GetTypeInfo(typeof(uint)));

	public JsonTypeInfo<uint?> NullableUInt32 => _NullableUInt32 ?? (_NullableUInt32 = (JsonTypeInfo<uint?>)Options.GetTypeInfo(typeof(uint?)));

	public JsonTypeInfo<ulong> UInt64 => _UInt64 ?? (_UInt64 = (JsonTypeInfo<ulong>)Options.GetTypeInfo(typeof(ulong)));

	public JsonTypeInfo<ulong?> NullableUInt64 => _NullableUInt64 ?? (_NullableUInt64 = (JsonTypeInfo<ulong?>)Options.GetTypeInfo(typeof(ulong?)));

	public JsonTypeInfo<ushort> UInt16 => _UInt16 ?? (_UInt16 = (JsonTypeInfo<ushort>)Options.GetTypeInfo(typeof(ushort)));

	public JsonTypeInfo<ushort?> NullableUInt16 => _NullableUInt16 ?? (_NullableUInt16 = (JsonTypeInfo<ushort?>)Options.GetTypeInfo(typeof(ushort?)));

	public static MxcJsonContext Default { get; } = new MxcJsonContext(new JsonSerializerOptions(s_defaultOptions));

	protected override JsonSerializerOptions? GeneratedSerializerOptions { get; } = s_defaultOptions;

	private JsonTypeInfo<bool> Create_Boolean(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<bool> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<bool>(options, JsonMetadataServices.BooleanConverter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<bool?> Create_NullableBoolean(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<bool?> jsonTypeInfo))
		{
			JsonConverter nullableConverter = JsonMetadataServices.GetNullableConverter<bool>(options);
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<bool?>(options, nullableConverter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<CaptureDenials> Create_CaptureDenials(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<CaptureDenials> jsonTypeInfo))
		{
			JsonObjectInfoValues<CaptureDenials> objectInfo = new JsonObjectInfoValues<CaptureDenials>
			{
				ObjectCreator = () => new CaptureDenials(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => CaptureDenialsPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = CaptureDenialsSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] CaptureDenialsPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenials),
			Converter = null,
			Getter = (object obj) => ((CaptureDenials)obj).Mode,
			Setter = (object obj, string? value) =>
			{
				((CaptureDenials)obj).Mode = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Mode",
			JsonPropertyName = "mode"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenials),
			Converter = null,
			Getter = (object obj) => ((CaptureDenials)obj).OutputPath,
			Setter = (object obj, string? value) =>
			{
				((CaptureDenials)obj).OutputPath = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "OutputPath",
			JsonPropertyName = "outputPath"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<bool?> propertyInfo3 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenials),
			Converter = null,
			Getter = (object obj) => ((CaptureDenials)obj).RetainEtl,
			Setter = (object obj, bool? value) =>
			{
				((CaptureDenials)obj).RetainEtl = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "RetainEtl",
			JsonPropertyName = "retainEtl"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void CaptureDenialsSerializeHandler(Utf8JsonWriter writer, CaptureDenials? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string mode = value.Mode;
		if (mode != null)
		{
			writer.WriteString(PropName_mode, mode);
		}
		string outputPath = value.OutputPath;
		if (outputPath != null)
		{
			writer.WriteString(PropName_outputPath, outputPath);
		}
		bool? retainEtl = value.RetainEtl;
		if (retainEtl.HasValue)
		{
			writer.WritePropertyName(PropName_retainEtl);
			JsonSerializer.Serialize(writer, retainEtl, NullableBoolean);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Fallback> Create_Fallback(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Fallback> jsonTypeInfo))
		{
			JsonObjectInfoValues<Fallback> objectInfo = new JsonObjectInfoValues<Fallback>
			{
				ObjectCreator = () => new Fallback(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => FallbackPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = FallbackSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] FallbackPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<bool?> propertyInfo = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Fallback),
			Converter = null,
			Getter = (object obj) => ((Fallback)obj).AllowDaclMutation,
			Setter = (object obj, bool? value) =>
			{
				((Fallback)obj).AllowDaclMutation = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "AllowDaclMutation",
			JsonPropertyName = "allowDaclMutation"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void FallbackSerializeHandler(Utf8JsonWriter writer, Fallback? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		bool? allowDaclMutation = value.AllowDaclMutation;
		if (allowDaclMutation.HasValue)
		{
			writer.WritePropertyName(PropName_allowDaclMutation);
			JsonSerializer.Serialize(writer, allowDaclMutation, NullableBoolean);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Filesystem> Create_Filesystem(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Filesystem> jsonTypeInfo))
		{
			JsonObjectInfoValues<Filesystem> objectInfo = new JsonObjectInfoValues<Filesystem>
			{
				ObjectCreator = () => new Filesystem(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => FilesystemPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = FilesystemSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] FilesystemPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<List<string>> propertyInfo = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Filesystem),
			Converter = null,
			Getter = (object obj) => ((Filesystem)obj).DeniedPaths,
			Setter = (object obj, List<string>? value) =>
			{
				((Filesystem)obj).DeniedPaths = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "DeniedPaths",
			JsonPropertyName = "deniedPaths"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<List<string>> propertyInfo2 = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Filesystem),
			Converter = null,
			Getter = (object obj) => ((Filesystem)obj).ReadonlyPaths,
			Setter = (object obj, List<string>? value) =>
			{
				((Filesystem)obj).ReadonlyPaths = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ReadonlyPaths",
			JsonPropertyName = "readonlyPaths"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<List<string>> propertyInfo3 = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Filesystem),
			Converter = null,
			Getter = (object obj) => ((Filesystem)obj).ReadwritePaths,
			Setter = (object obj, List<string>? value) =>
			{
				((Filesystem)obj).ReadwritePaths = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ReadwritePaths",
			JsonPropertyName = "readwritePaths"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void FilesystemSerializeHandler(Utf8JsonWriter writer, Filesystem? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		List<string> deniedPaths = value.DeniedPaths;
		if (deniedPaths != null)
		{
			writer.WritePropertyName(PropName_deniedPaths);
			ListStringSerializeHandler(writer, deniedPaths);
		}
		List<string> readonlyPaths = value.ReadonlyPaths;
		if (readonlyPaths != null)
		{
			writer.WritePropertyName(PropName_readonlyPaths);
			ListStringSerializeHandler(writer, readonlyPaths);
		}
		List<string> readwritePaths = value.ReadwritePaths;
		if (readwritePaths != null)
		{
			writer.WritePropertyName(PropName_readwritePaths);
			ListStringSerializeHandler(writer, readwritePaths);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Lifecycle> Create_Lifecycle(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Lifecycle> jsonTypeInfo))
		{
			JsonObjectInfoValues<Lifecycle> objectInfo = new JsonObjectInfoValues<Lifecycle>
			{
				ObjectCreator = () => new Lifecycle(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => LifecyclePropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = LifecycleSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] LifecyclePropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<bool?> propertyInfo = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Lifecycle),
			Converter = null,
			Getter = (object obj) => ((Lifecycle)obj).DestroyOnExit,
			Setter = (object obj, bool? value) =>
			{
				((Lifecycle)obj).DestroyOnExit = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "DestroyOnExit",
			JsonPropertyName = "destroyOnExit"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<bool?> propertyInfo2 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Lifecycle),
			Converter = null,
			Getter = (object obj) => ((Lifecycle)obj).PreservePolicy,
			Setter = (object obj, bool? value) =>
			{
				((Lifecycle)obj).PreservePolicy = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "PreservePolicy",
			JsonPropertyName = "preservePolicy"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void LifecycleSerializeHandler(Utf8JsonWriter writer, Lifecycle? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		bool? destroyOnExit = value.DestroyOnExit;
		if (destroyOnExit.HasValue)
		{
			writer.WritePropertyName(PropName_destroyOnExit);
			JsonSerializer.Serialize(writer, destroyOnExit, NullableBoolean);
		}
		bool? preservePolicy = value.PreservePolicy;
		if (preservePolicy.HasValue)
		{
			writer.WritePropertyName(PropName_preservePolicy);
			JsonSerializer.Serialize(writer, preservePolicy, NullableBoolean);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Lxc> Create_Lxc(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Lxc> jsonTypeInfo))
		{
			JsonObjectInfoValues<Lxc> objectInfo = new JsonObjectInfoValues<Lxc>
			{
				ObjectCreator = () => new Lxc(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => LxcPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = LxcSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] LxcPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Lxc),
			Converter = null,
			Getter = (object obj) => ((Lxc)obj).Distribution,
			Setter = (object obj, string? value) =>
			{
				((Lxc)obj).Distribution = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Distribution",
			JsonPropertyName = "distribution"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Lxc),
			Converter = null,
			Getter = (object obj) => ((Lxc)obj).Release,
			Setter = (object obj, string? value) =>
			{
				((Lxc)obj).Release = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Release",
			JsonPropertyName = "release"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void LxcSerializeHandler(Utf8JsonWriter writer, Lxc? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string distribution = value.Distribution;
		if (distribution != null)
		{
			writer.WriteString(PropName_distribution, distribution);
		}
		string release = value.Release;
		if (release != null)
		{
			writer.WriteString(PropName_release, release);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Network> Create_Network(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Network> jsonTypeInfo))
		{
			JsonObjectInfoValues<Network> objectInfo = new JsonObjectInfoValues<Network>
			{
				ObjectCreator = () => new Network(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NetworkPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NetworkSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NetworkPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<NetworkEgress> propertyInfo = new JsonPropertyInfoValues<NetworkEgress>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Network),
			Converter = null,
			Getter = (object obj) => ((Network)obj).Egress,
			Setter = (object obj, NetworkEgress? value) =>
			{
				((Network)obj).Egress = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Egress",
			JsonPropertyName = "egress"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<NetworkIngress> propertyInfo2 = new JsonPropertyInfoValues<NetworkIngress>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Network),
			Converter = null,
			Getter = (object obj) => ((Network)obj).Ingress,
			Setter = (object obj, NetworkIngress? value) =>
			{
				((Network)obj).Ingress = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Ingress",
			JsonPropertyName = "ingress"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void NetworkSerializeHandler(Utf8JsonWriter writer, Network? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		NetworkEgress egress = value.Egress;
		if (egress != null)
		{
			writer.WritePropertyName(PropName_egress);
			NetworkEgressSerializeHandler(writer, egress);
		}
		NetworkIngress ingress = value.Ingress;
		if (ingress != null)
		{
			writer.WritePropertyName(PropName_ingress);
			NetworkIngressSerializeHandler(writer, ingress);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<NetworkEgress> Create_NetworkEgress(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NetworkEgress> jsonTypeInfo))
		{
			JsonObjectInfoValues<NetworkEgress> objectInfo = new JsonObjectInfoValues<NetworkEgress>
			{
				ObjectCreator = () => new NetworkEgress(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NetworkEgressPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NetworkEgressSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NetworkEgressPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<List<NetworkRule>> propertyInfo = new JsonPropertyInfoValues<List<NetworkRule>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkEgress),
			Converter = null,
			Getter = (object obj) => ((NetworkEgress)obj).Allow,
			Setter = (object obj, List<NetworkRule>? value) =>
			{
				((NetworkEgress)obj).Allow = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Allow",
			JsonPropertyName = "allow"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkEgress),
			Converter = null,
			Getter = (object obj) => ((NetworkEgress)obj).Default,
			Setter = (object obj, string? value) =>
			{
				((NetworkEgress)obj).Default = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Default",
			JsonPropertyName = "default"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<List<NetworkRule>> propertyInfo3 = new JsonPropertyInfoValues<List<NetworkRule>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkEgress),
			Converter = null,
			Getter = (object obj) => ((NetworkEgress)obj).Deny,
			Setter = (object obj, List<NetworkRule>? value) =>
			{
				((NetworkEgress)obj).Deny = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Deny",
			JsonPropertyName = "deny"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void NetworkEgressSerializeHandler(Utf8JsonWriter writer, NetworkEgress? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		List<NetworkRule> allow = value.Allow;
		if (allow != null)
		{
			writer.WritePropertyName(PropName_allow);
			ListNetworkRuleSerializeHandler(writer, allow);
		}
		string text = value.Default;
		if (text != null)
		{
			writer.WriteString(PropName_default, text);
		}
		List<NetworkRule> deny = value.Deny;
		if (deny != null)
		{
			writer.WritePropertyName(PropName_deny);
			ListNetworkRuleSerializeHandler(writer, deny);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<NetworkIngress> Create_NetworkIngress(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NetworkIngress> jsonTypeInfo))
		{
			JsonObjectInfoValues<NetworkIngress> objectInfo = new JsonObjectInfoValues<NetworkIngress>
			{
				ObjectCreator = () => new NetworkIngress(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NetworkIngressPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NetworkIngressSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NetworkIngressPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkIngress),
			Converter = null,
			Getter = (object obj) => ((NetworkIngress)obj).Default,
			Setter = (object obj, string? value) =>
			{
				((NetworkIngress)obj).Default = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Default",
			JsonPropertyName = "default"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkIngress),
			Converter = null,
			Getter = (object obj) => ((NetworkIngress)obj).HostLoopback,
			Setter = (object obj, string? value) =>
			{
				((NetworkIngress)obj).HostLoopback = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "HostLoopback",
			JsonPropertyName = "hostLoopback"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void NetworkIngressSerializeHandler(Utf8JsonWriter writer, NetworkIngress? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string text = value.Default;
		if (text != null)
		{
			writer.WriteString(PropName_default, text);
		}
		string hostLoopback = value.HostLoopback;
		if (hostLoopback != null)
		{
			writer.WriteString(PropName_hostLoopback, hostLoopback);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<NetworkPeer> Create_NetworkPeer(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NetworkPeer> jsonTypeInfo))
		{
			JsonObjectInfoValues<NetworkPeer> objectInfo = new JsonObjectInfoValues<NetworkPeer>
			{
				ObjectCreator = () => new NetworkPeer(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NetworkPeerPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NetworkPeerSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NetworkPeerPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkPeer),
			Converter = null,
			Getter = (object obj) => ((NetworkPeer)obj).Cidr,
			Setter = (object obj, string? value) =>
			{
				((NetworkPeer)obj).Cidr = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Cidr",
			JsonPropertyName = "cidr"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<List<string>> propertyInfo2 = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkPeer),
			Converter = null,
			Getter = (object obj) => ((NetworkPeer)obj).Except,
			Setter = (object obj, List<string>? value) =>
			{
				((NetworkPeer)obj).Except = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Except",
			JsonPropertyName = "except"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void NetworkPeerSerializeHandler(Utf8JsonWriter writer, NetworkPeer? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string cidr = value.Cidr;
		if (cidr != null)
		{
			writer.WriteString(PropName_cidr, cidr);
		}
		List<string> except = value.Except;
		if (except != null)
		{
			writer.WritePropertyName(PropName_except);
			ListStringSerializeHandler(writer, except);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<NetworkPort> Create_NetworkPort(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NetworkPort> jsonTypeInfo))
		{
			JsonObjectInfoValues<NetworkPort> objectInfo = new JsonObjectInfoValues<NetworkPort>
			{
				ObjectCreator = () => new NetworkPort(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NetworkPortPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NetworkPortSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NetworkPortPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<ushort?> propertyInfo = new JsonPropertyInfoValues<ushort?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkPort),
			Converter = null,
			Getter = (object obj) => ((NetworkPort)obj).EndPort,
			Setter = (object obj, ushort? value) =>
			{
				((NetworkPort)obj).EndPort = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "EndPort",
			JsonPropertyName = "endPort"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<ushort?> propertyInfo2 = new JsonPropertyInfoValues<ushort?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkPort),
			Converter = null,
			Getter = (object obj) => ((NetworkPort)obj).Port,
			Setter = (object obj, ushort? value) =>
			{
				((NetworkPort)obj).Port = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Port",
			JsonPropertyName = "port"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<string> propertyInfo3 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkPort),
			Converter = null,
			Getter = (object obj) => ((NetworkPort)obj).Protocol,
			Setter = (object obj, string? value) =>
			{
				((NetworkPort)obj).Protocol = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Protocol",
			JsonPropertyName = "protocol"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void NetworkPortSerializeHandler(Utf8JsonWriter writer, NetworkPort? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		ushort? endPort = value.EndPort;
		if (endPort.HasValue)
		{
			writer.WritePropertyName(PropName_endPort);
			JsonSerializer.Serialize(writer, endPort, NullableUInt16);
		}
		ushort? port = value.Port;
		if (port.HasValue)
		{
			writer.WritePropertyName(PropName_port);
			JsonSerializer.Serialize(writer, port, NullableUInt16);
		}
		string protocol = value.Protocol;
		if (protocol != null)
		{
			writer.WriteString(PropName_protocol, protocol);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<NetworkRule> Create_NetworkRule(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NetworkRule> jsonTypeInfo))
		{
			JsonObjectInfoValues<NetworkRule> objectInfo = new JsonObjectInfoValues<NetworkRule>
			{
				ObjectCreator = () => new NetworkRule(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NetworkRulePropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NetworkRuleSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NetworkRulePropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<List<NetworkPort>> propertyInfo = new JsonPropertyInfoValues<List<NetworkPort>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkRule),
			Converter = null,
			Getter = (object obj) => ((NetworkRule)obj).Ports,
			Setter = (object obj, List<NetworkPort>? value) =>
			{
				((NetworkRule)obj).Ports = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Ports",
			JsonPropertyName = "ports"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<List<NetworkPeer>> propertyInfo2 = new JsonPropertyInfoValues<List<NetworkPeer>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkRule),
			Converter = null,
			Getter = (object obj) => ((NetworkRule)obj).To,
			Setter = (object obj, List<NetworkPeer>? value) =>
			{
				((NetworkRule)obj).To = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "To",
			JsonPropertyName = "to"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void NetworkRuleSerializeHandler(Utf8JsonWriter writer, NetworkRule? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		List<NetworkPort> ports = value.Ports;
		if (ports != null)
		{
			writer.WritePropertyName(PropName_ports);
			ListNetworkPortSerializeHandler(writer, ports);
		}
		List<NetworkPeer> to = value.To;
		if (to != null)
		{
			writer.WritePropertyName(PropName_to);
			ListNetworkPeerSerializeHandler(writer, to);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<OneShotRequest> Create_OneShotRequest(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<OneShotRequest> jsonTypeInfo))
		{
			JsonObjectInfoValues<OneShotRequest> objectInfo = new JsonObjectInfoValues<OneShotRequest>
			{
				ObjectCreator = () => new OneShotRequest(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => OneShotRequestPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = null
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] OneShotRequestPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[17];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Schema,
			Setter = (object obj, string? value) =>
			{
				((OneShotRequest)obj).Schema = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Schema",
			JsonPropertyName = "$schema"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<object> propertyInfo2 = new JsonPropertyInfoValues<object>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Comment,
			Setter = (object obj, object? value) =>
			{
				((OneShotRequest)obj).Comment = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Comment",
			JsonPropertyName = "_comment"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<string> propertyInfo3 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).ContainerId,
			Setter = (object obj, string? value) =>
			{
				((OneShotRequest)obj).ContainerId = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ContainerId",
			JsonPropertyName = "containerId"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<string> propertyInfo4 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Containment,
			Setter = (object obj, string? value) =>
			{
				((OneShotRequest)obj).Containment = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Containment",
			JsonPropertyName = "containment"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		JsonPropertyInfoValues<Fallback> propertyInfo5 = new JsonPropertyInfoValues<Fallback>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Fallback,
			Setter = (object obj, Fallback? value) =>
			{
				((OneShotRequest)obj).Fallback = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Fallback",
			JsonPropertyName = "fallback"
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		JsonPropertyInfoValues<Filesystem> propertyInfo6 = new JsonPropertyInfoValues<Filesystem>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Filesystem,
			Setter = (object obj, Filesystem? value) =>
			{
				((OneShotRequest)obj).Filesystem = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Filesystem",
			JsonPropertyName = "filesystem"
		};
		array[5] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo6);
		JsonPropertyInfoValues<Lifecycle> propertyInfo7 = new JsonPropertyInfoValues<Lifecycle>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Lifecycle,
			Setter = (object obj, Lifecycle? value) =>
			{
				((OneShotRequest)obj).Lifecycle = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Lifecycle",
			JsonPropertyName = "lifecycle"
		};
		array[6] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo7);
		JsonPropertyInfoValues<Lxc> propertyInfo8 = new JsonPropertyInfoValues<Lxc>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Lxc,
			Setter = (object obj, Lxc? value) =>
			{
				((OneShotRequest)obj).Lxc = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Lxc",
			JsonPropertyName = "lxc"
		};
		array[7] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo8);
		JsonPropertyInfoValues<Network> propertyInfo9 = new JsonPropertyInfoValues<Network>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Network,
			Setter = (object obj, Network? value) =>
			{
				((OneShotRequest)obj).Network = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Network",
			JsonPropertyName = "network"
		};
		array[8] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo9);
		JsonPropertyInfoValues<Process> propertyInfo10 = new JsonPropertyInfoValues<Process>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Process,
			Setter = (object obj, Process? value) =>
			{
				((OneShotRequest)obj).Process = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Process",
			JsonPropertyName = "process"
		};
		array[9] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo10);
		JsonPropertyInfoValues<ProcessContainer> propertyInfo11 = new JsonPropertyInfoValues<ProcessContainer>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).ProcessContainer,
			Setter = (object obj, ProcessContainer? value) =>
			{
				((OneShotRequest)obj).ProcessContainer = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ProcessContainer",
			JsonPropertyName = "processContainer"
		};
		array[10] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo11);
		JsonPropertyInfoValues<RuntimeConfig> propertyInfo12 = new JsonPropertyInfoValues<RuntimeConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).RuntimeConfig,
			Setter = (object obj, RuntimeConfig? value) =>
			{
				((OneShotRequest)obj).RuntimeConfig = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "RuntimeConfig",
			JsonPropertyName = "runtimeConfig"
		};
		array[11] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo12);
		JsonPropertyInfoValues<Seatbelt> propertyInfo13 = new JsonPropertyInfoValues<Seatbelt>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Seatbelt,
			Setter = (object obj, Seatbelt? value) =>
			{
				((OneShotRequest)obj).Seatbelt = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Seatbelt",
			JsonPropertyName = "seatbelt"
		};
		array[12] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo13);
		JsonPropertyInfoValues<Telemetry> propertyInfo14 = new JsonPropertyInfoValues<Telemetry>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Telemetry,
			Setter = (object obj, Telemetry? value) =>
			{
				((OneShotRequest)obj).Telemetry = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = "telemetry"
		};
		array[13] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo14);
		JsonPropertyInfoValues<Ui> propertyInfo15 = new JsonPropertyInfoValues<Ui>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Ui,
			Setter = (object obj, Ui? value) =>
			{
				((OneShotRequest)obj).Ui = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Ui",
			JsonPropertyName = "ui"
		};
		array[14] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo15);
		JsonPropertyInfoValues<string> propertyInfo16 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Version,
			Setter = (object obj, string? value) =>
			{
				((OneShotRequest)obj).Version = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Version",
			JsonPropertyName = "version"
		};
		array[15] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo16);
		JsonPropertyInfoValues<OneShotWslc> propertyInfo17 = new JsonPropertyInfoValues<OneShotWslc>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotRequest),
			Converter = null,
			Getter = (object obj) => ((OneShotRequest)obj).Wslc,
			Setter = (object obj, OneShotWslc? value) =>
			{
				((OneShotRequest)obj).Wslc = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Wslc",
			JsonPropertyName = "wslc"
		};
		array[16] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo17);
		return array;
	}

	private JsonTypeInfo<OneShotWslc> Create_OneShotWslc(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<OneShotWslc> jsonTypeInfo))
		{
			JsonObjectInfoValues<OneShotWslc> objectInfo = new JsonObjectInfoValues<OneShotWslc>
			{
				ObjectCreator = () => new OneShotWslc(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => OneShotWslcPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = OneShotWslcSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] OneShotWslcPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[8];
		JsonPropertyInfoValues<uint?> propertyInfo = new JsonPropertyInfoValues<uint?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotWslc),
			Converter = null,
			Getter = (object obj) => ((OneShotWslc)obj).CpuCount,
			Setter = (object obj, uint? value) =>
			{
				((OneShotWslc)obj).CpuCount = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CpuCount",
			JsonPropertyName = "cpuCount"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<bool?> propertyInfo2 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotWslc),
			Converter = null,
			Getter = (object obj) => ((OneShotWslc)obj).Gpu,
			Setter = (object obj, bool? value) =>
			{
				((OneShotWslc)obj).Gpu = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Gpu",
			JsonPropertyName = "gpu"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<string> propertyInfo3 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotWslc),
			Converter = null,
			Getter = (object obj) => ((OneShotWslc)obj).Image,
			Setter = (object obj, string? value) =>
			{
				((OneShotWslc)obj).Image = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Image",
			JsonPropertyName = "image"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<string> propertyInfo4 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotWslc),
			Converter = null,
			Getter = (object obj) => ((OneShotWslc)obj).ImageTarPath,
			Setter = (object obj, string? value) =>
			{
				((OneShotWslc)obj).ImageTarPath = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ImageTarPath",
			JsonPropertyName = "imageTarPath"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		JsonPropertyInfoValues<ulong?> propertyInfo5 = new JsonPropertyInfoValues<ulong?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotWslc),
			Converter = null,
			Getter = (object obj) => ((OneShotWslc)obj).MemoryMb,
			Setter = (object obj, ulong? value) =>
			{
				((OneShotWslc)obj).MemoryMb = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "MemoryMb",
			JsonPropertyName = "memoryMb"
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		JsonPropertyInfoValues<List<PortMapping>> propertyInfo6 = new JsonPropertyInfoValues<List<PortMapping>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotWslc),
			Converter = null,
			Getter = (object obj) => ((OneShotWslc)obj).PortMappings,
			Setter = (object obj, List<PortMapping>? value) =>
			{
				((OneShotWslc)obj).PortMappings = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "PortMappings",
			JsonPropertyName = "portMappings"
		};
		array[5] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo6);
		JsonPropertyInfoValues<string> propertyInfo7 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotWslc),
			Converter = null,
			Getter = (object obj) => ((OneShotWslc)obj).StoragePath,
			Setter = (object obj, string? value) =>
			{
				((OneShotWslc)obj).StoragePath = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "StoragePath",
			JsonPropertyName = "storagePath"
		};
		array[6] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo7);
		JsonPropertyInfoValues<string> propertyInfo8 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(OneShotWslc),
			Converter = null,
			Getter = (object obj) => ((OneShotWslc)obj).TargetOs,
			Setter = (object obj, string? value) =>
			{
				((OneShotWslc)obj).TargetOs = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "TargetOs",
			JsonPropertyName = "targetOs"
		};
		array[7] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo8);
		return array;
	}

	private void OneShotWslcSerializeHandler(Utf8JsonWriter writer, OneShotWslc? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		uint? cpuCount = value.CpuCount;
		if (cpuCount.HasValue)
		{
			writer.WritePropertyName(PropName_cpuCount);
			JsonSerializer.Serialize(writer, cpuCount, NullableUInt32);
		}
		bool? gpu = value.Gpu;
		if (gpu.HasValue)
		{
			writer.WritePropertyName(PropName_gpu);
			JsonSerializer.Serialize(writer, gpu, NullableBoolean);
		}
		string image = value.Image;
		if (image != null)
		{
			writer.WriteString(PropName_image, image);
		}
		string imageTarPath = value.ImageTarPath;
		if (imageTarPath != null)
		{
			writer.WriteString(PropName_imageTarPath, imageTarPath);
		}
		ulong? memoryMb = value.MemoryMb;
		if (memoryMb.HasValue)
		{
			writer.WritePropertyName(PropName_memoryMb);
			JsonSerializer.Serialize(writer, memoryMb, NullableUInt64);
		}
		List<PortMapping> portMappings = value.PortMappings;
		if (portMappings != null)
		{
			writer.WritePropertyName(PropName_portMappings);
			ListPortMappingSerializeHandler(writer, portMappings);
		}
		string storagePath = value.StoragePath;
		if (storagePath != null)
		{
			writer.WriteString(PropName_storagePath, storagePath);
		}
		string targetOs = value.TargetOs;
		if (targetOs != null)
		{
			writer.WriteString(PropName_targetOs, targetOs);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<PortMapping> Create_PortMapping(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<PortMapping> jsonTypeInfo))
		{
			JsonObjectInfoValues<PortMapping> objectInfo = new JsonObjectInfoValues<PortMapping>
			{
				ObjectCreator = () => new PortMapping(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => PortMappingPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = PortMappingSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] PortMappingPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<ushort> propertyInfo = new JsonPropertyInfoValues<ushort>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(PortMapping),
			Converter = null,
			Getter = (object obj) => ((PortMapping)obj).ContainerPort,
			Setter = (object obj, ushort value) =>
			{
				((PortMapping)obj).ContainerPort = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ContainerPort",
			JsonPropertyName = "containerPort"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(PortMapping),
			Converter = null,
			Getter = (object obj) => ((PortMapping)obj).Protocol,
			Setter = (object obj, string? value) =>
			{
				((PortMapping)obj).Protocol = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Protocol",
			JsonPropertyName = "protocol"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<ushort> propertyInfo3 = new JsonPropertyInfoValues<ushort>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(PortMapping),
			Converter = null,
			Getter = (object obj) => ((PortMapping)obj).WindowsPort,
			Setter = (object obj, ushort value) =>
			{
				((PortMapping)obj).WindowsPort = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "WindowsPort",
			JsonPropertyName = "windowsPort"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void PortMappingSerializeHandler(Utf8JsonWriter writer, PortMapping? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		writer.WriteNumber(PropName_containerPort, value.ContainerPort);
		string protocol = value.Protocol;
		if (protocol != null)
		{
			writer.WriteString(PropName_protocol, protocol);
		}
		writer.WriteNumber(PropName_windowsPort, value.WindowsPort);
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Process> Create_Process(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Process> jsonTypeInfo))
		{
			JsonObjectInfoValues<Process> objectInfo = new JsonObjectInfoValues<Process>
			{
				ObjectCreator = () => new Process(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ProcessPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = ProcessSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ProcessPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[5];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Process),
			Converter = null,
			Getter = (object obj) => ((Process)obj).CommandLine,
			Setter = (object obj, string? value) =>
			{
				((Process)obj).CommandLine = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CommandLine",
			JsonPropertyName = "commandLine"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Process),
			Converter = null,
			Getter = (object obj) => ((Process)obj).Cwd,
			Setter = (object obj, string? value) =>
			{
				((Process)obj).Cwd = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Cwd",
			JsonPropertyName = "cwd"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<List<string>> propertyInfo3 = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Process),
			Converter = null,
			Getter = (object obj) => ((Process)obj).Env,
			Setter = (object obj, List<string>? value) =>
			{
				((Process)obj).Env = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Env",
			JsonPropertyName = "env"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<bool?> propertyInfo4 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Process),
			Converter = null,
			Getter = (object obj) => ((Process)obj).InheritDefaultEnv,
			Setter = (object obj, bool? value) =>
			{
				((Process)obj).InheritDefaultEnv = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "InheritDefaultEnv",
			JsonPropertyName = "inheritDefaultEnv"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		JsonPropertyInfoValues<uint?> propertyInfo5 = new JsonPropertyInfoValues<uint?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Process),
			Converter = null,
			Getter = (object obj) => ((Process)obj).Timeout,
			Setter = (object obj, uint? value) =>
			{
				((Process)obj).Timeout = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Timeout",
			JsonPropertyName = "timeout"
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		return array;
	}

	private void ProcessSerializeHandler(Utf8JsonWriter writer, Process? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string commandLine = value.CommandLine;
		if (commandLine != null)
		{
			writer.WriteString(PropName_commandLine, commandLine);
		}
		string cwd = value.Cwd;
		if (cwd != null)
		{
			writer.WriteString(PropName_cwd, cwd);
		}
		List<string> env = value.Env;
		if (env != null)
		{
			writer.WritePropertyName(PropName_env);
			ListStringSerializeHandler(writer, env);
		}
		bool? inheritDefaultEnv = value.InheritDefaultEnv;
		if (inheritDefaultEnv.HasValue)
		{
			writer.WritePropertyName(PropName_inheritDefaultEnv);
			JsonSerializer.Serialize(writer, inheritDefaultEnv, NullableBoolean);
		}
		uint? timeout = value.Timeout;
		if (timeout.HasValue)
		{
			writer.WritePropertyName(PropName_timeout);
			JsonSerializer.Serialize(writer, timeout, NullableUInt32);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<ProcessContainer> Create_ProcessContainer(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ProcessContainer> jsonTypeInfo))
		{
			JsonObjectInfoValues<ProcessContainer> objectInfo = new JsonObjectInfoValues<ProcessContainer>
			{
				ObjectCreator = () => new ProcessContainer(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ProcessContainerPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = ProcessContainerSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ProcessContainerPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[7];
		JsonPropertyInfoValues<List<string>> propertyInfo = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainer),
			Converter = null,
			Getter = (object obj) => ((ProcessContainer)obj).Capabilities,
			Setter = (object obj, List<string>? value) =>
			{
				((ProcessContainer)obj).Capabilities = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Capabilities",
			JsonPropertyName = "capabilities"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<CaptureDenials> propertyInfo2 = new JsonPropertyInfoValues<CaptureDenials>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainer),
			Converter = null,
			Getter = (object obj) => ((ProcessContainer)obj).CaptureDenials,
			Setter = (object obj, CaptureDenials? value) =>
			{
				((ProcessContainer)obj).CaptureDenials = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CaptureDenials",
			JsonPropertyName = "captureDenials"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<ProcessContainerFilesystem> propertyInfo3 = new JsonPropertyInfoValues<ProcessContainerFilesystem>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainer),
			Converter = null,
			Getter = (object obj) => ((ProcessContainer)obj).Filesystem,
			Setter = (object obj, ProcessContainerFilesystem? value) =>
			{
				((ProcessContainer)obj).Filesystem = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Filesystem",
			JsonPropertyName = "filesystem"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<bool?> propertyInfo4 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainer),
			Converter = null,
			Getter = (object obj) => ((ProcessContainer)obj).LearningMode,
			Setter = (object obj, bool? value) =>
			{
				((ProcessContainer)obj).LearningMode = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "LearningMode",
			JsonPropertyName = "learningMode"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		JsonPropertyInfoValues<bool?> propertyInfo5 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainer),
			Converter = null,
			Getter = (object obj) => ((ProcessContainer)obj).LeastPrivilege,
			Setter = (object obj, bool? value) =>
			{
				((ProcessContainer)obj).LeastPrivilege = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "LeastPrivilege",
			JsonPropertyName = "leastPrivilege"
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		JsonPropertyInfoValues<ProcessContainerNetwork> propertyInfo6 = new JsonPropertyInfoValues<ProcessContainerNetwork>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainer),
			Converter = null,
			Getter = (object obj) => ((ProcessContainer)obj).Network,
			Setter = (object obj, ProcessContainerNetwork? value) =>
			{
				((ProcessContainer)obj).Network = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Network",
			JsonPropertyName = "network"
		};
		array[5] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo6);
		JsonPropertyInfoValues<ProcessContainerUi> propertyInfo7 = new JsonPropertyInfoValues<ProcessContainerUi>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainer),
			Converter = null,
			Getter = (object obj) => ((ProcessContainer)obj).Ui,
			Setter = (object obj, ProcessContainerUi? value) =>
			{
				((ProcessContainer)obj).Ui = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Ui",
			JsonPropertyName = "ui"
		};
		array[6] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo7);
		return array;
	}

	private void ProcessContainerSerializeHandler(Utf8JsonWriter writer, ProcessContainer? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		List<string> capabilities = value.Capabilities;
		if (capabilities != null)
		{
			writer.WritePropertyName(PropName_capabilities);
			ListStringSerializeHandler(writer, capabilities);
		}
		CaptureDenials captureDenials = value.CaptureDenials;
		if (captureDenials != null)
		{
			writer.WritePropertyName(PropName_captureDenials);
			CaptureDenialsSerializeHandler(writer, captureDenials);
		}
		ProcessContainerFilesystem filesystem = value.Filesystem;
		if (filesystem != null)
		{
			writer.WritePropertyName(PropName_filesystem);
			ProcessContainerFilesystemSerializeHandler(writer, filesystem);
		}
		bool? learningMode = value.LearningMode;
		if (learningMode.HasValue)
		{
			writer.WritePropertyName(PropName_learningMode);
			JsonSerializer.Serialize(writer, learningMode, NullableBoolean);
		}
		bool? leastPrivilege = value.LeastPrivilege;
		if (leastPrivilege.HasValue)
		{
			writer.WritePropertyName(PropName_leastPrivilege);
			JsonSerializer.Serialize(writer, leastPrivilege, NullableBoolean);
		}
		ProcessContainerNetwork network = value.Network;
		if (network != null)
		{
			writer.WritePropertyName(PropName_network);
			ProcessContainerNetworkSerializeHandler(writer, network);
		}
		ProcessContainerUi ui = value.Ui;
		if (ui != null)
		{
			writer.WritePropertyName(PropName_ui);
			ProcessContainerUiSerializeHandler(writer, ui);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<ProcessContainerFilesystem> Create_ProcessContainerFilesystem(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ProcessContainerFilesystem> jsonTypeInfo))
		{
			JsonObjectInfoValues<ProcessContainerFilesystem> objectInfo = new JsonObjectInfoValues<ProcessContainerFilesystem>
			{
				ObjectCreator = () => new ProcessContainerFilesystem(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ProcessContainerFilesystemPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = ProcessContainerFilesystemSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ProcessContainerFilesystemPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<List<string>> propertyInfo = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainerFilesystem),
			Converter = null,
			Getter = (object obj) => ((ProcessContainerFilesystem)obj).EnumeratePaths,
			Setter = (object obj, List<string>? value) =>
			{
				((ProcessContainerFilesystem)obj).EnumeratePaths = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "EnumeratePaths",
			JsonPropertyName = "enumeratePaths"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void ProcessContainerFilesystemSerializeHandler(Utf8JsonWriter writer, ProcessContainerFilesystem? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		List<string> enumeratePaths = value.EnumeratePaths;
		if (enumeratePaths != null)
		{
			writer.WritePropertyName(PropName_enumeratePaths);
			ListStringSerializeHandler(writer, enumeratePaths);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<ProcessContainerNetwork> Create_ProcessContainerNetwork(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ProcessContainerNetwork> jsonTypeInfo))
		{
			JsonObjectInfoValues<ProcessContainerNetwork> objectInfo = new JsonObjectInfoValues<ProcessContainerNetwork>
			{
				ObjectCreator = () => new ProcessContainerNetwork(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ProcessContainerNetworkPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = ProcessContainerNetworkSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ProcessContainerNetworkPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainerNetwork),
			Converter = null,
			Getter = (object obj) => ((ProcessContainerNetwork)obj).AllowedProxyPeer,
			Setter = (object obj, string? value) =>
			{
				((ProcessContainerNetwork)obj).AllowedProxyPeer = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "AllowedProxyPeer",
			JsonPropertyName = "allowedProxyPeer"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void ProcessContainerNetworkSerializeHandler(Utf8JsonWriter writer, ProcessContainerNetwork? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string allowedProxyPeer = value.AllowedProxyPeer;
		if (allowedProxyPeer != null)
		{
			writer.WriteString(PropName_allowedProxyPeer, allowedProxyPeer);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<ProcessContainerUi> Create_ProcessContainerUi(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ProcessContainerUi> jsonTypeInfo))
		{
			JsonObjectInfoValues<ProcessContainerUi> objectInfo = new JsonObjectInfoValues<ProcessContainerUi>
			{
				ObjectCreator = () => new ProcessContainerUi(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ProcessContainerUiPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = ProcessContainerUiSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ProcessContainerUiPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[4];
		JsonPropertyInfoValues<bool?> propertyInfo = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainerUi),
			Converter = null,
			Getter = (object obj) => ((ProcessContainerUi)obj).DesktopSystemControl,
			Setter = (object obj, bool? value) =>
			{
				((ProcessContainerUi)obj).DesktopSystemControl = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "DesktopSystemControl",
			JsonPropertyName = "desktopSystemControl"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<bool?> propertyInfo2 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainerUi),
			Converter = null,
			Getter = (object obj) => ((ProcessContainerUi)obj).Ime,
			Setter = (object obj, bool? value) =>
			{
				((ProcessContainerUi)obj).Ime = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Ime",
			JsonPropertyName = "ime"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<string> propertyInfo3 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainerUi),
			Converter = null,
			Getter = (object obj) => ((ProcessContainerUi)obj).Isolation,
			Setter = (object obj, string? value) =>
			{
				((ProcessContainerUi)obj).Isolation = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Isolation",
			JsonPropertyName = "isolation"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<string> propertyInfo4 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainerUi),
			Converter = null,
			Getter = (object obj) => ((ProcessContainerUi)obj).SystemSettings,
			Setter = (object obj, string? value) =>
			{
				((ProcessContainerUi)obj).SystemSettings = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "SystemSettings",
			JsonPropertyName = "systemSettings"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		return array;
	}

	private void ProcessContainerUiSerializeHandler(Utf8JsonWriter writer, ProcessContainerUi? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		bool? desktopSystemControl = value.DesktopSystemControl;
		if (desktopSystemControl.HasValue)
		{
			writer.WritePropertyName(PropName_desktopSystemControl);
			JsonSerializer.Serialize(writer, desktopSystemControl, NullableBoolean);
		}
		bool? ime = value.Ime;
		if (ime.HasValue)
		{
			writer.WritePropertyName(PropName_ime);
			JsonSerializer.Serialize(writer, ime, NullableBoolean);
		}
		string isolation = value.Isolation;
		if (isolation != null)
		{
			writer.WriteString(PropName_isolation, isolation);
		}
		string systemSettings = value.SystemSettings;
		if (systemSettings != null)
		{
			writer.WriteString(PropName_systemSettings, systemSettings);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<RuntimeConfig> Create_RuntimeConfig(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<RuntimeConfig> jsonTypeInfo))
		{
			JsonObjectInfoValues<RuntimeConfig> objectInfo = new JsonObjectInfoValues<RuntimeConfig>
			{
				ObjectCreator = () => new RuntimeConfig(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => RuntimeConfigPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = RuntimeConfigSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] RuntimeConfigPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(RuntimeConfig),
			Converter = null,
			Getter = (object obj) => ((RuntimeConfig)obj).NetworkProxy,
			Setter = (object obj, string? value) =>
			{
				((RuntimeConfig)obj).NetworkProxy = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "NetworkProxy",
			JsonPropertyName = "networkProxy"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void RuntimeConfigSerializeHandler(Utf8JsonWriter writer, RuntimeConfig? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string networkProxy = value.NetworkProxy;
		if (networkProxy != null)
		{
			writer.WriteString(PropName_networkProxy, networkProxy);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Seatbelt> Create_Seatbelt(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Seatbelt> jsonTypeInfo))
		{
			JsonObjectInfoValues<Seatbelt> objectInfo = new JsonObjectInfoValues<Seatbelt>
			{
				ObjectCreator = () => new Seatbelt(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => SeatbeltPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = SeatbeltSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] SeatbeltPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[5];
		JsonPropertyInfoValues<List<string>> propertyInfo = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Seatbelt),
			Converter = null,
			Getter = (object obj) => ((Seatbelt)obj).ExtraMachLookups,
			Setter = (object obj, List<string>? value) =>
			{
				((Seatbelt)obj).ExtraMachLookups = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ExtraMachLookups",
			JsonPropertyName = "extraMachLookups"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<bool?> propertyInfo2 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Seatbelt),
			Converter = null,
			Getter = (object obj) => ((Seatbelt)obj).GuiAccess,
			Setter = (object obj, bool? value) =>
			{
				((Seatbelt)obj).GuiAccess = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "GuiAccess",
			JsonPropertyName = "guiAccess"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<bool?> propertyInfo3 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Seatbelt),
			Converter = null,
			Getter = (object obj) => ((Seatbelt)obj).KeychainAccess,
			Setter = (object obj, bool? value) =>
			{
				((Seatbelt)obj).KeychainAccess = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "KeychainAccess",
			JsonPropertyName = "keychainAccess"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<bool?> propertyInfo4 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Seatbelt),
			Converter = null,
			Getter = (object obj) => ((Seatbelt)obj).NestedPty,
			Setter = (object obj, bool? value) =>
			{
				((Seatbelt)obj).NestedPty = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "NestedPty",
			JsonPropertyName = "nestedPty"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		JsonPropertyInfoValues<string> propertyInfo5 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Seatbelt),
			Converter = null,
			Getter = (object obj) => ((Seatbelt)obj).ProfileOverride,
			Setter = (object obj, string? value) =>
			{
				((Seatbelt)obj).ProfileOverride = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ProfileOverride",
			JsonPropertyName = "profileOverride"
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		return array;
	}

	private void SeatbeltSerializeHandler(Utf8JsonWriter writer, Seatbelt? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		List<string> extraMachLookups = value.ExtraMachLookups;
		if (extraMachLookups != null)
		{
			writer.WritePropertyName(PropName_extraMachLookups);
			ListStringSerializeHandler(writer, extraMachLookups);
		}
		bool? guiAccess = value.GuiAccess;
		if (guiAccess.HasValue)
		{
			writer.WritePropertyName(PropName_guiAccess);
			JsonSerializer.Serialize(writer, guiAccess, NullableBoolean);
		}
		bool? keychainAccess = value.KeychainAccess;
		if (keychainAccess.HasValue)
		{
			writer.WritePropertyName(PropName_keychainAccess);
			JsonSerializer.Serialize(writer, keychainAccess, NullableBoolean);
		}
		bool? nestedPty = value.NestedPty;
		if (nestedPty.HasValue)
		{
			writer.WritePropertyName(PropName_nestedPty);
			JsonSerializer.Serialize(writer, nestedPty, NullableBoolean);
		}
		string profileOverride = value.ProfileOverride;
		if (profileOverride != null)
		{
			writer.WriteString(PropName_profileOverride, profileOverride);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Telemetry> Create_Telemetry(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Telemetry> jsonTypeInfo))
		{
			JsonObjectInfoValues<Telemetry> objectInfo = new JsonObjectInfoValues<Telemetry>
			{
				ObjectCreator = () => new Telemetry(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => TelemetryPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = TelemetrySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] TelemetryPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<bool?> propertyInfo = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Telemetry),
			Converter = null,
			Getter = (object obj) => ((Telemetry)obj).Enabled,
			Setter = (object obj, bool? value) =>
			{
				((Telemetry)obj).Enabled = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Enabled",
			JsonPropertyName = "enabled"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void TelemetrySerializeHandler(Utf8JsonWriter writer, Telemetry? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		bool? enabled = value.Enabled;
		if (enabled.HasValue)
		{
			writer.WritePropertyName(PropName_enabled);
			JsonSerializer.Serialize(writer, enabled, NullableBoolean);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Ui> Create_Ui(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Ui> jsonTypeInfo))
		{
			JsonObjectInfoValues<Ui> objectInfo = new JsonObjectInfoValues<Ui>
			{
				ObjectCreator = () => new Ui(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => UiPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = UiSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] UiPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Ui),
			Converter = null,
			Getter = (object obj) => ((Ui)obj).Clipboard,
			Setter = (object obj, string? value) =>
			{
				((Ui)obj).Clipboard = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Clipboard",
			JsonPropertyName = "clipboard"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<bool?> propertyInfo2 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Ui),
			Converter = null,
			Getter = (object obj) => ((Ui)obj).Disable,
			Setter = (object obj, bool? value) =>
			{
				((Ui)obj).Disable = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Disable",
			JsonPropertyName = "disable"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<bool?> propertyInfo3 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Ui),
			Converter = null,
			Getter = (object obj) => ((Ui)obj).Injection,
			Setter = (object obj, bool? value) =>
			{
				((Ui)obj).Injection = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Injection",
			JsonPropertyName = "injection"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void UiSerializeHandler(Utf8JsonWriter writer, Ui? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string clipboard = value.Clipboard;
		if (clipboard != null)
		{
			writer.WriteString(PropName_clipboard, clipboard);
		}
		bool? disable = value.Disable;
		if (disable.HasValue)
		{
			writer.WritePropertyName(PropName_disable);
			JsonSerializer.Serialize(writer, disable, NullableBoolean);
		}
		bool? injection = value.Injection;
		if (injection.HasValue)
		{
			writer.WritePropertyName(PropName_injection);
			JsonSerializer.Serialize(writer, injection, NullableBoolean);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<CaptureDenialsError> Create_CaptureDenialsError(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<CaptureDenialsError> jsonTypeInfo))
		{
			JsonObjectInfoValues<CaptureDenialsError> objectInfo = new JsonObjectInfoValues<CaptureDenialsError>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new CaptureDenialsError
				{
					Message = (string)args[0],
					EtlPath = (string)args[1]
				},
				PropertyMetadataInitializer = (JsonSerializerContext _) => CaptureDenialsErrorPropInit(options),
				ConstructorParameterMetadataInitializer = CaptureDenialsErrorCtorParamInit,
				SerializeHandler = CaptureDenialsErrorSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] CaptureDenialsErrorPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenialsError),
			Converter = null,
			Getter = (object obj) => ((CaptureDenialsError)obj).Message,
			Setter = (object obj, string? value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Message",
			JsonPropertyName = "message"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenialsError),
			Converter = null,
			Getter = (object obj) => ((CaptureDenialsError)obj).EtlPath,
			Setter = (object obj, string? value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "EtlPath",
			JsonPropertyName = "etlPath"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void CaptureDenialsErrorSerializeHandler(Utf8JsonWriter writer, CaptureDenialsError? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string message = value.Message;
		if (message != null)
		{
			writer.WriteString(PropName_message, message);
		}
		string etlPath = value.EtlPath;
		if (etlPath != null)
		{
			writer.WriteString(PropName_etlPath, etlPath);
		}
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] CaptureDenialsErrorCtorParamInit()
	{
		return new JsonParameterInfoValues[2]
		{
			new JsonParameterInfoValues
			{
				Name = "Message",
				ParameterType = typeof(string),
				Position = 0
			},
			new JsonParameterInfoValues
			{
				Name = "EtlPath",
				ParameterType = typeof(string),
				Position = 1
			}
		};
	}

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.CaptureDenialsMode> Create_CaptureDenialsMode(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Microsoft.Mxc.Sdk.V1.CaptureDenialsMode> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<Microsoft.Mxc.Sdk.V1.CaptureDenialsMode>(options, JsonMetadataServices.GetEnumConverter<Microsoft.Mxc.Sdk.V1.CaptureDenialsMode>(options));
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<CaptureDenialsPolicy> Create_CaptureDenialsPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<CaptureDenialsPolicy> jsonTypeInfo))
		{
			JsonObjectInfoValues<CaptureDenialsPolicy> objectInfo = new JsonObjectInfoValues<CaptureDenialsPolicy>
			{
				ObjectCreator = () => new CaptureDenialsPolicy(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => CaptureDenialsPolicyPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = CaptureDenialsPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] CaptureDenialsPolicyPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<Microsoft.Mxc.Sdk.V1.CaptureDenialsMode> propertyInfo = new JsonPropertyInfoValues<Microsoft.Mxc.Sdk.V1.CaptureDenialsMode>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenialsPolicy),
			Converter = null,
			Getter = (object obj) => ((CaptureDenialsPolicy)obj).Mode,
			Setter = (object obj, Microsoft.Mxc.Sdk.V1.CaptureDenialsMode value) =>
			{
				((CaptureDenialsPolicy)obj).Mode = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Mode",
			JsonPropertyName = "mode"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenialsPolicy),
			Converter = null,
			Getter = (object obj) => ((CaptureDenialsPolicy)obj).OutputPath,
			Setter = (object obj, string? value) =>
			{
				((CaptureDenialsPolicy)obj).OutputPath = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "OutputPath",
			JsonPropertyName = "outputPath"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<bool> propertyInfo3 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenialsPolicy),
			Converter = null,
			Getter = (object obj) => ((CaptureDenialsPolicy)obj).RetainEtl,
			Setter = (object obj, bool value) =>
			{
				((CaptureDenialsPolicy)obj).RetainEtl = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "RetainEtl",
			JsonPropertyName = "retainEtl"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void CaptureDenialsPolicySerializeHandler(Utf8JsonWriter writer, CaptureDenialsPolicy? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		writer.WritePropertyName(PropName_mode);
		JsonSerializer.Serialize(writer, value.Mode, CaptureDenialsMode);
		string outputPath = value.OutputPath;
		if (outputPath != null)
		{
			writer.WriteString(PropName_outputPath, outputPath);
		}
		writer.WriteBoolean(PropName_retainEtl, value.RetainEtl);
		writer.WriteEndObject();
	}

	private JsonTypeInfo<CaptureDenialsResult> Create_CaptureDenialsResult(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<CaptureDenialsResult> jsonTypeInfo))
		{
			JsonObjectInfoValues<CaptureDenialsResult> objectInfo = new JsonObjectInfoValues<CaptureDenialsResult>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new CaptureDenialsResult
				{
					Type = (string)args[0],
					OutputPath = (string)args[1],
					ExitCode = (int)args[2],
					TotalDenials = (ulong)args[3],
					DeniedResourcesTruncated = (bool)args[4],
					EtlPath = (string)args[5]
				},
				PropertyMetadataInitializer = (JsonSerializerContext _) => CaptureDenialsResultPropInit(options),
				ConstructorParameterMetadataInitializer = CaptureDenialsResultCtorParamInit,
				SerializeHandler = CaptureDenialsResultSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] CaptureDenialsResultPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[6];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenialsResult),
			Converter = null,
			Getter = (object obj) => ((CaptureDenialsResult)obj).Type,
			Setter = (object obj, string? value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Type",
			JsonPropertyName = "type"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenialsResult),
			Converter = null,
			Getter = (object obj) => ((CaptureDenialsResult)obj).OutputPath,
			Setter = (object obj, string? value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "OutputPath",
			JsonPropertyName = "outputPath"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<int> propertyInfo3 = new JsonPropertyInfoValues<int>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenialsResult),
			Converter = null,
			Getter = (object obj) => ((CaptureDenialsResult)obj).ExitCode,
			Setter = (object obj, int value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ExitCode",
			JsonPropertyName = "exitCode"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<ulong> propertyInfo4 = new JsonPropertyInfoValues<ulong>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenialsResult),
			Converter = null,
			Getter = (object obj) => ((CaptureDenialsResult)obj).TotalDenials,
			Setter = (object obj, ulong value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "TotalDenials",
			JsonPropertyName = "totalDenials"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		JsonPropertyInfoValues<bool> propertyInfo5 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenialsResult),
			Converter = null,
			Getter = (object obj) => ((CaptureDenialsResult)obj).DeniedResourcesTruncated,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "DeniedResourcesTruncated",
			JsonPropertyName = "deniedResourcesTruncated"
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		JsonPropertyInfoValues<string> propertyInfo6 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(CaptureDenialsResult),
			Converter = null,
			Getter = (object obj) => ((CaptureDenialsResult)obj).EtlPath,
			Setter = (object obj, string? value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "EtlPath",
			JsonPropertyName = "etlPath"
		};
		array[5] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo6);
		return array;
	}

	private void CaptureDenialsResultSerializeHandler(Utf8JsonWriter writer, CaptureDenialsResult? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string type = value.Type;
		if (type != null)
		{
			writer.WriteString(PropName_type, type);
		}
		string outputPath = value.OutputPath;
		if (outputPath != null)
		{
			writer.WriteString(PropName_outputPath, outputPath);
		}
		writer.WriteNumber(PropName_exitCode, value.ExitCode);
		writer.WriteNumber(PropName_totalDenials, value.TotalDenials);
		writer.WriteBoolean(PropName_deniedResourcesTruncated, value.DeniedResourcesTruncated);
		string etlPath = value.EtlPath;
		if (etlPath != null)
		{
			writer.WriteString(PropName_etlPath, etlPath);
		}
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] CaptureDenialsResultCtorParamInit()
	{
		return new JsonParameterInfoValues[6]
		{
			new JsonParameterInfoValues
			{
				Name = "Type",
				ParameterType = typeof(string),
				Position = 0
			},
			new JsonParameterInfoValues
			{
				Name = "OutputPath",
				ParameterType = typeof(string),
				Position = 1
			},
			new JsonParameterInfoValues
			{
				Name = "ExitCode",
				ParameterType = typeof(int),
				Position = 2
			},
			new JsonParameterInfoValues
			{
				Name = "TotalDenials",
				ParameterType = typeof(ulong),
				Position = 3
			},
			new JsonParameterInfoValues
			{
				Name = "DeniedResourcesTruncated",
				ParameterType = typeof(bool),
				Position = 4
			},
			new JsonParameterInfoValues
			{
				Name = "EtlPath",
				ParameterType = typeof(string),
				Position = 5
			}
		};
	}

	private JsonTypeInfo<ClipboardPolicy> Create_ClipboardPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ClipboardPolicy> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<ClipboardPolicy>(options, JsonMetadataServices.GetEnumConverter<ClipboardPolicy>(options));
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<ContainerId> Create_ContainerId(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ContainerId> jsonTypeInfo))
		{
			JsonObjectInfoValues<ContainerId> objectInfo = new JsonObjectInfoValues<ContainerId>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new ContainerId((string)args[0]),
				PropertyMetadataInitializer = (JsonSerializerContext _) => ContainerIdPropInit(options),
				ConstructorParameterMetadataInitializer = ContainerIdCtorParamInit,
				SerializeHandler = ContainerIdSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ContainerIdPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ContainerId),
			Converter = null,
			Getter = (object obj) => ((ContainerId)obj).Value,
			Setter = null,
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Value",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void ContainerIdSerializeHandler(Utf8JsonWriter writer, ContainerId value)
	{
		writer.WriteStartObject();
		ContainerId containerId = value;
		string value2 = containerId.Value;
		if (value2 != null)
		{
			writer.WriteString(PropName_value, value2);
		}
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] ContainerIdCtorParamInit()
	{
		return new JsonParameterInfoValues[1]
		{
			new JsonParameterInfoValues
			{
				Name = "value",
				ParameterType = typeof(string),
				Position = 0,
				HasDefaultValue = false,
				DefaultValue = null
			}
		};
	}

	private JsonTypeInfo<ContainerRequest> Create_ContainerRequest(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ContainerRequest> jsonTypeInfo))
		{
			JsonObjectInfoValues<ContainerRequest> objectInfo = new JsonObjectInfoValues<ContainerRequest>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new ContainerRequest((string)args[0]),
				PropertyMetadataInitializer = (JsonSerializerContext _) => ContainerRequestPropInit(options),
				ConstructorParameterMetadataInitializer = ContainerRequestCtorParamInit,
				SerializeHandler = ContainerRequestSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ContainerRequestPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[10];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ContainerRequest),
			Converter = null,
			Getter = (object obj) => ((ContainerRequest)obj).Command,
			Setter = null,
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Command",
			JsonPropertyName = "command"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<FilesystemPolicy> propertyInfo2 = new JsonPropertyInfoValues<FilesystemPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ContainerRequest),
			Converter = null,
			Getter = (object obj) => ((ContainerRequest)obj).Filesystem,
			Setter = (object obj, FilesystemPolicy? value) =>
			{
				((ContainerRequest)obj).Filesystem = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Filesystem",
			JsonPropertyName = "filesystem"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<NetworkPolicy> propertyInfo3 = new JsonPropertyInfoValues<NetworkPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ContainerRequest),
			Converter = null,
			Getter = (object obj) => ((ContainerRequest)obj).Network,
			Setter = (object obj, NetworkPolicy? value) =>
			{
				((ContainerRequest)obj).Network = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Network",
			JsonPropertyName = "network"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<UiPolicy> propertyInfo4 = new JsonPropertyInfoValues<UiPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ContainerRequest),
			Converter = null,
			Getter = (object obj) => ((ContainerRequest)obj).Ui,
			Setter = (object obj, UiPolicy? value) =>
			{
				((ContainerRequest)obj).Ui = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Ui",
			JsonPropertyName = "ui"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		JsonPropertyInfoValues<uint?> propertyInfo5 = new JsonPropertyInfoValues<uint?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ContainerRequest),
			Converter = null,
			Getter = (object obj) => ((ContainerRequest)obj).TimeoutMs,
			Setter = (object obj, uint? value) =>
			{
				((ContainerRequest)obj).TimeoutMs = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "TimeoutMs",
			JsonPropertyName = "timeoutMs"
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		JsonPropertyInfoValues<Containment> propertyInfo6 = new JsonPropertyInfoValues<Containment>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ContainerRequest),
			Converter = null,
			Getter = (object obj) => ((ContainerRequest)obj).Containment,
			Setter = (object obj, Containment? value) =>
			{
				((ContainerRequest)obj).Containment = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Containment",
			JsonPropertyName = "containment"
		};
		array[5] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo6);
		JsonPropertyInfoValues<string> propertyInfo7 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ContainerRequest),
			Converter = null,
			Getter = (object obj) => ((ContainerRequest)obj).ContainerName,
			Setter = (object obj, string? value) =>
			{
				((ContainerRequest)obj).ContainerName = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ContainerName",
			JsonPropertyName = "containerName"
		};
		array[6] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo7);
		JsonPropertyInfoValues<string> propertyInfo8 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ContainerRequest),
			Converter = null,
			Getter = (object obj) => ((ContainerRequest)obj).WorkingDirectory,
			Setter = (object obj, string? value) =>
			{
				((ContainerRequest)obj).WorkingDirectory = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "WorkingDirectory",
			JsonPropertyName = "workingDirectory"
		};
		array[7] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo8);
		JsonPropertyInfoValues<Dictionary<string, string>> propertyInfo9 = new JsonPropertyInfoValues<Dictionary<string, string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ContainerRequest),
			Converter = null,
			Getter = (object obj) => ((ContainerRequest)obj).Environment,
			Setter = (object obj, Dictionary<string, string>? value) =>
			{
				((ContainerRequest)obj).Environment = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Environment",
			JsonPropertyName = "environment"
		};
		array[8] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo9);
		JsonPropertyInfoValues<bool> propertyInfo10 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ContainerRequest),
			Converter = null,
			Getter = (object obj) => ((ContainerRequest)obj).InheritDefaultEnvironment,
			Setter = (object obj, bool value) =>
			{
				((ContainerRequest)obj).InheritDefaultEnvironment = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingDefault,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "InheritDefaultEnvironment",
			JsonPropertyName = "inheritDefaultEnv"
		};
		array[9] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo10);
		return array;
	}

	private void ContainerRequestSerializeHandler(Utf8JsonWriter writer, ContainerRequest? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string command = value.Command;
		if (command != null)
		{
			writer.WriteString(PropName_command, command);
		}
		FilesystemPolicy filesystem = value.Filesystem;
		if (filesystem != null)
		{
			writer.WritePropertyName(PropName_filesystem);
			FilesystemPolicySerializeHandler(writer, filesystem);
		}
		NetworkPolicy network = value.Network;
		if (network != null)
		{
			writer.WritePropertyName(PropName_network);
			NetworkPolicySerializeHandler(writer, network);
		}
		UiPolicy ui = value.Ui;
		if (ui != null)
		{
			writer.WritePropertyName(PropName_ui);
			UiPolicySerializeHandler(writer, ui);
		}
		uint? timeoutMs = value.TimeoutMs;
		if (timeoutMs.HasValue)
		{
			writer.WritePropertyName(PropName_timeoutMs);
			JsonSerializer.Serialize(writer, timeoutMs, NullableUInt32);
		}
		Containment containment = value.Containment;
		if (containment != null)
		{
			writer.WritePropertyName(PropName_containment);
			JsonSerializer.Serialize(writer, containment, Containment);
		}
		string containerName = value.ContainerName;
		if (containerName != null)
		{
			writer.WriteString(PropName_containerName, containerName);
		}
		string workingDirectory = value.WorkingDirectory;
		if (workingDirectory != null)
		{
			writer.WriteString(PropName_workingDirectory, workingDirectory);
		}
		Dictionary<string, string> environment = value.Environment;
		if (environment != null)
		{
			writer.WritePropertyName(PropName_environment);
			DictionaryStringStringSerializeHandler(writer, environment);
		}
		bool inheritDefaultEnvironment = value.InheritDefaultEnvironment;
		if (!EqualityComparer<bool>.Default.Equals(x: false, inheritDefaultEnvironment))
		{
			writer.WriteBoolean(PropName_inheritDefaultEnv, inheritDefaultEnvironment);
		}
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] ContainerRequestCtorParamInit()
	{
		return new JsonParameterInfoValues[1]
		{
			new JsonParameterInfoValues
			{
				Name = "command",
				ParameterType = typeof(string),
				Position = 0,
				HasDefaultValue = false,
				DefaultValue = null
			}
		};
	}

	private JsonTypeInfo<Containment> Create_Containment(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Containment> jsonTypeInfo))
		{
			JsonObjectInfoValues<Containment> objectInfo = new JsonObjectInfoValues<Containment>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ContainmentPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = null
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ContainmentPropInit(JsonSerializerOptions options)
	{
		return new JsonPropertyInfo[0];
	}

	private JsonTypeInfo<Containment.Bubblewrap> Create_SdkContainmentBubblewrap(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Containment.Bubblewrap> jsonTypeInfo))
		{
			JsonObjectInfoValues<Containment.Bubblewrap> objectInfo = new JsonObjectInfoValues<Containment.Bubblewrap>
			{
				ObjectCreator = () => new Containment.Bubblewrap(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => SdkContainmentBubblewrapPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = SdkContainmentBubblewrapSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] SdkContainmentBubblewrapPropInit(JsonSerializerOptions options)
	{
		return new JsonPropertyInfo[0];
	}

	private void SdkContainmentBubblewrapSerializeHandler(Utf8JsonWriter writer, Containment.Bubblewrap? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Containment.IsolationSession> Create_SdkContainmentIsolationSession(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Containment.IsolationSession> jsonTypeInfo))
		{
			JsonObjectInfoValues<Containment.IsolationSession> objectInfo = new JsonObjectInfoValues<Containment.IsolationSession>
			{
				ObjectCreator = () => new Containment.IsolationSession(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => SdkContainmentIsolationSessionPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = SdkContainmentIsolationSessionSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] SdkContainmentIsolationSessionPropInit(JsonSerializerOptions options)
	{
		return new JsonPropertyInfo[0];
	}

	private void SdkContainmentIsolationSessionSerializeHandler(Utf8JsonWriter writer, Containment.IsolationSession? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Containment.Lxc> Create_SdkContainmentLxc(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Containment.Lxc> jsonTypeInfo))
		{
			JsonObjectInfoValues<Containment.Lxc> objectInfo = new JsonObjectInfoValues<Containment.Lxc>
			{
				ObjectCreator = () => new Containment.Lxc(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => SdkContainmentLxcPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = SdkContainmentLxcSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] SdkContainmentLxcPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Lxc),
			Converter = null,
			Getter = (object obj) => ((Containment.Lxc)obj).Distribution,
			Setter = (object obj, string? value) =>
			{
				((Containment.Lxc)obj).Distribution = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Distribution",
			JsonPropertyName = "distribution"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Lxc),
			Converter = null,
			Getter = (object obj) => ((Containment.Lxc)obj).Release,
			Setter = (object obj, string? value) =>
			{
				((Containment.Lxc)obj).Release = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Release",
			JsonPropertyName = "release"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void SdkContainmentLxcSerializeHandler(Utf8JsonWriter writer, Containment.Lxc? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string distribution = value.Distribution;
		if (distribution != null)
		{
			writer.WriteString(PropName_distribution, distribution);
		}
		string release = value.Release;
		if (release != null)
		{
			writer.WriteString(PropName_release, release);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Containment.Process> Create_SdkContainmentProcess(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Containment.Process> jsonTypeInfo))
		{
			JsonObjectInfoValues<Containment.Process> objectInfo = new JsonObjectInfoValues<Containment.Process>
			{
				ObjectCreator = () => new Containment.Process(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => SdkContainmentProcessPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = SdkContainmentProcessSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] SdkContainmentProcessPropInit(JsonSerializerOptions options)
	{
		return new JsonPropertyInfo[0];
	}

	private void SdkContainmentProcessSerializeHandler(Utf8JsonWriter writer, Containment.Process? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Containment.ProcessContainer> Create_SdkContainmentProcessContainer(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Containment.ProcessContainer> jsonTypeInfo))
		{
			JsonObjectInfoValues<Containment.ProcessContainer> objectInfo = new JsonObjectInfoValues<Containment.ProcessContainer>
			{
				ObjectCreator = () => new Containment.ProcessContainer(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => SdkContainmentProcessContainerPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = SdkContainmentProcessContainerSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] SdkContainmentProcessContainerPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[6];
		JsonPropertyInfoValues<bool> propertyInfo = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.ProcessContainer),
			Converter = null,
			Getter = (object obj) => ((Containment.ProcessContainer)obj).LearningMode,
			Setter = (object obj, bool value) =>
			{
				((Containment.ProcessContainer)obj).LearningMode = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "LearningMode",
			JsonPropertyName = "learningMode"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<List<string>> propertyInfo2 = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.ProcessContainer),
			Converter = null,
			Getter = (object obj) => ((Containment.ProcessContainer)obj).Capabilities,
			Setter = (object obj, List<string>? value) =>
			{
				((Containment.ProcessContainer)obj).Capabilities = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Capabilities",
			JsonPropertyName = "capabilities"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<CaptureDenialsPolicy> propertyInfo3 = new JsonPropertyInfoValues<CaptureDenialsPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.ProcessContainer),
			Converter = null,
			Getter = (object obj) => ((Containment.ProcessContainer)obj).CaptureDenials,
			Setter = (object obj, CaptureDenialsPolicy? value) =>
			{
				((Containment.ProcessContainer)obj).CaptureDenials = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CaptureDenials",
			JsonPropertyName = "captureDenials"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<ProcessContainerUiPolicy> propertyInfo4 = new JsonPropertyInfoValues<ProcessContainerUiPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.ProcessContainer),
			Converter = null,
			Getter = (object obj) => ((Containment.ProcessContainer)obj).Ui,
			Setter = (object obj, ProcessContainerUiPolicy? value) =>
			{
				((Containment.ProcessContainer)obj).Ui = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Ui",
			JsonPropertyName = "ui"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		JsonPropertyInfoValues<ProcessContainerFilesystemPolicy> propertyInfo5 = new JsonPropertyInfoValues<ProcessContainerFilesystemPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.ProcessContainer),
			Converter = null,
			Getter = (object obj) => ((Containment.ProcessContainer)obj).Filesystem,
			Setter = (object obj, ProcessContainerFilesystemPolicy? value) =>
			{
				((Containment.ProcessContainer)obj).Filesystem = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Filesystem",
			JsonPropertyName = "filesystem"
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		JsonPropertyInfoValues<ProcessContainerNetworkPolicy> propertyInfo6 = new JsonPropertyInfoValues<ProcessContainerNetworkPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.ProcessContainer),
			Converter = null,
			Getter = (object obj) => ((Containment.ProcessContainer)obj).Network,
			Setter = (object obj, ProcessContainerNetworkPolicy? value) =>
			{
				((Containment.ProcessContainer)obj).Network = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Network",
			JsonPropertyName = "network"
		};
		array[5] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo6);
		return array;
	}

	private void SdkContainmentProcessContainerSerializeHandler(Utf8JsonWriter writer, Containment.ProcessContainer? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		writer.WriteBoolean(PropName_learningMode, value.LearningMode);
		List<string> capabilities = value.Capabilities;
		if (capabilities != null)
		{
			writer.WritePropertyName(PropName_capabilities);
			ListStringSerializeHandler(writer, capabilities);
		}
		CaptureDenialsPolicy captureDenials = value.CaptureDenials;
		if (captureDenials != null)
		{
			writer.WritePropertyName(PropName_captureDenials);
			CaptureDenialsPolicySerializeHandler(writer, captureDenials);
		}
		ProcessContainerUiPolicy ui = value.Ui;
		if (ui != null)
		{
			writer.WritePropertyName(PropName_ui);
			ProcessContainerUiPolicySerializeHandler(writer, ui);
		}
		ProcessContainerFilesystemPolicy filesystem = value.Filesystem;
		if (filesystem != null)
		{
			writer.WritePropertyName(PropName_filesystem);
			ProcessContainerFilesystemPolicySerializeHandler(writer, filesystem);
		}
		ProcessContainerNetworkPolicy network = value.Network;
		if (network != null)
		{
			writer.WritePropertyName(PropName_network);
			ProcessContainerNetworkPolicySerializeHandler(writer, network);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Containment.Seatbelt> Create_SdkContainmentSeatbelt(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Containment.Seatbelt> jsonTypeInfo))
		{
			JsonObjectInfoValues<Containment.Seatbelt> objectInfo = new JsonObjectInfoValues<Containment.Seatbelt>
			{
				ObjectCreator = () => new Containment.Seatbelt(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => SdkContainmentSeatbeltPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = SdkContainmentSeatbeltSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] SdkContainmentSeatbeltPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[5];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Seatbelt),
			Converter = null,
			Getter = (object obj) => ((Containment.Seatbelt)obj).ProfileOverride,
			Setter = (object obj, string? value) =>
			{
				((Containment.Seatbelt)obj).ProfileOverride = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ProfileOverride",
			JsonPropertyName = "profileOverride"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<bool> propertyInfo2 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Seatbelt),
			Converter = null,
			Getter = (object obj) => ((Containment.Seatbelt)obj).GuiAccess,
			Setter = (object obj, bool value) =>
			{
				((Containment.Seatbelt)obj).GuiAccess = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "GuiAccess",
			JsonPropertyName = "guiAccess"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<bool> propertyInfo3 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Seatbelt),
			Converter = null,
			Getter = (object obj) => ((Containment.Seatbelt)obj).NestedPty,
			Setter = (object obj, bool value) =>
			{
				((Containment.Seatbelt)obj).NestedPty = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "NestedPty",
			JsonPropertyName = "nestedPty"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<bool> propertyInfo4 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Seatbelt),
			Converter = null,
			Getter = (object obj) => ((Containment.Seatbelt)obj).KeychainAccess,
			Setter = (object obj, bool value) =>
			{
				((Containment.Seatbelt)obj).KeychainAccess = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "KeychainAccess",
			JsonPropertyName = "keychainAccess"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		JsonPropertyInfoValues<List<string>> propertyInfo5 = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Seatbelt),
			Converter = null,
			Getter = (object obj) => ((Containment.Seatbelt)obj).ExtraMachLookups,
			Setter = (object obj, List<string>? value) =>
			{
				((Containment.Seatbelt)obj).ExtraMachLookups = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ExtraMachLookups",
			JsonPropertyName = "extraMachLookups"
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		return array;
	}

	private void SdkContainmentSeatbeltSerializeHandler(Utf8JsonWriter writer, Containment.Seatbelt? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string profileOverride = value.ProfileOverride;
		if (profileOverride != null)
		{
			writer.WriteString(PropName_profileOverride, profileOverride);
		}
		writer.WriteBoolean(PropName_guiAccess, value.GuiAccess);
		writer.WriteBoolean(PropName_nestedPty, value.NestedPty);
		writer.WriteBoolean(PropName_keychainAccess, value.KeychainAccess);
		List<string> extraMachLookups = value.ExtraMachLookups;
		if (extraMachLookups != null)
		{
			writer.WritePropertyName(PropName_extraMachLookups);
			ListStringSerializeHandler(writer, extraMachLookups);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Containment.Wslc> Create_SdkContainmentWslc(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Containment.Wslc> jsonTypeInfo))
		{
			JsonObjectInfoValues<Containment.Wslc> objectInfo = new JsonObjectInfoValues<Containment.Wslc>
			{
				ObjectCreator = () => new Containment.Wslc(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => SdkContainmentWslcPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = SdkContainmentWslcSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] SdkContainmentWslcPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[7];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Wslc),
			Converter = null,
			Getter = (object obj) => ((Containment.Wslc)obj).Image,
			Setter = (object obj, string? value) =>
			{
				((Containment.Wslc)obj).Image = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Image",
			JsonPropertyName = "image"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Wslc),
			Converter = null,
			Getter = (object obj) => ((Containment.Wslc)obj).ImageTarPath,
			Setter = (object obj, string? value) =>
			{
				((Containment.Wslc)obj).ImageTarPath = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ImageTarPath",
			JsonPropertyName = "imageTarPath"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<uint?> propertyInfo3 = new JsonPropertyInfoValues<uint?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Wslc),
			Converter = null,
			Getter = (object obj) => ((Containment.Wslc)obj).CpuCount,
			Setter = (object obj, uint? value) =>
			{
				((Containment.Wslc)obj).CpuCount = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CpuCount",
			JsonPropertyName = "cpuCount"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<ulong?> propertyInfo4 = new JsonPropertyInfoValues<ulong?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Wslc),
			Converter = null,
			Getter = (object obj) => ((Containment.Wslc)obj).MemoryMb,
			Setter = (object obj, ulong? value) =>
			{
				((Containment.Wslc)obj).MemoryMb = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "MemoryMb",
			JsonPropertyName = "memoryMb"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		JsonPropertyInfoValues<bool> propertyInfo5 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Wslc),
			Converter = null,
			Getter = (object obj) => ((Containment.Wslc)obj).Gpu,
			Setter = (object obj, bool value) =>
			{
				((Containment.Wslc)obj).Gpu = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Gpu",
			JsonPropertyName = "gpu"
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		JsonPropertyInfoValues<string> propertyInfo6 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Wslc),
			Converter = null,
			Getter = (object obj) => ((Containment.Wslc)obj).StoragePath,
			Setter = (object obj, string? value) =>
			{
				((Containment.Wslc)obj).StoragePath = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "StoragePath",
			JsonPropertyName = "storagePath"
		};
		array[5] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo6);
		JsonPropertyInfoValues<List<WslcPortMapping>> propertyInfo7 = new JsonPropertyInfoValues<List<WslcPortMapping>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Containment.Wslc),
			Converter = null,
			Getter = (object obj) => ((Containment.Wslc)obj).PortMappings,
			Setter = (object obj, List<WslcPortMapping>? value) =>
			{
				((Containment.Wslc)obj).PortMappings = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "PortMappings",
			JsonPropertyName = "portMappings"
		};
		array[6] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo7);
		return array;
	}

	private void SdkContainmentWslcSerializeHandler(Utf8JsonWriter writer, Containment.Wslc? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string image = value.Image;
		if (image != null)
		{
			writer.WriteString(PropName_image, image);
		}
		string imageTarPath = value.ImageTarPath;
		if (imageTarPath != null)
		{
			writer.WriteString(PropName_imageTarPath, imageTarPath);
		}
		uint? cpuCount = value.CpuCount;
		if (cpuCount.HasValue)
		{
			writer.WritePropertyName(PropName_cpuCount);
			JsonSerializer.Serialize(writer, cpuCount, NullableUInt32);
		}
		ulong? memoryMb = value.MemoryMb;
		if (memoryMb.HasValue)
		{
			writer.WritePropertyName(PropName_memoryMb);
			JsonSerializer.Serialize(writer, memoryMb, NullableUInt64);
		}
		writer.WriteBoolean(PropName_gpu, value.Gpu);
		string storagePath = value.StoragePath;
		if (storagePath != null)
		{
			writer.WriteString(PropName_storagePath, storagePath);
		}
		List<WslcPortMapping> portMappings = value.PortMappings;
		if (portMappings != null)
		{
			writer.WritePropertyName(PropName_portMappings);
			ListWslcPortMappingSerializeHandler(writer, portMappings);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<DeprovisionOptions> Create_DeprovisionOptions(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<DeprovisionOptions> jsonTypeInfo))
		{
			JsonObjectInfoValues<DeprovisionOptions> objectInfo = new JsonObjectInfoValues<DeprovisionOptions>
			{
				ObjectCreator = () => new DeprovisionOptions(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => DeprovisionOptionsPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = DeprovisionOptionsSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
			jsonTypeInfo.UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] DeprovisionOptionsPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(DeprovisionOptions),
			Converter = null,
			Getter = (object obj) => ((DeprovisionOptions)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((DeprovisionOptions)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void DeprovisionOptionsSerializeHandler(Utf8JsonWriter writer, DeprovisionOptions? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		TelemetryConfig telemetry = value.Telemetry;
		if (telemetry != null)
		{
			writer.WritePropertyName(PropName_telemetry);
			TelemetryConfigSerializeHandler(writer, telemetry);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<ExecutionMetadata> Create_ExecutionMetadata(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ExecutionMetadata> jsonTypeInfo))
		{
			JsonObjectInfoValues<ExecutionMetadata> objectInfo = new JsonObjectInfoValues<ExecutionMetadata>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new ExecutionMetadata
				{
					CaptureDenials = (CaptureDenialsResult)args[0],
					CaptureDenialsError = (CaptureDenialsError)args[1]
				},
				PropertyMetadataInitializer = (JsonSerializerContext _) => ExecutionMetadataPropInit(options),
				ConstructorParameterMetadataInitializer = ExecutionMetadataCtorParamInit,
				SerializeHandler = ExecutionMetadataSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ExecutionMetadataPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<CaptureDenialsResult> propertyInfo = new JsonPropertyInfoValues<CaptureDenialsResult>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ExecutionMetadata),
			Converter = null,
			Getter = (object obj) => ((ExecutionMetadata)obj).CaptureDenials,
			Setter = (object obj, CaptureDenialsResult? value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CaptureDenials",
			JsonPropertyName = "captureDenials"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<CaptureDenialsError> propertyInfo2 = new JsonPropertyInfoValues<CaptureDenialsError>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ExecutionMetadata),
			Converter = null,
			Getter = (object obj) => ((ExecutionMetadata)obj).CaptureDenialsError,
			Setter = (object obj, CaptureDenialsError? value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CaptureDenialsError",
			JsonPropertyName = "captureDenialsError"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void ExecutionMetadataSerializeHandler(Utf8JsonWriter writer, ExecutionMetadata? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		CaptureDenialsResult captureDenials = value.CaptureDenials;
		if (captureDenials != null)
		{
			writer.WritePropertyName(PropName_captureDenials);
			CaptureDenialsResultSerializeHandler(writer, captureDenials);
		}
		CaptureDenialsError captureDenialsError = value.CaptureDenialsError;
		if (captureDenialsError != null)
		{
			writer.WritePropertyName(PropName_captureDenialsError);
			CaptureDenialsErrorSerializeHandler(writer, captureDenialsError);
		}
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] ExecutionMetadataCtorParamInit()
	{
		return new JsonParameterInfoValues[2]
		{
			new JsonParameterInfoValues
			{
				Name = "CaptureDenials",
				ParameterType = typeof(CaptureDenialsResult),
				Position = 0
			},
			new JsonParameterInfoValues
			{
				Name = "CaptureDenialsError",
				ParameterType = typeof(CaptureDenialsError),
				Position = 1
			}
		};
	}

	private JsonTypeInfo<ExecutionRequest> Create_ExecutionRequest(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ExecutionRequest> jsonTypeInfo))
		{
			JsonObjectInfoValues<ExecutionRequest> objectInfo = new JsonObjectInfoValues<ExecutionRequest>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new ExecutionRequest((string)args[0]),
				PropertyMetadataInitializer = (JsonSerializerContext _) => ExecutionRequestPropInit(options),
				ConstructorParameterMetadataInitializer = ExecutionRequestCtorParamInit,
				SerializeHandler = ExecutionRequestSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
			jsonTypeInfo.UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ExecutionRequestPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[7];
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ExecutionRequest),
			Converter = null,
			Getter = (object obj) => ((ExecutionRequest)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((ExecutionRequest)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ExecutionRequest),
			Converter = null,
			Getter = (object obj) => ((ExecutionRequest)obj).Command,
			Setter = null,
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Command",
			JsonPropertyName = null
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<string> propertyInfo3 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ExecutionRequest),
			Converter = null,
			Getter = (object obj) => ((ExecutionRequest)obj).WorkingDirectory,
			Setter = (object obj, string? value) =>
			{
				((ExecutionRequest)obj).WorkingDirectory = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "WorkingDirectory",
			JsonPropertyName = null
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<Dictionary<string, string>> propertyInfo4 = new JsonPropertyInfoValues<Dictionary<string, string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ExecutionRequest),
			Converter = null,
			Getter = (object obj) => ((ExecutionRequest)obj).Environment,
			Setter = (object obj, Dictionary<string, string>? value) =>
			{
				((ExecutionRequest)obj).Environment = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Environment",
			JsonPropertyName = null
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		JsonPropertyInfoValues<bool?> propertyInfo5 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ExecutionRequest),
			Converter = null,
			Getter = (object obj) => ((ExecutionRequest)obj).InheritDefaultEnvironment,
			Setter = (object obj, bool? value) =>
			{
				((ExecutionRequest)obj).InheritDefaultEnvironment = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "InheritDefaultEnvironment",
			JsonPropertyName = null
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		JsonPropertyInfoValues<uint?> propertyInfo6 = new JsonPropertyInfoValues<uint?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ExecutionRequest),
			Converter = null,
			Getter = (object obj) => ((ExecutionRequest)obj).TimeoutMs,
			Setter = (object obj, uint? value) =>
			{
				((ExecutionRequest)obj).TimeoutMs = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "TimeoutMs",
			JsonPropertyName = null
		};
		array[5] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo6);
		JsonPropertyInfoValues<ProcessNetworkPolicy> propertyInfo7 = new JsonPropertyInfoValues<ProcessNetworkPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ExecutionRequest),
			Converter = null,
			Getter = (object obj) => ((ExecutionRequest)obj).Network,
			Setter = (object obj, ProcessNetworkPolicy? value) =>
			{
				((ExecutionRequest)obj).Network = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Network",
			JsonPropertyName = null
		};
		array[6] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo7);
		return array;
	}

	private void ExecutionRequestSerializeHandler(Utf8JsonWriter writer, ExecutionRequest? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		TelemetryConfig telemetry = value.Telemetry;
		if (telemetry != null)
		{
			writer.WritePropertyName(PropName_telemetry);
			TelemetryConfigSerializeHandler(writer, telemetry);
		}
		string command = value.Command;
		if (command != null)
		{
			writer.WriteString(PropName_command, command);
		}
		string workingDirectory = value.WorkingDirectory;
		if (workingDirectory != null)
		{
			writer.WriteString(PropName_workingDirectory, workingDirectory);
		}
		Dictionary<string, string> environment = value.Environment;
		if (environment != null)
		{
			writer.WritePropertyName(PropName_environment);
			DictionaryStringStringSerializeHandler(writer, environment);
		}
		bool? inheritDefaultEnvironment = value.InheritDefaultEnvironment;
		if (inheritDefaultEnvironment.HasValue)
		{
			writer.WritePropertyName(PropName_inheritDefaultEnvironment);
			JsonSerializer.Serialize(writer, inheritDefaultEnvironment, NullableBoolean);
		}
		uint? timeoutMs = value.TimeoutMs;
		if (timeoutMs.HasValue)
		{
			writer.WritePropertyName(PropName_timeoutMs);
			JsonSerializer.Serialize(writer, timeoutMs, NullableUInt32);
		}
		ProcessNetworkPolicy network = value.Network;
		if (network != null)
		{
			writer.WritePropertyName(PropName_network);
			ProcessNetworkPolicySerializeHandler(writer, network);
		}
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] ExecutionRequestCtorParamInit()
	{
		return new JsonParameterInfoValues[1]
		{
			new JsonParameterInfoValues
			{
				Name = "command",
				ParameterType = typeof(string),
				Position = 0,
				HasDefaultValue = false,
				DefaultValue = null
			}
		};
	}

	private JsonTypeInfo<FilesystemPolicy> Create_FilesystemPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<FilesystemPolicy> jsonTypeInfo))
		{
			JsonObjectInfoValues<FilesystemPolicy> objectInfo = new JsonObjectInfoValues<FilesystemPolicy>
			{
				ObjectCreator = () => new FilesystemPolicy(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => FilesystemPolicyPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = FilesystemPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] FilesystemPolicyPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[4];
		JsonPropertyInfoValues<List<string>> propertyInfo = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(FilesystemPolicy),
			Converter = null,
			Getter = (object obj) => ((FilesystemPolicy)obj).ReadwritePaths,
			Setter = (object obj, List<string>? value) =>
			{
				((FilesystemPolicy)obj).ReadwritePaths = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ReadwritePaths",
			JsonPropertyName = "readwritePaths"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<List<string>> propertyInfo2 = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(FilesystemPolicy),
			Converter = null,
			Getter = (object obj) => ((FilesystemPolicy)obj).ReadonlyPaths,
			Setter = (object obj, List<string>? value) =>
			{
				((FilesystemPolicy)obj).ReadonlyPaths = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ReadonlyPaths",
			JsonPropertyName = "readonlyPaths"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<List<string>> propertyInfo3 = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(FilesystemPolicy),
			Converter = null,
			Getter = (object obj) => ((FilesystemPolicy)obj).DeniedPaths,
			Setter = (object obj, List<string>? value) =>
			{
				((FilesystemPolicy)obj).DeniedPaths = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "DeniedPaths",
			JsonPropertyName = "deniedPaths"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<bool?> propertyInfo4 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(FilesystemPolicy),
			Converter = null,
			Getter = (object obj) => ((FilesystemPolicy)obj).ClearPolicyOnExit,
			Setter = (object obj, bool? value) =>
			{
				((FilesystemPolicy)obj).ClearPolicyOnExit = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ClearPolicyOnExit",
			JsonPropertyName = "clearPolicyOnExit"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		return array;
	}

	private void FilesystemPolicySerializeHandler(Utf8JsonWriter writer, FilesystemPolicy? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		List<string> readwritePaths = value.ReadwritePaths;
		if (readwritePaths != null)
		{
			writer.WritePropertyName(PropName_readwritePaths);
			ListStringSerializeHandler(writer, readwritePaths);
		}
		List<string> readonlyPaths = value.ReadonlyPaths;
		if (readonlyPaths != null)
		{
			writer.WritePropertyName(PropName_readonlyPaths);
			ListStringSerializeHandler(writer, readonlyPaths);
		}
		List<string> deniedPaths = value.DeniedPaths;
		if (deniedPaths != null)
		{
			writer.WritePropertyName(PropName_deniedPaths);
			ListStringSerializeHandler(writer, deniedPaths);
		}
		bool? clearPolicyOnExit = value.ClearPolicyOnExit;
		if (clearPolicyOnExit.HasValue)
		{
			writer.WritePropertyName(PropName_clearPolicyOnExit);
			JsonSerializer.Serialize(writer, clearPolicyOnExit, NullableBoolean);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<IsolationSessionProvisionMetadata> Create_IsolationSessionProvisionMetadata(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<IsolationSessionProvisionMetadata> jsonTypeInfo))
		{
			JsonObjectInfoValues<IsolationSessionProvisionMetadata> objectInfo = new JsonObjectInfoValues<IsolationSessionProvisionMetadata>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new IsolationSessionProvisionMetadata
				{
					AgentUserName = (string)args[0],
					AgentUserSid = (string)args[1],
					EphemeralWorkspacePath = (string)args[2]
				},
				PropertyMetadataInitializer = (JsonSerializerContext _) => IsolationSessionProvisionMetadataPropInit(options),
				ConstructorParameterMetadataInitializer = IsolationSessionProvisionMetadataCtorParamInit,
				SerializeHandler = IsolationSessionProvisionMetadataSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] IsolationSessionProvisionMetadataPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(IsolationSessionProvisionMetadata),
			Converter = null,
			Getter = (object obj) => ((IsolationSessionProvisionMetadata)obj).AgentUserName,
			Setter = (object obj, string? value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "AgentUserName",
			JsonPropertyName = "agentUserName"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		array[0].IsRequired = true;
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(IsolationSessionProvisionMetadata),
			Converter = null,
			Getter = (object obj) => ((IsolationSessionProvisionMetadata)obj).AgentUserSid,
			Setter = (object obj, string? value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "AgentUserSid",
			JsonPropertyName = "agentUserSid"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		array[1].IsRequired = true;
		JsonPropertyInfoValues<string> propertyInfo3 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(IsolationSessionProvisionMetadata),
			Converter = null,
			Getter = (object obj) => ((IsolationSessionProvisionMetadata)obj).EphemeralWorkspacePath,
			Setter = (object obj, string? value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "EphemeralWorkspacePath",
			JsonPropertyName = "ephemeralWorkspacePath"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		array[2].IsRequired = true;
		return array;
	}

	private void IsolationSessionProvisionMetadataSerializeHandler(Utf8JsonWriter writer, IsolationSessionProvisionMetadata? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string agentUserName = value.AgentUserName;
		if (agentUserName != null)
		{
			writer.WriteString(PropName_agentUserName, agentUserName);
		}
		string agentUserSid = value.AgentUserSid;
		if (agentUserSid != null)
		{
			writer.WriteString(PropName_agentUserSid, agentUserSid);
		}
		string ephemeralWorkspacePath = value.EphemeralWorkspacePath;
		if (ephemeralWorkspacePath != null)
		{
			writer.WriteString(PropName_ephemeralWorkspacePath, ephemeralWorkspacePath);
		}
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] IsolationSessionProvisionMetadataCtorParamInit()
	{
		return new JsonParameterInfoValues[3]
		{
			new JsonParameterInfoValues
			{
				Name = "AgentUserName",
				ParameterType = typeof(string),
				Position = 0
			},
			new JsonParameterInfoValues
			{
				Name = "AgentUserSid",
				ParameterType = typeof(string),
				Position = 1
			},
			new JsonParameterInfoValues
			{
				Name = "EphemeralWorkspacePath",
				ParameterType = typeof(string),
				Position = 2
			}
		};
	}

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest> Create_IsolationSessionProvisionRequest(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest> jsonTypeInfo))
		{
			JsonObjectInfoValues<Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest> objectInfo = new JsonObjectInfoValues<Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest((NetworkPolicy)args[0]),
				PropertyMetadataInitializer = (JsonSerializerContext _) => IsolationSessionProvisionRequestPropInit(options),
				ConstructorParameterMetadataInitializer = IsolationSessionProvisionRequestCtorParamInit,
				SerializeHandler = IsolationSessionProvisionRequestSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
			jsonTypeInfo.UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] IsolationSessionProvisionRequestPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<NetworkPolicy> propertyInfo = new JsonPropertyInfoValues<NetworkPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest),
			Converter = null,
			Getter = (object obj) => ((Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest)obj).Network,
			Setter = (object obj, NetworkPolicy? value) =>
			{
				((Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest)obj).Network = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Network",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest),
			Converter = null,
			Getter = (object obj) => ((Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest)obj).AppId,
			Setter = (object obj, string? value) =>
			{
				((Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest)obj).AppId = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "AppId",
			JsonPropertyName = null
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo3 = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProvisionRequest),
			Converter = null,
			Getter = (object obj) => ((ProvisionRequest)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((ProvisionRequest)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void IsolationSessionProvisionRequestSerializeHandler(Utf8JsonWriter writer, Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		NetworkPolicy network = value.Network;
		if (network != null)
		{
			writer.WritePropertyName(PropName_network);
			NetworkPolicySerializeHandler(writer, network);
		}
		string appId = value.AppId;
		if (appId != null)
		{
			writer.WriteString(PropName_appId, appId);
		}
		TelemetryConfig telemetry = value.Telemetry;
		if (telemetry != null)
		{
			writer.WritePropertyName(PropName_telemetry);
			TelemetryConfigSerializeHandler(writer, telemetry);
		}
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] IsolationSessionProvisionRequestCtorParamInit()
	{
		return new JsonParameterInfoValues[1]
		{
			new JsonParameterInfoValues
			{
				Name = "network",
				ParameterType = typeof(NetworkPolicy),
				Position = 0,
				HasDefaultValue = false,
				DefaultValue = null
			}
		};
	}

	private JsonTypeInfo<LifecycleResult> Create_LifecycleResult(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<LifecycleResult> jsonTypeInfo))
		{
			JsonObjectInfoValues<LifecycleResult> objectInfo = new JsonObjectInfoValues<LifecycleResult>
			{
				ObjectCreator = () => new LifecycleResult(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => LifecycleResultPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = LifecycleResultSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] LifecycleResultPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<string[]> propertyInfo = new JsonPropertyInfoValues<string[]>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(LifecycleResult),
			Converter = null,
			Getter = (object obj) => ((LifecycleResult)obj).Warnings,
			Setter = (object obj, string[]? value) =>
			{
				((LifecycleResult)obj).Warnings = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Warnings",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void LifecycleResultSerializeHandler(Utf8JsonWriter writer, LifecycleResult? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string[] warnings = value.Warnings;
		if (warnings != null)
		{
			writer.WritePropertyName(PropName_warnings);
			StringArraySerializeHandler(writer, warnings);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<MxcPtySize> Create_MxcPtySize(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<MxcPtySize> jsonTypeInfo))
		{
			JsonObjectInfoValues<MxcPtySize> objectInfo = new JsonObjectInfoValues<MxcPtySize>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new MxcPtySize
				{
					Rows = (ushort)args[0],
					Columns = (ushort)args[1]
				},
				PropertyMetadataInitializer = (JsonSerializerContext _) => MxcPtySizePropInit(options),
				ConstructorParameterMetadataInitializer = MxcPtySizeCtorParamInit,
				SerializeHandler = MxcPtySizeSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] MxcPtySizePropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<ushort> propertyInfo = new JsonPropertyInfoValues<ushort>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(MxcPtySize),
			Converter = null,
			Getter = (object obj) => ((MxcPtySize)obj).Rows,
			Setter = (object obj, ushort value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Rows",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<ushort> propertyInfo2 = new JsonPropertyInfoValues<ushort>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(MxcPtySize),
			Converter = null,
			Getter = (object obj) => ((MxcPtySize)obj).Columns,
			Setter = (object obj, ushort value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Columns",
			JsonPropertyName = null
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void MxcPtySizeSerializeHandler(Utf8JsonWriter writer, MxcPtySize value)
	{
		writer.WriteStartObject();
		JsonEncodedText propName_rows = PropName_rows;
		MxcPtySize mxcPtySize = value;
		writer.WriteNumber(propName_rows, mxcPtySize.Rows);
		JsonEncodedText propName_columns = PropName_columns;
		mxcPtySize = value;
		writer.WriteNumber(propName_columns, mxcPtySize.Columns);
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] MxcPtySizeCtorParamInit()
	{
		return new JsonParameterInfoValues[2]
		{
			new JsonParameterInfoValues
			{
				Name = "Rows",
				ParameterType = typeof(ushort),
				Position = 0
			},
			new JsonParameterInfoValues
			{
				Name = "Columns",
				ParameterType = typeof(ushort),
				Position = 1
			}
		};
	}

	private JsonTypeInfo<MxcPtySize?> Create_NullableMxcPtySize(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<MxcPtySize?> jsonTypeInfo))
		{
			JsonConverter nullableConverter = JsonMetadataServices.GetNullableConverter<MxcPtySize>(options);
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<MxcPtySize?>(options, nullableConverter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<NativeAvailableBackend> Create_NativeAvailableBackend(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NativeAvailableBackend> jsonTypeInfo))
		{
			JsonObjectInfoValues<NativeAvailableBackend> objectInfo = new JsonObjectInfoValues<NativeAvailableBackend>
			{
				ObjectCreator = () => new NativeAvailableBackend(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NativeAvailableBackendPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NativeAvailableBackendSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NativeAvailableBackendPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[4];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeAvailableBackend),
			Converter = null,
			Getter = (object obj) => ((NativeAvailableBackend)obj).Backend,
			Setter = (object obj, string? value) =>
			{
				((NativeAvailableBackend)obj).Backend = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Backend",
			JsonPropertyName = "backend"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeAvailableBackend),
			Converter = null,
			Getter = (object obj) => ((NativeAvailableBackend)obj).Tier,
			Setter = (object obj, string? value) =>
			{
				((NativeAvailableBackend)obj).Tier = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Tier",
			JsonPropertyName = "tier"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<string[]> propertyInfo3 = new JsonPropertyInfoValues<string[]>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeAvailableBackend),
			Converter = null,
			Getter = (object obj) => ((NativeAvailableBackend)obj).Capabilities,
			Setter = (object obj, string[]? value) =>
			{
				((NativeAvailableBackend)obj).Capabilities = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Capabilities",
			JsonPropertyName = "capabilities"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<string[]> propertyInfo4 = new JsonPropertyInfoValues<string[]>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeAvailableBackend),
			Converter = null,
			Getter = (object obj) => ((NativeAvailableBackend)obj).Warnings,
			Setter = (object obj, string[]? value) =>
			{
				((NativeAvailableBackend)obj).Warnings = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Warnings",
			JsonPropertyName = "warnings"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		return array;
	}

	private void NativeAvailableBackendSerializeHandler(Utf8JsonWriter writer, NativeAvailableBackend? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string backend = value.Backend;
		if (backend != null)
		{
			writer.WriteString(PropName_backend, backend);
		}
		string tier = value.Tier;
		if (tier != null)
		{
			writer.WriteString(PropName_tier, tier);
		}
		string[] capabilities = value.Capabilities;
		if (capabilities != null)
		{
			writer.WritePropertyName(PropName_capabilities);
			StringArraySerializeHandler(writer, capabilities);
		}
		string[] warnings = value.Warnings;
		if (warnings != null)
		{
			writer.WritePropertyName(PropName_warnings);
			StringArraySerializeHandler(writer, warnings);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<NativeAvailableBackend[]> Create_NativeAvailableBackendArray(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NativeAvailableBackend[]> jsonTypeInfo))
		{
			JsonCollectionInfoValues<NativeAvailableBackend[]> collectionInfo = new JsonCollectionInfoValues<NativeAvailableBackend[]>
			{
				ObjectCreator = null,
				SerializeHandler = NativeAvailableBackendArraySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateArrayInfo(options, collectionInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private void NativeAvailableBackendArraySerializeHandler(Utf8JsonWriter writer, NativeAvailableBackend[]? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartArray();
		for (int i = 0; i < value.Length; i++)
		{
			NativeAvailableBackendSerializeHandler(writer, value[i]);
		}
		writer.WriteEndArray();
	}

	private JsonTypeInfo<NativePlatformSupport> Create_NativePlatformSupport(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NativePlatformSupport> jsonTypeInfo))
		{
			JsonObjectInfoValues<NativePlatformSupport> objectInfo = new JsonObjectInfoValues<NativePlatformSupport>
			{
				ObjectCreator = () => new NativePlatformSupport(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NativePlatformSupportPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NativePlatformSupportSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NativePlatformSupportPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<bool> propertyInfo = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativePlatformSupport),
			Converter = null,
			Getter = (object obj) => ((NativePlatformSupport)obj).IsSupported,
			Setter = (object obj, bool value) =>
			{
				((NativePlatformSupport)obj).IsSupported = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "IsSupported",
			JsonPropertyName = "isSupported"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<string> propertyInfo2 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativePlatformSupport),
			Converter = null,
			Getter = (object obj) => ((NativePlatformSupport)obj).Reason,
			Setter = (object obj, string? value) =>
			{
				((NativePlatformSupport)obj).Reason = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Reason",
			JsonPropertyName = "reason"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<string[]> propertyInfo3 = new JsonPropertyInfoValues<string[]>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativePlatformSupport),
			Converter = null,
			Getter = (object obj) => ((NativePlatformSupport)obj).AvailableMethods,
			Setter = (object obj, string[]? value) =>
			{
				((NativePlatformSupport)obj).AvailableMethods = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "AvailableMethods",
			JsonPropertyName = "availableMethods"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void NativePlatformSupportSerializeHandler(Utf8JsonWriter writer, NativePlatformSupport? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		writer.WriteBoolean(PropName_isSupported, value.IsSupported);
		string reason = value.Reason;
		if (reason != null)
		{
			writer.WriteString(PropName_reason, reason);
		}
		string[] availableMethods = value.AvailableMethods;
		if (availableMethods != null)
		{
			writer.WritePropertyName(PropName_availableMethods);
			StringArraySerializeHandler(writer, availableMethods);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<NativeProbeFacts> Create_NativeProbeFacts(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NativeProbeFacts> jsonTypeInfo))
		{
			JsonObjectInfoValues<NativeProbeFacts> objectInfo = new JsonObjectInfoValues<NativeProbeFacts>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new NativeProbeFacts
				{
					BaseContainerApiPresent = (bool)args[0],
					NativeCaptureAvailable = (bool)args[1],
					GuardedCaptureAvailable = (bool)args[2],
					BfscfgPresent = (bool)args[3],
					BfsCompiledIn = (bool)args[4],
					BaseContainerSupportsDenyPaths = (bool)args[5],
					BaseContainerSupportsEnumeratePaths = (bool)args[6],
					BaseContainerSupportsIngressHostLoopbackAllow = (bool)args[7],
					BaseContainerSupportsIdentitylessLoopbackProxy = (bool)args[8],
					IsolationSessionAvailable = (bool)args[9],
					HyperlightAvailable = (bool)args[10],
					UiCapabilities = (NativeUiCapabilitySupport)args[11]
				},
				PropertyMetadataInitializer = (JsonSerializerContext _) => NativeProbeFactsPropInit(options),
				ConstructorParameterMetadataInitializer = NativeProbeFactsCtorParamInit,
				SerializeHandler = NativeProbeFactsSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NativeProbeFactsPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[12];
		JsonPropertyInfoValues<bool> propertyInfo = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeFacts),
			Converter = null,
			Getter = (object obj) => ((NativeProbeFacts)obj).BaseContainerApiPresent,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "BaseContainerApiPresent",
			JsonPropertyName = "baseContainerApiPresent"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		array[0].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo2 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeFacts),
			Converter = null,
			Getter = (object obj) => ((NativeProbeFacts)obj).NativeCaptureAvailable,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "NativeCaptureAvailable",
			JsonPropertyName = "nativeCaptureAvailable"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		array[1].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo3 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeFacts),
			Converter = null,
			Getter = (object obj) => ((NativeProbeFacts)obj).GuardedCaptureAvailable,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "GuardedCaptureAvailable",
			JsonPropertyName = "guardedCaptureAvailable"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		array[2].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo4 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeFacts),
			Converter = null,
			Getter = (object obj) => ((NativeProbeFacts)obj).BfscfgPresent,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "BfscfgPresent",
			JsonPropertyName = "bfscfgPresent"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		array[3].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo5 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeFacts),
			Converter = null,
			Getter = (object obj) => ((NativeProbeFacts)obj).BfsCompiledIn,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "BfsCompiledIn",
			JsonPropertyName = "bfsCompiledIn"
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		array[4].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo6 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeFacts),
			Converter = null,
			Getter = (object obj) => ((NativeProbeFacts)obj).BaseContainerSupportsDenyPaths,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "BaseContainerSupportsDenyPaths",
			JsonPropertyName = "baseContainerSupportsDenyPaths"
		};
		array[5] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo6);
		array[5].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo7 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeFacts),
			Converter = null,
			Getter = (object obj) => ((NativeProbeFacts)obj).BaseContainerSupportsEnumeratePaths,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "BaseContainerSupportsEnumeratePaths",
			JsonPropertyName = "baseContainerSupportsEnumeratePaths"
		};
		array[6] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo7);
		array[6].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo8 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeFacts),
			Converter = null,
			Getter = (object obj) => ((NativeProbeFacts)obj).BaseContainerSupportsIngressHostLoopbackAllow,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "BaseContainerSupportsIngressHostLoopbackAllow",
			JsonPropertyName = "baseContainerSupportsIngressHostLoopbackAllow"
		};
		array[7] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo8);
		array[7].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo9 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeFacts),
			Converter = null,
			Getter = (object obj) => ((NativeProbeFacts)obj).BaseContainerSupportsIdentitylessLoopbackProxy,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "BaseContainerSupportsIdentitylessLoopbackProxy",
			JsonPropertyName = "baseContainerSupportsIdentitylessLoopbackProxy"
		};
		array[8] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo9);
		array[8].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo10 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeFacts),
			Converter = null,
			Getter = (object obj) => ((NativeProbeFacts)obj).IsolationSessionAvailable,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "IsolationSessionAvailable",
			JsonPropertyName = "isolationSessionAvailable"
		};
		array[9] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo10);
		array[9].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo11 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeFacts),
			Converter = null,
			Getter = (object obj) => ((NativeProbeFacts)obj).HyperlightAvailable,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "HyperlightAvailable",
			JsonPropertyName = "hyperlightAvailable"
		};
		array[10] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo11);
		array[10].IsRequired = true;
		JsonPropertyInfoValues<NativeUiCapabilitySupport> propertyInfo12 = new JsonPropertyInfoValues<NativeUiCapabilitySupport>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeFacts),
			Converter = null,
			Getter = (object obj) => ((NativeProbeFacts)obj).UiCapabilities,
			Setter = (object obj, NativeUiCapabilitySupport? value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "UiCapabilities",
			JsonPropertyName = "uiCapabilities"
		};
		array[11] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo12);
		array[11].IsRequired = true;
		return array;
	}

	private void NativeProbeFactsSerializeHandler(Utf8JsonWriter writer, NativeProbeFacts? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		writer.WriteBoolean(PropName_baseContainerApiPresent, value.BaseContainerApiPresent);
		writer.WriteBoolean(PropName_nativeCaptureAvailable, value.NativeCaptureAvailable);
		writer.WriteBoolean(PropName_guardedCaptureAvailable, value.GuardedCaptureAvailable);
		writer.WriteBoolean(PropName_bfscfgPresent, value.BfscfgPresent);
		writer.WriteBoolean(PropName_bfsCompiledIn, value.BfsCompiledIn);
		writer.WriteBoolean(PropName_baseContainerSupportsDenyPaths, value.BaseContainerSupportsDenyPaths);
		writer.WriteBoolean(PropName_baseContainerSupportsEnumeratePaths, value.BaseContainerSupportsEnumeratePaths);
		writer.WriteBoolean(PropName_baseContainerSupportsIngressHostLoopbackAllow, value.BaseContainerSupportsIngressHostLoopbackAllow);
		writer.WriteBoolean(PropName_baseContainerSupportsIdentitylessLoopbackProxy, value.BaseContainerSupportsIdentitylessLoopbackProxy);
		writer.WriteBoolean(PropName_isolationSessionAvailable, value.IsolationSessionAvailable);
		writer.WriteBoolean(PropName_hyperlightAvailable, value.HyperlightAvailable);
		NativeUiCapabilitySupport uiCapabilities = value.UiCapabilities;
		if (uiCapabilities != null)
		{
			writer.WritePropertyName(PropName_uiCapabilities);
			NativeUiCapabilitySupportSerializeHandler(writer, uiCapabilities);
		}
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] NativeProbeFactsCtorParamInit()
	{
		return new JsonParameterInfoValues[12]
		{
			new JsonParameterInfoValues
			{
				Name = "BaseContainerApiPresent",
				ParameterType = typeof(bool),
				Position = 0
			},
			new JsonParameterInfoValues
			{
				Name = "NativeCaptureAvailable",
				ParameterType = typeof(bool),
				Position = 1
			},
			new JsonParameterInfoValues
			{
				Name = "GuardedCaptureAvailable",
				ParameterType = typeof(bool),
				Position = 2
			},
			new JsonParameterInfoValues
			{
				Name = "BfscfgPresent",
				ParameterType = typeof(bool),
				Position = 3
			},
			new JsonParameterInfoValues
			{
				Name = "BfsCompiledIn",
				ParameterType = typeof(bool),
				Position = 4
			},
			new JsonParameterInfoValues
			{
				Name = "BaseContainerSupportsDenyPaths",
				ParameterType = typeof(bool),
				Position = 5
			},
			new JsonParameterInfoValues
			{
				Name = "BaseContainerSupportsEnumeratePaths",
				ParameterType = typeof(bool),
				Position = 6
			},
			new JsonParameterInfoValues
			{
				Name = "BaseContainerSupportsIngressHostLoopbackAllow",
				ParameterType = typeof(bool),
				Position = 7
			},
			new JsonParameterInfoValues
			{
				Name = "BaseContainerSupportsIdentitylessLoopbackProxy",
				ParameterType = typeof(bool),
				Position = 8
			},
			new JsonParameterInfoValues
			{
				Name = "IsolationSessionAvailable",
				ParameterType = typeof(bool),
				Position = 9
			},
			new JsonParameterInfoValues
			{
				Name = "HyperlightAvailable",
				ParameterType = typeof(bool),
				Position = 10
			},
			new JsonParameterInfoValues
			{
				Name = "UiCapabilities",
				ParameterType = typeof(NativeUiCapabilitySupport),
				Position = 11
			}
		};
	}

	private JsonTypeInfo<NativeProbeOutput> Create_NativeProbeOutput(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NativeProbeOutput> jsonTypeInfo))
		{
			JsonObjectInfoValues<NativeProbeOutput> objectInfo = new JsonObjectInfoValues<NativeProbeOutput>
			{
				ObjectCreator = () => new NativeProbeOutput(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NativeProbeOutputPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NativeProbeOutputSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NativeProbeOutputPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[5];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeOutput),
			Converter = null,
			Getter = (object obj) => ((NativeProbeOutput)obj).Tier,
			Setter = (object obj, string? value) =>
			{
				((NativeProbeOutput)obj).Tier = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Tier",
			JsonPropertyName = "tier"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<bool?> propertyInfo2 = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeOutput),
			Converter = null,
			Getter = (object obj) => ((NativeProbeOutput)obj).NeedsDaclAugmentation,
			Setter = (object obj, bool? value) =>
			{
				((NativeProbeOutput)obj).NeedsDaclAugmentation = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "NeedsDaclAugmentation",
			JsonPropertyName = "needsDaclAugmentation"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<string[]> propertyInfo3 = new JsonPropertyInfoValues<string[]>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeOutput),
			Converter = null,
			Getter = (object obj) => ((NativeProbeOutput)obj).Warnings,
			Setter = (object obj, string[]? value) =>
			{
				((NativeProbeOutput)obj).Warnings = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Warnings",
			JsonPropertyName = "warnings"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		array[2].IsRequired = true;
		JsonPropertyInfoValues<NativeProbeFacts> propertyInfo4 = new JsonPropertyInfoValues<NativeProbeFacts>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeOutput),
			Converter = null,
			Getter = (object obj) => ((NativeProbeOutput)obj).Probes,
			Setter = (object obj, NativeProbeFacts? value) =>
			{
				((NativeProbeOutput)obj).Probes = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Probes",
			JsonPropertyName = "probes"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		array[3].IsRequired = true;
		JsonPropertyInfoValues<string> propertyInfo5 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeProbeOutput),
			Converter = null,
			Getter = (object obj) => ((NativeProbeOutput)obj).Error,
			Setter = (object obj, string? value) =>
			{
				((NativeProbeOutput)obj).Error = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Error",
			JsonPropertyName = "error"
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		return array;
	}

	private void NativeProbeOutputSerializeHandler(Utf8JsonWriter writer, NativeProbeOutput? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string tier = value.Tier;
		if (tier != null)
		{
			writer.WriteString(PropName_tier, tier);
		}
		bool? needsDaclAugmentation = value.NeedsDaclAugmentation;
		if (needsDaclAugmentation.HasValue)
		{
			writer.WritePropertyName(PropName_needsDaclAugmentation);
			JsonSerializer.Serialize(writer, needsDaclAugmentation, NullableBoolean);
		}
		string[] warnings = value.Warnings;
		if (warnings != null)
		{
			writer.WritePropertyName(PropName_warnings);
			StringArraySerializeHandler(writer, warnings);
		}
		NativeProbeFacts probes = value.Probes;
		if (probes != null)
		{
			writer.WritePropertyName(PropName_probes);
			NativeProbeFactsSerializeHandler(writer, probes);
		}
		string error = value.Error;
		if (error != null)
		{
			writer.WriteString(PropName_error, error);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<NativeUiCapabilitySupport> Create_NativeUiCapabilitySupport(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NativeUiCapabilitySupport> jsonTypeInfo))
		{
			JsonObjectInfoValues<NativeUiCapabilitySupport> objectInfo = new JsonObjectInfoValues<NativeUiCapabilitySupport>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new NativeUiCapabilitySupport
				{
					CanBlockClipboardRead = (bool)args[0],
					CanBlockClipboardWrite = (bool)args[1],
					CanBlockInputInjection = (bool)args[2],
					CanBlockInputMethodChanges = (bool)args[3],
					CanBlockExternalUiObjects = (bool)args[4],
					CanBlockGlobalUiNamespace = (bool)args[5],
					CanBlockDesktopSwitching = (bool)args[6],
					CanBlockLogoffOrShutdown = (bool)args[7],
					CanBlockSystemParameterChanges = (bool)args[8],
					CanBlockDisplaySettingsChanges = (bool)args[9]
				},
				PropertyMetadataInitializer = (JsonSerializerContext _) => NativeUiCapabilitySupportPropInit(options),
				ConstructorParameterMetadataInitializer = NativeUiCapabilitySupportCtorParamInit,
				SerializeHandler = NativeUiCapabilitySupportSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NativeUiCapabilitySupportPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[10];
		JsonPropertyInfoValues<bool> propertyInfo = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeUiCapabilitySupport),
			Converter = null,
			Getter = (object obj) => ((NativeUiCapabilitySupport)obj).CanBlockClipboardRead,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CanBlockClipboardRead",
			JsonPropertyName = "canBlockClipboardRead"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		array[0].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo2 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeUiCapabilitySupport),
			Converter = null,
			Getter = (object obj) => ((NativeUiCapabilitySupport)obj).CanBlockClipboardWrite,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CanBlockClipboardWrite",
			JsonPropertyName = "canBlockClipboardWrite"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		array[1].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo3 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeUiCapabilitySupport),
			Converter = null,
			Getter = (object obj) => ((NativeUiCapabilitySupport)obj).CanBlockInputInjection,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CanBlockInputInjection",
			JsonPropertyName = "canBlockInputInjection"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		array[2].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo4 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeUiCapabilitySupport),
			Converter = null,
			Getter = (object obj) => ((NativeUiCapabilitySupport)obj).CanBlockInputMethodChanges,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CanBlockInputMethodChanges",
			JsonPropertyName = "canBlockInputMethodChanges"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		array[3].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo5 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeUiCapabilitySupport),
			Converter = null,
			Getter = (object obj) => ((NativeUiCapabilitySupport)obj).CanBlockExternalUiObjects,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CanBlockExternalUiObjects",
			JsonPropertyName = "canBlockExternalUiObjects"
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		array[4].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo6 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeUiCapabilitySupport),
			Converter = null,
			Getter = (object obj) => ((NativeUiCapabilitySupport)obj).CanBlockGlobalUiNamespace,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CanBlockGlobalUiNamespace",
			JsonPropertyName = "canBlockGlobalUiNamespace"
		};
		array[5] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo6);
		array[5].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo7 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeUiCapabilitySupport),
			Converter = null,
			Getter = (object obj) => ((NativeUiCapabilitySupport)obj).CanBlockDesktopSwitching,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CanBlockDesktopSwitching",
			JsonPropertyName = "canBlockDesktopSwitching"
		};
		array[6] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo7);
		array[6].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo8 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeUiCapabilitySupport),
			Converter = null,
			Getter = (object obj) => ((NativeUiCapabilitySupport)obj).CanBlockLogoffOrShutdown,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CanBlockLogoffOrShutdown",
			JsonPropertyName = "canBlockLogoffOrShutdown"
		};
		array[7] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo8);
		array[7].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo9 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeUiCapabilitySupport),
			Converter = null,
			Getter = (object obj) => ((NativeUiCapabilitySupport)obj).CanBlockSystemParameterChanges,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CanBlockSystemParameterChanges",
			JsonPropertyName = "canBlockSystemParameterChanges"
		};
		array[8] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo9);
		array[8].IsRequired = true;
		JsonPropertyInfoValues<bool> propertyInfo10 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NativeUiCapabilitySupport),
			Converter = null,
			Getter = (object obj) => ((NativeUiCapabilitySupport)obj).CanBlockDisplaySettingsChanges,
			Setter = (object obj, bool value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "CanBlockDisplaySettingsChanges",
			JsonPropertyName = "canBlockDisplaySettingsChanges"
		};
		array[9] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo10);
		array[9].IsRequired = true;
		return array;
	}

	private void NativeUiCapabilitySupportSerializeHandler(Utf8JsonWriter writer, NativeUiCapabilitySupport? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		writer.WriteBoolean(PropName_canBlockClipboardRead, value.CanBlockClipboardRead);
		writer.WriteBoolean(PropName_canBlockClipboardWrite, value.CanBlockClipboardWrite);
		writer.WriteBoolean(PropName_canBlockInputInjection, value.CanBlockInputInjection);
		writer.WriteBoolean(PropName_canBlockInputMethodChanges, value.CanBlockInputMethodChanges);
		writer.WriteBoolean(PropName_canBlockExternalUiObjects, value.CanBlockExternalUiObjects);
		writer.WriteBoolean(PropName_canBlockGlobalUiNamespace, value.CanBlockGlobalUiNamespace);
		writer.WriteBoolean(PropName_canBlockDesktopSwitching, value.CanBlockDesktopSwitching);
		writer.WriteBoolean(PropName_canBlockLogoffOrShutdown, value.CanBlockLogoffOrShutdown);
		writer.WriteBoolean(PropName_canBlockSystemParameterChanges, value.CanBlockSystemParameterChanges);
		writer.WriteBoolean(PropName_canBlockDisplaySettingsChanges, value.CanBlockDisplaySettingsChanges);
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] NativeUiCapabilitySupportCtorParamInit()
	{
		return new JsonParameterInfoValues[10]
		{
			new JsonParameterInfoValues
			{
				Name = "CanBlockClipboardRead",
				ParameterType = typeof(bool),
				Position = 0
			},
			new JsonParameterInfoValues
			{
				Name = "CanBlockClipboardWrite",
				ParameterType = typeof(bool),
				Position = 1
			},
			new JsonParameterInfoValues
			{
				Name = "CanBlockInputInjection",
				ParameterType = typeof(bool),
				Position = 2
			},
			new JsonParameterInfoValues
			{
				Name = "CanBlockInputMethodChanges",
				ParameterType = typeof(bool),
				Position = 3
			},
			new JsonParameterInfoValues
			{
				Name = "CanBlockExternalUiObjects",
				ParameterType = typeof(bool),
				Position = 4
			},
			new JsonParameterInfoValues
			{
				Name = "CanBlockGlobalUiNamespace",
				ParameterType = typeof(bool),
				Position = 5
			},
			new JsonParameterInfoValues
			{
				Name = "CanBlockDesktopSwitching",
				ParameterType = typeof(bool),
				Position = 6
			},
			new JsonParameterInfoValues
			{
				Name = "CanBlockLogoffOrShutdown",
				ParameterType = typeof(bool),
				Position = 7
			},
			new JsonParameterInfoValues
			{
				Name = "CanBlockSystemParameterChanges",
				ParameterType = typeof(bool),
				Position = 8
			},
			new JsonParameterInfoValues
			{
				Name = "CanBlockDisplaySettingsChanges",
				ParameterType = typeof(bool),
				Position = 9
			}
		};
	}

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkAction> Create_NetworkAction(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkAction> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<Microsoft.Mxc.Sdk.V1.NetworkAction>(options, JsonMetadataServices.GetEnumConverter<Microsoft.Mxc.Sdk.V1.NetworkAction>(options));
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkAction?> Create_NullableNetworkAction(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkAction?> jsonTypeInfo))
		{
			JsonConverter nullableConverter = JsonMetadataServices.GetNullableConverter<Microsoft.Mxc.Sdk.V1.NetworkAction>(options);
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<Microsoft.Mxc.Sdk.V1.NetworkAction?>(options, nullableConverter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<NetworkEgressPolicy> Create_NetworkEgressPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NetworkEgressPolicy> jsonTypeInfo))
		{
			JsonObjectInfoValues<NetworkEgressPolicy> objectInfo = new JsonObjectInfoValues<NetworkEgressPolicy>
			{
				ObjectCreator = () => new NetworkEgressPolicy(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NetworkEgressPolicyPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NetworkEgressPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NetworkEgressPolicyPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<Microsoft.Mxc.Sdk.V1.NetworkAction?> propertyInfo = new JsonPropertyInfoValues<Microsoft.Mxc.Sdk.V1.NetworkAction?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkEgressPolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkEgressPolicy)obj).Default,
			Setter = (object obj, Microsoft.Mxc.Sdk.V1.NetworkAction? value) =>
			{
				((NetworkEgressPolicy)obj).Default = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Default",
			JsonPropertyName = "default"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<List<NetworkRulePolicy>> propertyInfo2 = new JsonPropertyInfoValues<List<NetworkRulePolicy>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkEgressPolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkEgressPolicy)obj).Allow,
			Setter = (object obj, List<NetworkRulePolicy>? value) =>
			{
				((NetworkEgressPolicy)obj).Allow = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Allow",
			JsonPropertyName = "allow"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<List<NetworkRulePolicy>> propertyInfo3 = new JsonPropertyInfoValues<List<NetworkRulePolicy>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkEgressPolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkEgressPolicy)obj).Deny,
			Setter = (object obj, List<NetworkRulePolicy>? value) =>
			{
				((NetworkEgressPolicy)obj).Deny = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Deny",
			JsonPropertyName = "deny"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void NetworkEgressPolicySerializeHandler(Utf8JsonWriter writer, NetworkEgressPolicy? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		Microsoft.Mxc.Sdk.V1.NetworkAction? value2 = value.Default;
		if (value2.HasValue)
		{
			writer.WritePropertyName(PropName_default);
			JsonSerializer.Serialize(writer, value2, NullableNetworkAction);
		}
		List<NetworkRulePolicy> allow = value.Allow;
		if (allow != null)
		{
			writer.WritePropertyName(PropName_allow);
			ListNetworkRulePolicySerializeHandler(writer, allow);
		}
		List<NetworkRulePolicy> deny = value.Deny;
		if (deny != null)
		{
			writer.WritePropertyName(PropName_deny);
			ListNetworkRulePolicySerializeHandler(writer, deny);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<NetworkIngressPolicy> Create_NetworkIngressPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NetworkIngressPolicy> jsonTypeInfo))
		{
			JsonObjectInfoValues<NetworkIngressPolicy> objectInfo = new JsonObjectInfoValues<NetworkIngressPolicy>
			{
				ObjectCreator = () => new NetworkIngressPolicy(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NetworkIngressPolicyPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NetworkIngressPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NetworkIngressPolicyPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<Microsoft.Mxc.Sdk.V1.NetworkAction?> propertyInfo = new JsonPropertyInfoValues<Microsoft.Mxc.Sdk.V1.NetworkAction?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkIngressPolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkIngressPolicy)obj).Default,
			Setter = (object obj, Microsoft.Mxc.Sdk.V1.NetworkAction? value) =>
			{
				((NetworkIngressPolicy)obj).Default = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Default",
			JsonPropertyName = "default"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<Microsoft.Mxc.Sdk.V1.NetworkAction?> propertyInfo2 = new JsonPropertyInfoValues<Microsoft.Mxc.Sdk.V1.NetworkAction?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkIngressPolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkIngressPolicy)obj).HostLoopback,
			Setter = (object obj, Microsoft.Mxc.Sdk.V1.NetworkAction? value) =>
			{
				((NetworkIngressPolicy)obj).HostLoopback = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "HostLoopback",
			JsonPropertyName = "hostLoopback"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void NetworkIngressPolicySerializeHandler(Utf8JsonWriter writer, NetworkIngressPolicy? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		Microsoft.Mxc.Sdk.V1.NetworkAction? value2 = value.Default;
		if (value2.HasValue)
		{
			writer.WritePropertyName(PropName_default);
			JsonSerializer.Serialize(writer, value2, NullableNetworkAction);
		}
		Microsoft.Mxc.Sdk.V1.NetworkAction? hostLoopback = value.HostLoopback;
		if (hostLoopback.HasValue)
		{
			writer.WritePropertyName(PropName_hostLoopback);
			JsonSerializer.Serialize(writer, hostLoopback, NullableNetworkAction);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<NetworkPeerPolicy> Create_NetworkPeerPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NetworkPeerPolicy> jsonTypeInfo))
		{
			JsonObjectInfoValues<NetworkPeerPolicy> objectInfo = new JsonObjectInfoValues<NetworkPeerPolicy>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new NetworkPeerPolicy((string)args[0]),
				PropertyMetadataInitializer = (JsonSerializerContext _) => NetworkPeerPolicyPropInit(options),
				ConstructorParameterMetadataInitializer = NetworkPeerPolicyCtorParamInit,
				SerializeHandler = NetworkPeerPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NetworkPeerPolicyPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkPeerPolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkPeerPolicy)obj).Cidr,
			Setter = null,
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Cidr",
			JsonPropertyName = "cidr"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<List<string>> propertyInfo2 = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkPeerPolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkPeerPolicy)obj).Except,
			Setter = (object obj, List<string>? value) =>
			{
				((NetworkPeerPolicy)obj).Except = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Except",
			JsonPropertyName = "except"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void NetworkPeerPolicySerializeHandler(Utf8JsonWriter writer, NetworkPeerPolicy? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string cidr = value.Cidr;
		if (cidr != null)
		{
			writer.WriteString(PropName_cidr, cidr);
		}
		List<string> except = value.Except;
		if (except != null)
		{
			writer.WritePropertyName(PropName_except);
			ListStringSerializeHandler(writer, except);
		}
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] NetworkPeerPolicyCtorParamInit()
	{
		return new JsonParameterInfoValues[1]
		{
			new JsonParameterInfoValues
			{
				Name = "cidr",
				ParameterType = typeof(string),
				Position = 0,
				HasDefaultValue = false,
				DefaultValue = null
			}
		};
	}

	private JsonTypeInfo<NetworkPolicy> Create_NetworkPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NetworkPolicy> jsonTypeInfo))
		{
			JsonObjectInfoValues<NetworkPolicy> objectInfo = new JsonObjectInfoValues<NetworkPolicy>
			{
				ObjectCreator = () => new NetworkPolicy(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NetworkPolicyPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NetworkPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
			jsonTypeInfo.UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NetworkPolicyPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<NetworkEgressPolicy> propertyInfo = new JsonPropertyInfoValues<NetworkEgressPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkPolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkPolicy)obj).Egress,
			Setter = (object obj, NetworkEgressPolicy? value) =>
			{
				((NetworkPolicy)obj).Egress = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Egress",
			JsonPropertyName = "egress"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<NetworkIngressPolicy> propertyInfo2 = new JsonPropertyInfoValues<NetworkIngressPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkPolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkPolicy)obj).Ingress,
			Setter = (object obj, NetworkIngressPolicy? value) =>
			{
				((NetworkPolicy)obj).Ingress = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Ingress",
			JsonPropertyName = "ingress"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<NetworkRuntimeConfig> propertyInfo3 = new JsonPropertyInfoValues<NetworkRuntimeConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkPolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkPolicy)obj).RuntimeConfig,
			Setter = (object obj, NetworkRuntimeConfig? value) =>
			{
				((NetworkPolicy)obj).RuntimeConfig = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "RuntimeConfig",
			JsonPropertyName = "runtimeConfig"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void NetworkPolicySerializeHandler(Utf8JsonWriter writer, NetworkPolicy? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		NetworkEgressPolicy egress = value.Egress;
		if (egress != null)
		{
			writer.WritePropertyName(PropName_egress);
			NetworkEgressPolicySerializeHandler(writer, egress);
		}
		NetworkIngressPolicy ingress = value.Ingress;
		if (ingress != null)
		{
			writer.WritePropertyName(PropName_ingress);
			NetworkIngressPolicySerializeHandler(writer, ingress);
		}
		NetworkRuntimeConfig runtimeConfig = value.RuntimeConfig;
		if (runtimeConfig != null)
		{
			writer.WritePropertyName(PropName_runtimeConfig);
			NetworkRuntimeConfigSerializeHandler(writer, runtimeConfig);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<NetworkPortPolicy> Create_NetworkPortPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NetworkPortPolicy> jsonTypeInfo))
		{
			JsonObjectInfoValues<NetworkPortPolicy> objectInfo = new JsonObjectInfoValues<NetworkPortPolicy>
			{
				ObjectCreator = () => new NetworkPortPolicy(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NetworkPortPolicyPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NetworkPortPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NetworkPortPolicyPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<Microsoft.Mxc.Sdk.V1.NetworkProtocol?> propertyInfo = new JsonPropertyInfoValues<Microsoft.Mxc.Sdk.V1.NetworkProtocol?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkPortPolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkPortPolicy)obj).Protocol,
			Setter = (object obj, Microsoft.Mxc.Sdk.V1.NetworkProtocol? value) =>
			{
				((NetworkPortPolicy)obj).Protocol = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Protocol",
			JsonPropertyName = "protocol"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<ushort?> propertyInfo2 = new JsonPropertyInfoValues<ushort?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkPortPolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkPortPolicy)obj).Port,
			Setter = (object obj, ushort? value) =>
			{
				((NetworkPortPolicy)obj).Port = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Port",
			JsonPropertyName = "port"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<ushort?> propertyInfo3 = new JsonPropertyInfoValues<ushort?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkPortPolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkPortPolicy)obj).EndPort,
			Setter = (object obj, ushort? value) =>
			{
				((NetworkPortPolicy)obj).EndPort = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "EndPort",
			JsonPropertyName = "endPort"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void NetworkPortPolicySerializeHandler(Utf8JsonWriter writer, NetworkPortPolicy? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		Microsoft.Mxc.Sdk.V1.NetworkProtocol? protocol = value.Protocol;
		if (protocol.HasValue)
		{
			writer.WritePropertyName(PropName_protocol);
			JsonSerializer.Serialize(writer, protocol, NullableNetworkProtocol);
		}
		ushort? port = value.Port;
		if (port.HasValue)
		{
			writer.WritePropertyName(PropName_port);
			JsonSerializer.Serialize(writer, port, NullableUInt16);
		}
		ushort? endPort = value.EndPort;
		if (endPort.HasValue)
		{
			writer.WritePropertyName(PropName_endPort);
			JsonSerializer.Serialize(writer, endPort, NullableUInt16);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkProtocol> Create_NetworkProtocol(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkProtocol> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<Microsoft.Mxc.Sdk.V1.NetworkProtocol>(options, JsonMetadataServices.GetEnumConverter<Microsoft.Mxc.Sdk.V1.NetworkProtocol>(options));
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkProtocol?> Create_NullableNetworkProtocol(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Microsoft.Mxc.Sdk.V1.NetworkProtocol?> jsonTypeInfo))
		{
			JsonConverter nullableConverter = JsonMetadataServices.GetNullableConverter<Microsoft.Mxc.Sdk.V1.NetworkProtocol>(options);
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<Microsoft.Mxc.Sdk.V1.NetworkProtocol?>(options, nullableConverter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<NetworkRulePolicy> Create_NetworkRulePolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NetworkRulePolicy> jsonTypeInfo))
		{
			JsonObjectInfoValues<NetworkRulePolicy> objectInfo = new JsonObjectInfoValues<NetworkRulePolicy>
			{
				ObjectCreator = () => new NetworkRulePolicy(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NetworkRulePolicyPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NetworkRulePolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NetworkRulePolicyPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<List<NetworkPeerPolicy>> propertyInfo = new JsonPropertyInfoValues<List<NetworkPeerPolicy>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkRulePolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkRulePolicy)obj).To,
			Setter = (object obj, List<NetworkPeerPolicy>? value) =>
			{
				((NetworkRulePolicy)obj).To = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "To",
			JsonPropertyName = "to"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<List<NetworkPortPolicy>> propertyInfo2 = new JsonPropertyInfoValues<List<NetworkPortPolicy>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkRulePolicy),
			Converter = null,
			Getter = (object obj) => ((NetworkRulePolicy)obj).Ports,
			Setter = (object obj, List<NetworkPortPolicy>? value) =>
			{
				((NetworkRulePolicy)obj).Ports = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Ports",
			JsonPropertyName = "ports"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void NetworkRulePolicySerializeHandler(Utf8JsonWriter writer, NetworkRulePolicy? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		List<NetworkPeerPolicy> to = value.To;
		if (to != null)
		{
			writer.WritePropertyName(PropName_to);
			ListNetworkPeerPolicySerializeHandler(writer, to);
		}
		List<NetworkPortPolicy> ports = value.Ports;
		if (ports != null)
		{
			writer.WritePropertyName(PropName_ports);
			ListNetworkPortPolicySerializeHandler(writer, ports);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<NetworkRuntimeConfig> Create_NetworkRuntimeConfig(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<NetworkRuntimeConfig> jsonTypeInfo))
		{
			JsonObjectInfoValues<NetworkRuntimeConfig> objectInfo = new JsonObjectInfoValues<NetworkRuntimeConfig>
			{
				ObjectCreator = () => new NetworkRuntimeConfig(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => NetworkRuntimeConfigPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = NetworkRuntimeConfigSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] NetworkRuntimeConfigPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(NetworkRuntimeConfig),
			Converter = null,
			Getter = (object obj) => ((NetworkRuntimeConfig)obj).NetworkProxy,
			Setter = (object obj, string? value) =>
			{
				((NetworkRuntimeConfig)obj).NetworkProxy = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "NetworkProxy",
			JsonPropertyName = "networkProxy"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void NetworkRuntimeConfigSerializeHandler(Utf8JsonWriter writer, NetworkRuntimeConfig? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string networkProxy = value.NetworkProxy;
		if (networkProxy != null)
		{
			writer.WriteString(PropName_networkProxy, networkProxy);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<ProcessContainerFilesystemPolicy> Create_ProcessContainerFilesystemPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ProcessContainerFilesystemPolicy> jsonTypeInfo))
		{
			JsonObjectInfoValues<ProcessContainerFilesystemPolicy> objectInfo = new JsonObjectInfoValues<ProcessContainerFilesystemPolicy>
			{
				ObjectCreator = () => new ProcessContainerFilesystemPolicy(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ProcessContainerFilesystemPolicyPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = ProcessContainerFilesystemPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ProcessContainerFilesystemPolicyPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<List<string>> propertyInfo = new JsonPropertyInfoValues<List<string>>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainerFilesystemPolicy),
			Converter = null,
			Getter = (object obj) => ((ProcessContainerFilesystemPolicy)obj).EnumeratePaths,
			Setter = (object obj, List<string>? value) =>
			{
				((ProcessContainerFilesystemPolicy)obj).EnumeratePaths = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "EnumeratePaths",
			JsonPropertyName = "enumeratePaths"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void ProcessContainerFilesystemPolicySerializeHandler(Utf8JsonWriter writer, ProcessContainerFilesystemPolicy? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		List<string> enumeratePaths = value.EnumeratePaths;
		if (enumeratePaths != null)
		{
			writer.WritePropertyName(PropName_enumeratePaths);
			ListStringSerializeHandler(writer, enumeratePaths);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<ProcessContainerNetworkPolicy> Create_ProcessContainerNetworkPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ProcessContainerNetworkPolicy> jsonTypeInfo))
		{
			JsonObjectInfoValues<ProcessContainerNetworkPolicy> objectInfo = new JsonObjectInfoValues<ProcessContainerNetworkPolicy>
			{
				ObjectCreator = () => new ProcessContainerNetworkPolicy(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ProcessContainerNetworkPolicyPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = ProcessContainerNetworkPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ProcessContainerNetworkPolicyPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<string> propertyInfo = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainerNetworkPolicy),
			Converter = null,
			Getter = (object obj) => ((ProcessContainerNetworkPolicy)obj).AllowedProxyPeer,
			Setter = (object obj, string? value) =>
			{
				((ProcessContainerNetworkPolicy)obj).AllowedProxyPeer = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "AllowedProxyPeer",
			JsonPropertyName = "allowedProxyPeer"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void ProcessContainerNetworkPolicySerializeHandler(Utf8JsonWriter writer, ProcessContainerNetworkPolicy? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string allowedProxyPeer = value.AllowedProxyPeer;
		if (allowedProxyPeer != null)
		{
			writer.WriteString(PropName_allowedProxyPeer, allowedProxyPeer);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<ProcessContainerSystemSettings> Create_ProcessContainerSystemSettings(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ProcessContainerSystemSettings> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<ProcessContainerSystemSettings>(options, JsonMetadataServices.GetEnumConverter<ProcessContainerSystemSettings>(options));
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation> Create_ProcessContainerUiIsolation(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation>(options, JsonMetadataServices.GetEnumConverter<Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation>(options));
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<ProcessContainerUiPolicy> Create_ProcessContainerUiPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ProcessContainerUiPolicy> jsonTypeInfo))
		{
			JsonObjectInfoValues<ProcessContainerUiPolicy> objectInfo = new JsonObjectInfoValues<ProcessContainerUiPolicy>
			{
				ObjectCreator = () => new ProcessContainerUiPolicy(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ProcessContainerUiPolicyPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = ProcessContainerUiPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ProcessContainerUiPolicyPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[4];
		JsonPropertyInfoValues<Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation> propertyInfo = new JsonPropertyInfoValues<Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainerUiPolicy),
			Converter = null,
			Getter = (object obj) => ((ProcessContainerUiPolicy)obj).Isolation,
			Setter = (object obj, Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation value) =>
			{
				((ProcessContainerUiPolicy)obj).Isolation = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Isolation",
			JsonPropertyName = "isolation"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<bool> propertyInfo2 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainerUiPolicy),
			Converter = null,
			Getter = (object obj) => ((ProcessContainerUiPolicy)obj).DesktopSystemControl,
			Setter = (object obj, bool value) =>
			{
				((ProcessContainerUiPolicy)obj).DesktopSystemControl = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "DesktopSystemControl",
			JsonPropertyName = "desktopSystemControl"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<ProcessContainerSystemSettings> propertyInfo3 = new JsonPropertyInfoValues<ProcessContainerSystemSettings>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainerUiPolicy),
			Converter = null,
			Getter = (object obj) => ((ProcessContainerUiPolicy)obj).SystemSettings,
			Setter = (object obj, ProcessContainerSystemSettings value) =>
			{
				((ProcessContainerUiPolicy)obj).SystemSettings = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "SystemSettings",
			JsonPropertyName = "systemSettings"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<bool> propertyInfo4 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessContainerUiPolicy),
			Converter = null,
			Getter = (object obj) => ((ProcessContainerUiPolicy)obj).Ime,
			Setter = (object obj, bool value) =>
			{
				((ProcessContainerUiPolicy)obj).Ime = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Ime",
			JsonPropertyName = "ime"
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		return array;
	}

	private void ProcessContainerUiPolicySerializeHandler(Utf8JsonWriter writer, ProcessContainerUiPolicy? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		writer.WritePropertyName(PropName_isolation);
		JsonSerializer.Serialize(writer, value.Isolation, ProcessContainerUiIsolation);
		writer.WriteBoolean(PropName_desktopSystemControl, value.DesktopSystemControl);
		writer.WritePropertyName(PropName_systemSettings);
		JsonSerializer.Serialize(writer, value.SystemSettings, ProcessContainerSystemSettings);
		writer.WriteBoolean(PropName_ime, value.Ime);
		writer.WriteEndObject();
	}

	private JsonTypeInfo<ProcessNetworkPolicy> Create_ProcessNetworkPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ProcessNetworkPolicy> jsonTypeInfo))
		{
			JsonObjectInfoValues<ProcessNetworkPolicy> objectInfo = new JsonObjectInfoValues<ProcessNetworkPolicy>
			{
				ObjectCreator = () => new ProcessNetworkPolicy(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ProcessNetworkPolicyPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = ProcessNetworkPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ProcessNetworkPolicyPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<NetworkRuntimeConfig> propertyInfo = new JsonPropertyInfoValues<NetworkRuntimeConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProcessNetworkPolicy),
			Converter = null,
			Getter = (object obj) => ((ProcessNetworkPolicy)obj).RuntimeConfig,
			Setter = (object obj, NetworkRuntimeConfig? value) =>
			{
				((ProcessNetworkPolicy)obj).RuntimeConfig = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "RuntimeConfig",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void ProcessNetworkPolicySerializeHandler(Utf8JsonWriter writer, ProcessNetworkPolicy? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		NetworkRuntimeConfig runtimeConfig = value.RuntimeConfig;
		if (runtimeConfig != null)
		{
			writer.WritePropertyName(PropName_runtimeConfig);
			NetworkRuntimeConfigSerializeHandler(writer, runtimeConfig);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<ProvisionMetadata> Create_ProvisionMetadata(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ProvisionMetadata> jsonTypeInfo))
		{
			JsonObjectInfoValues<ProvisionMetadata> objectInfo = new JsonObjectInfoValues<ProvisionMetadata>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ProvisionMetadataPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = null
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ProvisionMetadataPropInit(JsonSerializerOptions options)
	{
		return new JsonPropertyInfo[0];
	}

	private JsonTypeInfo<ProvisionOptions> Create_ProvisionOptions(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ProvisionOptions> jsonTypeInfo))
		{
			JsonObjectInfoValues<ProvisionOptions> objectInfo = new JsonObjectInfoValues<ProvisionOptions>
			{
				ObjectCreator = () => new ProvisionOptions(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ProvisionOptionsPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = ProvisionOptionsSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
			jsonTypeInfo.UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ProvisionOptionsPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProvisionOptions),
			Converter = null,
			Getter = (object obj) => ((ProvisionOptions)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((ProvisionOptions)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void ProvisionOptionsSerializeHandler(Utf8JsonWriter writer, ProvisionOptions? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		TelemetryConfig telemetry = value.Telemetry;
		if (telemetry != null)
		{
			writer.WritePropertyName(PropName_telemetry);
			TelemetryConfigSerializeHandler(writer, telemetry);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<ProvisionRequest> Create_ProvisionRequest(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ProvisionRequest> jsonTypeInfo))
		{
			JsonObjectInfoValues<ProvisionRequest> objectInfo = new JsonObjectInfoValues<ProvisionRequest>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ProvisionRequestPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = null
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ProvisionRequestPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProvisionRequest),
			Converter = null,
			Getter = (object obj) => ((ProvisionRequest)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((ProvisionRequest)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private JsonTypeInfo<ProvisionResult> Create_ProvisionResult(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ProvisionResult> jsonTypeInfo))
		{
			JsonObjectInfoValues<ProvisionResult> objectInfo = new JsonObjectInfoValues<ProvisionResult>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new ProvisionResult
				{
					ContainerId = (ContainerId)args[0],
					Metadata = (ProvisionMetadata)args[1]
				},
				PropertyMetadataInitializer = (JsonSerializerContext _) => ProvisionResultPropInit(options),
				ConstructorParameterMetadataInitializer = ProvisionResultCtorParamInit,
				SerializeHandler = ProvisionResultSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ProvisionResultPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<ContainerId> propertyInfo = new JsonPropertyInfoValues<ContainerId>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProvisionResult),
			Converter = null,
			Getter = (object obj) => ((ProvisionResult)obj).ContainerId,
			Setter = (object obj, ContainerId value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ContainerId",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<ProvisionMetadata> propertyInfo2 = new JsonPropertyInfoValues<ProvisionMetadata>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProvisionResult),
			Converter = null,
			Getter = (object obj) => ((ProvisionResult)obj).Metadata,
			Setter = (object obj, ProvisionMetadata? value) =>
			{
				throw new InvalidOperationException("Setting init-only properties is not supported in source generation mode.");
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Metadata",
			JsonPropertyName = null
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<string[]> propertyInfo3 = new JsonPropertyInfoValues<string[]>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProvisionResult),
			Converter = null,
			Getter = (object obj) => ((ProvisionResult)obj).Warnings,
			Setter = (object obj, string[]? value) =>
			{
				((ProvisionResult)obj).Warnings = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Warnings",
			JsonPropertyName = null
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void ProvisionResultSerializeHandler(Utf8JsonWriter writer, ProvisionResult? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		writer.WritePropertyName(PropName_containerId);
		ContainerIdSerializeHandler(writer, value.ContainerId);
		ProvisionMetadata metadata = value.Metadata;
		if (metadata != null)
		{
			writer.WritePropertyName(PropName_metadata);
			JsonSerializer.Serialize(writer, metadata, ProvisionMetadata);
		}
		string[] warnings = value.Warnings;
		if (warnings != null)
		{
			writer.WritePropertyName(PropName_warnings);
			StringArraySerializeHandler(writer, warnings);
		}
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] ProvisionResultCtorParamInit()
	{
		return new JsonParameterInfoValues[2]
		{
			new JsonParameterInfoValues
			{
				Name = "ContainerId",
				ParameterType = typeof(ContainerId),
				Position = 0
			},
			new JsonParameterInfoValues
			{
				Name = "Metadata",
				ParameterType = typeof(ProvisionMetadata),
				Position = 1
			}
		};
	}

	private JsonTypeInfo<RunInContainerOptions> Create_RunInContainerOptions(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<RunInContainerOptions> jsonTypeInfo))
		{
			JsonObjectInfoValues<RunInContainerOptions> objectInfo = new JsonObjectInfoValues<RunInContainerOptions>
			{
				ObjectCreator = () => new RunInContainerOptions(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => RunInContainerOptionsPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = RunInContainerOptionsSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] RunInContainerOptionsPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(RunInContainerOptions),
			Converter = null,
			Getter = (object obj) => ((RunInContainerOptions)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((RunInContainerOptions)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void RunInContainerOptionsSerializeHandler(Utf8JsonWriter writer, RunInContainerOptions? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		TelemetryConfig telemetry = value.Telemetry;
		if (telemetry != null)
		{
			writer.WritePropertyName(PropName_telemetry);
			TelemetryConfigSerializeHandler(writer, telemetry);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<RunOptions> Create_RunOptions(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<RunOptions> jsonTypeInfo))
		{
			JsonObjectInfoValues<RunOptions> objectInfo = new JsonObjectInfoValues<RunOptions>
			{
				ObjectCreator = () => new RunOptions(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => RunOptionsPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = RunOptionsSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] RunOptionsPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(RunOptions),
			Converter = null,
			Getter = (object obj) => ((RunOptions)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((RunOptions)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void RunOptionsSerializeHandler(Utf8JsonWriter writer, RunOptions? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		TelemetryConfig telemetry = value.Telemetry;
		if (telemetry != null)
		{
			writer.WritePropertyName(PropName_telemetry);
			TelemetryConfigSerializeHandler(writer, telemetry);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<SpawnInContainerOptions> Create_SpawnInContainerOptions(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<SpawnInContainerOptions> jsonTypeInfo))
		{
			JsonObjectInfoValues<SpawnInContainerOptions> objectInfo = new JsonObjectInfoValues<SpawnInContainerOptions>
			{
				ObjectCreator = () => new SpawnInContainerOptions(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => SpawnInContainerOptionsPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = SpawnInContainerOptionsSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] SpawnInContainerOptionsPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(SpawnInContainerOptions),
			Converter = null,
			Getter = (object obj) => ((SpawnInContainerOptions)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((SpawnInContainerOptions)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void SpawnInContainerOptionsSerializeHandler(Utf8JsonWriter writer, SpawnInContainerOptions? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		TelemetryConfig telemetry = value.Telemetry;
		if (telemetry != null)
		{
			writer.WritePropertyName(PropName_telemetry);
			TelemetryConfigSerializeHandler(writer, telemetry);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<SpawnInContainerWithPtyOptions> Create_SpawnInContainerWithPtyOptions(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<SpawnInContainerWithPtyOptions> jsonTypeInfo))
		{
			JsonObjectInfoValues<SpawnInContainerWithPtyOptions> objectInfo = new JsonObjectInfoValues<SpawnInContainerWithPtyOptions>
			{
				ObjectCreator = () => new SpawnInContainerWithPtyOptions(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => SpawnInContainerWithPtyOptionsPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = SpawnInContainerWithPtyOptionsSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] SpawnInContainerWithPtyOptionsPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(SpawnInContainerWithPtyOptions),
			Converter = null,
			Getter = (object obj) => ((SpawnInContainerWithPtyOptions)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((SpawnInContainerWithPtyOptions)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<MxcPtySize?> propertyInfo2 = new JsonPropertyInfoValues<MxcPtySize?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(SpawnInContainerWithPtyOptions),
			Converter = null,
			Getter = (object obj) => ((SpawnInContainerWithPtyOptions)obj).Size,
			Setter = (object obj, MxcPtySize? value) =>
			{
				((SpawnInContainerWithPtyOptions)obj).Size = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Size",
			JsonPropertyName = null
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void SpawnInContainerWithPtyOptionsSerializeHandler(Utf8JsonWriter writer, SpawnInContainerWithPtyOptions? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		TelemetryConfig telemetry = value.Telemetry;
		if (telemetry != null)
		{
			writer.WritePropertyName(PropName_telemetry);
			TelemetryConfigSerializeHandler(writer, telemetry);
		}
		MxcPtySize? size = value.Size;
		if (size.HasValue)
		{
			writer.WritePropertyName(PropName_size);
			JsonSerializer.Serialize(writer, size, NullableMxcPtySize);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<SpawnOptions> Create_SpawnOptions(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<SpawnOptions> jsonTypeInfo))
		{
			JsonObjectInfoValues<SpawnOptions> objectInfo = new JsonObjectInfoValues<SpawnOptions>
			{
				ObjectCreator = () => new SpawnOptions(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => SpawnOptionsPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = SpawnOptionsSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] SpawnOptionsPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(SpawnOptions),
			Converter = null,
			Getter = (object obj) => ((SpawnOptions)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((SpawnOptions)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void SpawnOptionsSerializeHandler(Utf8JsonWriter writer, SpawnOptions? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		TelemetryConfig telemetry = value.Telemetry;
		if (telemetry != null)
		{
			writer.WritePropertyName(PropName_telemetry);
			TelemetryConfigSerializeHandler(writer, telemetry);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<SpawnWithPtyOptions> Create_SpawnWithPtyOptions(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<SpawnWithPtyOptions> jsonTypeInfo))
		{
			JsonObjectInfoValues<SpawnWithPtyOptions> objectInfo = new JsonObjectInfoValues<SpawnWithPtyOptions>
			{
				ObjectCreator = () => new SpawnWithPtyOptions(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => SpawnWithPtyOptionsPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = SpawnWithPtyOptionsSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] SpawnWithPtyOptionsPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(SpawnWithPtyOptions),
			Converter = null,
			Getter = (object obj) => ((SpawnWithPtyOptions)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((SpawnWithPtyOptions)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<MxcPtySize?> propertyInfo2 = new JsonPropertyInfoValues<MxcPtySize?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(SpawnWithPtyOptions),
			Converter = null,
			Getter = (object obj) => ((SpawnWithPtyOptions)obj).Size,
			Setter = (object obj, MxcPtySize? value) =>
			{
				((SpawnWithPtyOptions)obj).Size = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Size",
			JsonPropertyName = null
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void SpawnWithPtyOptionsSerializeHandler(Utf8JsonWriter writer, SpawnWithPtyOptions? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		TelemetryConfig telemetry = value.Telemetry;
		if (telemetry != null)
		{
			writer.WritePropertyName(PropName_telemetry);
			TelemetryConfigSerializeHandler(writer, telemetry);
		}
		MxcPtySize? size = value.Size;
		if (size.HasValue)
		{
			writer.WritePropertyName(PropName_size);
			JsonSerializer.Serialize(writer, size, NullableMxcPtySize);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<StartOptions> Create_StartOptions(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<StartOptions> jsonTypeInfo))
		{
			JsonObjectInfoValues<StartOptions> objectInfo = new JsonObjectInfoValues<StartOptions>
			{
				ObjectCreator = () => new StartOptions(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => StartOptionsPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = StartOptionsSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
			jsonTypeInfo.UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] StartOptionsPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(StartOptions),
			Converter = null,
			Getter = (object obj) => ((StartOptions)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((StartOptions)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void StartOptionsSerializeHandler(Utf8JsonWriter writer, StartOptions? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		TelemetryConfig telemetry = value.Telemetry;
		if (telemetry != null)
		{
			writer.WritePropertyName(PropName_telemetry);
			TelemetryConfigSerializeHandler(writer, telemetry);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<StopOptions> Create_StopOptions(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<StopOptions> jsonTypeInfo))
		{
			JsonObjectInfoValues<StopOptions> objectInfo = new JsonObjectInfoValues<StopOptions>
			{
				ObjectCreator = () => new StopOptions(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => StopOptionsPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = StopOptionsSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
			jsonTypeInfo.UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] StopOptionsPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(StopOptions),
			Converter = null,
			Getter = (object obj) => ((StopOptions)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((StopOptions)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void StopOptionsSerializeHandler(Utf8JsonWriter writer, StopOptions? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		TelemetryConfig telemetry = value.Telemetry;
		if (telemetry != null)
		{
			writer.WritePropertyName(PropName_telemetry);
			TelemetryConfigSerializeHandler(writer, telemetry);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<TelemetryConfig> Create_TelemetryConfig(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<TelemetryConfig> jsonTypeInfo))
		{
			JsonObjectInfoValues<TelemetryConfig> objectInfo = new JsonObjectInfoValues<TelemetryConfig>
			{
				ObjectCreator = () => new TelemetryConfig(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => TelemetryConfigPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = TelemetryConfigSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] TelemetryConfigPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<bool?> propertyInfo = new JsonPropertyInfoValues<bool?>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(TelemetryConfig),
			Converter = null,
			Getter = (object obj) => ((TelemetryConfig)obj).Enabled,
			Setter = (object obj, bool? value) =>
			{
				((TelemetryConfig)obj).Enabled = value;
			},
			IgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Enabled",
			JsonPropertyName = "enabled"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void TelemetryConfigSerializeHandler(Utf8JsonWriter writer, TelemetryConfig? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		bool? enabled = value.Enabled;
		if (enabled.HasValue)
		{
			writer.WritePropertyName(PropName_enabled);
			JsonSerializer.Serialize(writer, enabled, NullableBoolean);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<UiPolicy> Create_UiPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<UiPolicy> jsonTypeInfo))
		{
			JsonObjectInfoValues<UiPolicy> objectInfo = new JsonObjectInfoValues<UiPolicy>
			{
				ObjectCreator = () => new UiPolicy(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => UiPolicyPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = UiPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] UiPolicyPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[3];
		JsonPropertyInfoValues<bool> propertyInfo = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(UiPolicy),
			Converter = null,
			Getter = (object obj) => ((UiPolicy)obj).Disable,
			Setter = (object obj, bool value) =>
			{
				((UiPolicy)obj).Disable = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Disable",
			JsonPropertyName = "disable"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<ClipboardPolicy> propertyInfo2 = new JsonPropertyInfoValues<ClipboardPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(UiPolicy),
			Converter = null,
			Getter = (object obj) => ((UiPolicy)obj).Clipboard,
			Setter = (object obj, ClipboardPolicy value) =>
			{
				((UiPolicy)obj).Clipboard = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Clipboard",
			JsonPropertyName = "clipboard"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<bool> propertyInfo3 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(UiPolicy),
			Converter = null,
			Getter = (object obj) => ((UiPolicy)obj).AllowInputInjection,
			Setter = (object obj, bool value) =>
			{
				((UiPolicy)obj).AllowInputInjection = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "AllowInputInjection",
			JsonPropertyName = "allowInputInjection"
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		return array;
	}

	private void UiPolicySerializeHandler(Utf8JsonWriter writer, UiPolicy? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		writer.WriteBoolean(PropName_disable, value.Disable);
		writer.WritePropertyName(PropName_clipboard);
		JsonSerializer.Serialize(writer, value.Clipboard, ClipboardPolicy);
		writer.WriteBoolean(PropName_allowInputInjection, value.AllowInputInjection);
		writer.WriteEndObject();
	}

	private JsonTypeInfo<ValidationResult> Create_ValidationResult(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ValidationResult> jsonTypeInfo))
		{
			JsonObjectInfoValues<ValidationResult> objectInfo = new JsonObjectInfoValues<ValidationResult>
			{
				ObjectCreator = () => new ValidationResult(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => ValidationResultPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = ValidationResultSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] ValidationResultPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[1];
		JsonPropertyInfoValues<string[]> propertyInfo = new JsonPropertyInfoValues<string[]>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ValidationResult),
			Converter = null,
			Getter = (object obj) => ((ValidationResult)obj).Warnings,
			Setter = (object obj, string[]? value) =>
			{
				((ValidationResult)obj).Warnings = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Warnings",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		return array;
	}

	private void ValidationResultSerializeHandler(Utf8JsonWriter writer, ValidationResult? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		string[] warnings = value.Warnings;
		if (warnings != null)
		{
			writer.WritePropertyName(PropName_warnings);
			StringArraySerializeHandler(writer, warnings);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<WslcPortMapping> Create_WslcPortMapping(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<WslcPortMapping> jsonTypeInfo))
		{
			JsonObjectInfoValues<WslcPortMapping> objectInfo = new JsonObjectInfoValues<WslcPortMapping>
			{
				ObjectCreator = null,
				ObjectWithParameterizedConstructorCreator = (object[] args) => new WslcPortMapping((int)args[0], (int)args[1]),
				PropertyMetadataInitializer = (JsonSerializerContext _) => WslcPortMappingPropInit(options),
				ConstructorParameterMetadataInitializer = WslcPortMappingCtorParamInit,
				SerializeHandler = WslcPortMappingSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] WslcPortMappingPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[2];
		JsonPropertyInfoValues<ushort> propertyInfo = new JsonPropertyInfoValues<ushort>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(WslcPortMapping),
			Converter = null,
			Getter = (object obj) => ((WslcPortMapping)obj).WindowsPort,
			Setter = null,
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "WindowsPort",
			JsonPropertyName = "windowsPort"
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<ushort> propertyInfo2 = new JsonPropertyInfoValues<ushort>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(WslcPortMapping),
			Converter = null,
			Getter = (object obj) => ((WslcPortMapping)obj).ContainerPort,
			Setter = null,
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ContainerPort",
			JsonPropertyName = "containerPort"
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		return array;
	}

	private void WslcPortMappingSerializeHandler(Utf8JsonWriter writer, WslcPortMapping? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		writer.WriteNumber(PropName_windowsPort, value.WindowsPort);
		writer.WriteNumber(PropName_containerPort, value.ContainerPort);
		writer.WriteEndObject();
	}

	private static JsonParameterInfoValues[] WslcPortMappingCtorParamInit()
	{
		return new JsonParameterInfoValues[2]
		{
			new JsonParameterInfoValues
			{
				Name = "windowsPort",
				ParameterType = typeof(int),
				Position = 0,
				HasDefaultValue = false,
				DefaultValue = 0
			},
			new JsonParameterInfoValues
			{
				Name = "containerPort",
				ParameterType = typeof(int),
				Position = 1,
				HasDefaultValue = false,
				DefaultValue = 0
			}
		};
	}

	private JsonTypeInfo<Microsoft.Mxc.Sdk.V1.WslcProvisionRequest> Create_WslcProvisionRequest(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Microsoft.Mxc.Sdk.V1.WslcProvisionRequest> jsonTypeInfo))
		{
			JsonObjectInfoValues<Microsoft.Mxc.Sdk.V1.WslcProvisionRequest> objectInfo = new JsonObjectInfoValues<Microsoft.Mxc.Sdk.V1.WslcProvisionRequest>
			{
				ObjectCreator = () => new Microsoft.Mxc.Sdk.V1.WslcProvisionRequest(),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => WslcProvisionRequestPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				SerializeHandler = WslcProvisionRequestSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
			jsonTypeInfo.UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] WslcProvisionRequestPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[5];
		JsonPropertyInfoValues<FilesystemPolicy> propertyInfo = new JsonPropertyInfoValues<FilesystemPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Microsoft.Mxc.Sdk.V1.WslcProvisionRequest),
			Converter = null,
			Getter = (object obj) => ((Microsoft.Mxc.Sdk.V1.WslcProvisionRequest)obj).Filesystem,
			Setter = (object obj, FilesystemPolicy? value) =>
			{
				((Microsoft.Mxc.Sdk.V1.WslcProvisionRequest)obj).Filesystem = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Filesystem",
			JsonPropertyName = null
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<NetworkPolicy> propertyInfo2 = new JsonPropertyInfoValues<NetworkPolicy>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Microsoft.Mxc.Sdk.V1.WslcProvisionRequest),
			Converter = null,
			Getter = (object obj) => ((Microsoft.Mxc.Sdk.V1.WslcProvisionRequest)obj).Network,
			Setter = (object obj, NetworkPolicy? value) =>
			{
				((Microsoft.Mxc.Sdk.V1.WslcProvisionRequest)obj).Network = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Network",
			JsonPropertyName = null
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<string> propertyInfo3 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Microsoft.Mxc.Sdk.V1.WslcProvisionRequest),
			Converter = null,
			Getter = (object obj) => ((Microsoft.Mxc.Sdk.V1.WslcProvisionRequest)obj).Image,
			Setter = (object obj, string? value) =>
			{
				((Microsoft.Mxc.Sdk.V1.WslcProvisionRequest)obj).Image = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Image",
			JsonPropertyName = null
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<string> propertyInfo4 = new JsonPropertyInfoValues<string>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(Microsoft.Mxc.Sdk.V1.WslcProvisionRequest),
			Converter = null,
			Getter = (object obj) => ((Microsoft.Mxc.Sdk.V1.WslcProvisionRequest)obj).ImageTarPath,
			Setter = (object obj, string? value) =>
			{
				((Microsoft.Mxc.Sdk.V1.WslcProvisionRequest)obj).ImageTarPath = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "ImageTarPath",
			JsonPropertyName = null
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		JsonPropertyInfoValues<TelemetryConfig> propertyInfo5 = new JsonPropertyInfoValues<TelemetryConfig>
		{
			IsProperty = true,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(ProvisionRequest),
			Converter = null,
			Getter = (object obj) => ((ProvisionRequest)obj).Telemetry,
			Setter = (object obj, TelemetryConfig? value) =>
			{
				((ProvisionRequest)obj).Telemetry = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "Telemetry",
			JsonPropertyName = null
		};
		array[4] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo5);
		return array;
	}

	private void WslcProvisionRequestSerializeHandler(Utf8JsonWriter writer, Microsoft.Mxc.Sdk.V1.WslcProvisionRequest? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		FilesystemPolicy filesystem = value.Filesystem;
		if (filesystem != null)
		{
			writer.WritePropertyName(PropName_filesystem);
			FilesystemPolicySerializeHandler(writer, filesystem);
		}
		NetworkPolicy network = value.Network;
		if (network != null)
		{
			writer.WritePropertyName(PropName_network);
			NetworkPolicySerializeHandler(writer, network);
		}
		string image = value.Image;
		if (image != null)
		{
			writer.WriteString(PropName_image, image);
		}
		string imageTarPath = value.ImageTarPath;
		if (imageTarPath != null)
		{
			writer.WriteString(PropName_imageTarPath, imageTarPath);
		}
		TelemetryConfig telemetry = value.Telemetry;
		if (telemetry != null)
		{
			writer.WritePropertyName(PropName_telemetry);
			TelemetryConfigSerializeHandler(writer, telemetry);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Dictionary<string, string>> Create_DictionaryStringString(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Dictionary<string, string>> jsonTypeInfo))
		{
			JsonCollectionInfoValues<Dictionary<string, string>> collectionInfo = new JsonCollectionInfoValues<Dictionary<string, string>>
			{
				ObjectCreator = () => new Dictionary<string, string>(),
				SerializeHandler = DictionaryStringStringSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateDictionaryInfo<Dictionary<string, string>, string, string>(options, collectionInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private void DictionaryStringStringSerializeHandler(Utf8JsonWriter writer, Dictionary<string, string>? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		foreach (KeyValuePair<string, string> item in value)
		{
			writer.WriteString(item.Key, item.Value);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<List<NetworkPeer>> Create_ListNetworkPeer(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<List<NetworkPeer>> jsonTypeInfo))
		{
			JsonCollectionInfoValues<List<NetworkPeer>> collectionInfo = new JsonCollectionInfoValues<List<NetworkPeer>>
			{
				ObjectCreator = () => new List<NetworkPeer>(),
				SerializeHandler = ListNetworkPeerSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateListInfo<List<NetworkPeer>, NetworkPeer>(options, collectionInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private void ListNetworkPeerSerializeHandler(Utf8JsonWriter writer, List<NetworkPeer>? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartArray();
		for (int i = 0; i < value.Count; i++)
		{
			NetworkPeerSerializeHandler(writer, value[i]);
		}
		writer.WriteEndArray();
	}

	private JsonTypeInfo<List<NetworkPort>> Create_ListNetworkPort(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<List<NetworkPort>> jsonTypeInfo))
		{
			JsonCollectionInfoValues<List<NetworkPort>> collectionInfo = new JsonCollectionInfoValues<List<NetworkPort>>
			{
				ObjectCreator = () => new List<NetworkPort>(),
				SerializeHandler = ListNetworkPortSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateListInfo<List<NetworkPort>, NetworkPort>(options, collectionInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private void ListNetworkPortSerializeHandler(Utf8JsonWriter writer, List<NetworkPort>? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartArray();
		for (int i = 0; i < value.Count; i++)
		{
			NetworkPortSerializeHandler(writer, value[i]);
		}
		writer.WriteEndArray();
	}

	private JsonTypeInfo<List<NetworkRule>> Create_ListNetworkRule(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<List<NetworkRule>> jsonTypeInfo))
		{
			JsonCollectionInfoValues<List<NetworkRule>> collectionInfo = new JsonCollectionInfoValues<List<NetworkRule>>
			{
				ObjectCreator = () => new List<NetworkRule>(),
				SerializeHandler = ListNetworkRuleSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateListInfo<List<NetworkRule>, NetworkRule>(options, collectionInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private void ListNetworkRuleSerializeHandler(Utf8JsonWriter writer, List<NetworkRule>? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartArray();
		for (int i = 0; i < value.Count; i++)
		{
			NetworkRuleSerializeHandler(writer, value[i]);
		}
		writer.WriteEndArray();
	}

	private JsonTypeInfo<List<PortMapping>> Create_ListPortMapping(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<List<PortMapping>> jsonTypeInfo))
		{
			JsonCollectionInfoValues<List<PortMapping>> collectionInfo = new JsonCollectionInfoValues<List<PortMapping>>
			{
				ObjectCreator = () => new List<PortMapping>(),
				SerializeHandler = ListPortMappingSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateListInfo<List<PortMapping>, PortMapping>(options, collectionInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private void ListPortMappingSerializeHandler(Utf8JsonWriter writer, List<PortMapping>? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartArray();
		for (int i = 0; i < value.Count; i++)
		{
			PortMappingSerializeHandler(writer, value[i]);
		}
		writer.WriteEndArray();
	}

	private JsonTypeInfo<List<NetworkPeerPolicy>> Create_ListNetworkPeerPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<List<NetworkPeerPolicy>> jsonTypeInfo))
		{
			JsonCollectionInfoValues<List<NetworkPeerPolicy>> collectionInfo = new JsonCollectionInfoValues<List<NetworkPeerPolicy>>
			{
				ObjectCreator = () => new List<NetworkPeerPolicy>(),
				SerializeHandler = ListNetworkPeerPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateListInfo<List<NetworkPeerPolicy>, NetworkPeerPolicy>(options, collectionInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private void ListNetworkPeerPolicySerializeHandler(Utf8JsonWriter writer, List<NetworkPeerPolicy>? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartArray();
		for (int i = 0; i < value.Count; i++)
		{
			NetworkPeerPolicySerializeHandler(writer, value[i]);
		}
		writer.WriteEndArray();
	}

	private JsonTypeInfo<List<NetworkPortPolicy>> Create_ListNetworkPortPolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<List<NetworkPortPolicy>> jsonTypeInfo))
		{
			JsonCollectionInfoValues<List<NetworkPortPolicy>> collectionInfo = new JsonCollectionInfoValues<List<NetworkPortPolicy>>
			{
				ObjectCreator = () => new List<NetworkPortPolicy>(),
				SerializeHandler = ListNetworkPortPolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateListInfo<List<NetworkPortPolicy>, NetworkPortPolicy>(options, collectionInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private void ListNetworkPortPolicySerializeHandler(Utf8JsonWriter writer, List<NetworkPortPolicy>? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartArray();
		for (int i = 0; i < value.Count; i++)
		{
			NetworkPortPolicySerializeHandler(writer, value[i]);
		}
		writer.WriteEndArray();
	}

	private JsonTypeInfo<List<NetworkRulePolicy>> Create_ListNetworkRulePolicy(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<List<NetworkRulePolicy>> jsonTypeInfo))
		{
			JsonCollectionInfoValues<List<NetworkRulePolicy>> collectionInfo = new JsonCollectionInfoValues<List<NetworkRulePolicy>>
			{
				ObjectCreator = () => new List<NetworkRulePolicy>(),
				SerializeHandler = ListNetworkRulePolicySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateListInfo<List<NetworkRulePolicy>, NetworkRulePolicy>(options, collectionInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private void ListNetworkRulePolicySerializeHandler(Utf8JsonWriter writer, List<NetworkRulePolicy>? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartArray();
		for (int i = 0; i < value.Count; i++)
		{
			NetworkRulePolicySerializeHandler(writer, value[i]);
		}
		writer.WriteEndArray();
	}

	private JsonTypeInfo<List<WslcPortMapping>> Create_ListWslcPortMapping(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<List<WslcPortMapping>> jsonTypeInfo))
		{
			JsonCollectionInfoValues<List<WslcPortMapping>> collectionInfo = new JsonCollectionInfoValues<List<WslcPortMapping>>
			{
				ObjectCreator = () => new List<WslcPortMapping>(),
				SerializeHandler = ListWslcPortMappingSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateListInfo<List<WslcPortMapping>, WslcPortMapping>(options, collectionInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private void ListWslcPortMappingSerializeHandler(Utf8JsonWriter writer, List<WslcPortMapping>? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartArray();
		for (int i = 0; i < value.Count; i++)
		{
			WslcPortMappingSerializeHandler(writer, value[i]);
		}
		writer.WriteEndArray();
	}

	private JsonTypeInfo<List<string>> Create_ListString(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<List<string>> jsonTypeInfo))
		{
			JsonCollectionInfoValues<List<string>> collectionInfo = new JsonCollectionInfoValues<List<string>>
			{
				ObjectCreator = () => new List<string>(),
				SerializeHandler = ListStringSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateListInfo<List<string>, string>(options, collectionInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private void ListStringSerializeHandler(Utf8JsonWriter writer, List<string>? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartArray();
		for (int i = 0; i < value.Count; i++)
		{
			writer.WriteStringValue(value[i]);
		}
		writer.WriteEndArray();
	}

	private JsonTypeInfo<int> Create_Int32(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<int> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<int>(options, JsonMetadataServices.Int32Converter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<object> Create_Object(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<object> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<object>(options, JsonMetadataServices.ObjectConverter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<string> Create_String(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<string> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<string>(options, JsonMetadataServices.StringConverter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<string[]> Create_StringArray(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<string[]> jsonTypeInfo))
		{
			JsonCollectionInfoValues<string[]> collectionInfo = new JsonCollectionInfoValues<string[]>
			{
				ObjectCreator = null,
				SerializeHandler = StringArraySerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateArrayInfo(options, collectionInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private void StringArraySerializeHandler(Utf8JsonWriter writer, string[]? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartArray();
		for (int i = 0; i < value.Length; i++)
		{
			writer.WriteStringValue(value[i]);
		}
		writer.WriteEndArray();
	}

	private JsonTypeInfo<uint> Create_UInt32(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<uint> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<uint>(options, JsonMetadataServices.UInt32Converter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<uint?> Create_NullableUInt32(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<uint?> jsonTypeInfo))
		{
			JsonConverter nullableConverter = JsonMetadataServices.GetNullableConverter<uint>(options);
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<uint?>(options, nullableConverter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<ulong> Create_UInt64(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ulong> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<ulong>(options, JsonMetadataServices.UInt64Converter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<ulong?> Create_NullableUInt64(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ulong?> jsonTypeInfo))
		{
			JsonConverter nullableConverter = JsonMetadataServices.GetNullableConverter<ulong>(options);
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<ulong?>(options, nullableConverter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<ushort> Create_UInt16(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ushort> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<ushort>(options, JsonMetadataServices.UInt16Converter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<ushort?> Create_NullableUInt16(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<ushort?> jsonTypeInfo))
		{
			JsonConverter nullableConverter = JsonMetadataServices.GetNullableConverter<ushort>(options);
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<ushort?>(options, nullableConverter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	public MxcJsonContext()
		: base(null)
	{
	}

	public MxcJsonContext(JsonSerializerOptions options)
		: base(options)
	{
	}

	private static bool TryGetTypeInfoForRuntimeCustomConverter<TJsonMetadataType>(JsonSerializerOptions options, out JsonTypeInfo<TJsonMetadataType> jsonTypeInfo)
	{
		JsonConverter runtimeConverterForType = GetRuntimeConverterForType(typeof(TJsonMetadataType), options);
		if (runtimeConverterForType != null)
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<TJsonMetadataType>(options, runtimeConverterForType);
			return true;
		}
		jsonTypeInfo = null;
		return false;
	}

	private static JsonConverter? GetRuntimeConverterForType(Type type, JsonSerializerOptions options)
	{
		for (int i = 0; i < options.Converters.Count; i++)
		{
			JsonConverter jsonConverter = options.Converters[i];
			if (jsonConverter != null && jsonConverter.CanConvert(type))
			{
				return ExpandConverter(type, jsonConverter, options, validateCanConvert: false);
			}
		}
		return null;
	}

	private static JsonConverter ExpandConverter(Type type, JsonConverter converter, JsonSerializerOptions options, bool validateCanConvert = true)
	{
		if (validateCanConvert && !converter.CanConvert(type))
		{
			throw new InvalidOperationException($"The converter '{converter.GetType()}' is not compatible with the type '{type}'.");
		}
		if (converter is JsonConverterFactory jsonConverterFactory)
		{
			converter = jsonConverterFactory.CreateConverter(type, options);
			if (converter == null || converter is JsonConverterFactory)
			{
				throw new InvalidOperationException($"The converter '{jsonConverterFactory.GetType()}' cannot return null or a JsonConverterFactory instance.");
			}
		}
		return converter;
	}

	public override JsonTypeInfo? GetTypeInfo(Type type)
	{
		Options.TryGetTypeInfo(type, out JsonTypeInfo typeInfo);
		return typeInfo;
	}

	JsonTypeInfo? IJsonTypeInfoResolver.GetTypeInfo(Type type, JsonSerializerOptions options)
	{
		if (type == typeof(bool))
		{
			return Create_Boolean(options);
		}
		if (type == typeof(bool?))
		{
			return Create_NullableBoolean(options);
		}
		if (type == typeof(CaptureDenials))
		{
			return Create_CaptureDenials(options);
		}
		if (type == typeof(Fallback))
		{
			return Create_Fallback(options);
		}
		if (type == typeof(Filesystem))
		{
			return Create_Filesystem(options);
		}
		if (type == typeof(Lifecycle))
		{
			return Create_Lifecycle(options);
		}
		if (type == typeof(Lxc))
		{
			return Create_Lxc(options);
		}
		if (type == typeof(Network))
		{
			return Create_Network(options);
		}
		if (type == typeof(NetworkEgress))
		{
			return Create_NetworkEgress(options);
		}
		if (type == typeof(NetworkIngress))
		{
			return Create_NetworkIngress(options);
		}
		if (type == typeof(NetworkPeer))
		{
			return Create_NetworkPeer(options);
		}
		if (type == typeof(NetworkPort))
		{
			return Create_NetworkPort(options);
		}
		if (type == typeof(NetworkRule))
		{
			return Create_NetworkRule(options);
		}
		if (type == typeof(OneShotRequest))
		{
			return Create_OneShotRequest(options);
		}
		if (type == typeof(OneShotWslc))
		{
			return Create_OneShotWslc(options);
		}
		if (type == typeof(PortMapping))
		{
			return Create_PortMapping(options);
		}
		if (type == typeof(Process))
		{
			return Create_Process(options);
		}
		if (type == typeof(ProcessContainer))
		{
			return Create_ProcessContainer(options);
		}
		if (type == typeof(ProcessContainerFilesystem))
		{
			return Create_ProcessContainerFilesystem(options);
		}
		if (type == typeof(ProcessContainerNetwork))
		{
			return Create_ProcessContainerNetwork(options);
		}
		if (type == typeof(ProcessContainerUi))
		{
			return Create_ProcessContainerUi(options);
		}
		if (type == typeof(RuntimeConfig))
		{
			return Create_RuntimeConfig(options);
		}
		if (type == typeof(Seatbelt))
		{
			return Create_Seatbelt(options);
		}
		if (type == typeof(Telemetry))
		{
			return Create_Telemetry(options);
		}
		if (type == typeof(Ui))
		{
			return Create_Ui(options);
		}
		if (type == typeof(CaptureDenialsError))
		{
			return Create_CaptureDenialsError(options);
		}
		if (type == typeof(Microsoft.Mxc.Sdk.V1.CaptureDenialsMode))
		{
			return Create_CaptureDenialsMode(options);
		}
		if (type == typeof(CaptureDenialsPolicy))
		{
			return Create_CaptureDenialsPolicy(options);
		}
		if (type == typeof(CaptureDenialsResult))
		{
			return Create_CaptureDenialsResult(options);
		}
		if (type == typeof(ClipboardPolicy))
		{
			return Create_ClipboardPolicy(options);
		}
		if (type == typeof(ContainerId))
		{
			return Create_ContainerId(options);
		}
		if (type == typeof(ContainerRequest))
		{
			return Create_ContainerRequest(options);
		}
		if (type == typeof(Containment))
		{
			return Create_Containment(options);
		}
		if (type == typeof(Containment.Bubblewrap))
		{
			return Create_SdkContainmentBubblewrap(options);
		}
		if (type == typeof(Containment.IsolationSession))
		{
			return Create_SdkContainmentIsolationSession(options);
		}
		if (type == typeof(Containment.Lxc))
		{
			return Create_SdkContainmentLxc(options);
		}
		if (type == typeof(Containment.Process))
		{
			return Create_SdkContainmentProcess(options);
		}
		if (type == typeof(Containment.ProcessContainer))
		{
			return Create_SdkContainmentProcessContainer(options);
		}
		if (type == typeof(Containment.Seatbelt))
		{
			return Create_SdkContainmentSeatbelt(options);
		}
		if (type == typeof(Containment.Wslc))
		{
			return Create_SdkContainmentWslc(options);
		}
		if (type == typeof(DeprovisionOptions))
		{
			return Create_DeprovisionOptions(options);
		}
		if (type == typeof(ExecutionMetadata))
		{
			return Create_ExecutionMetadata(options);
		}
		if (type == typeof(ExecutionRequest))
		{
			return Create_ExecutionRequest(options);
		}
		if (type == typeof(FilesystemPolicy))
		{
			return Create_FilesystemPolicy(options);
		}
		if (type == typeof(IsolationSessionProvisionMetadata))
		{
			return Create_IsolationSessionProvisionMetadata(options);
		}
		if (type == typeof(Microsoft.Mxc.Sdk.V1.IsolationSessionProvisionRequest))
		{
			return Create_IsolationSessionProvisionRequest(options);
		}
		if (type == typeof(LifecycleResult))
		{
			return Create_LifecycleResult(options);
		}
		if (type == typeof(MxcPtySize))
		{
			return Create_MxcPtySize(options);
		}
		if (type == typeof(MxcPtySize?))
		{
			return Create_NullableMxcPtySize(options);
		}
		if (type == typeof(NativeAvailableBackend))
		{
			return Create_NativeAvailableBackend(options);
		}
		if (type == typeof(NativeAvailableBackend[]))
		{
			return Create_NativeAvailableBackendArray(options);
		}
		if (type == typeof(NativePlatformSupport))
		{
			return Create_NativePlatformSupport(options);
		}
		if (type == typeof(NativeProbeFacts))
		{
			return Create_NativeProbeFacts(options);
		}
		if (type == typeof(NativeProbeOutput))
		{
			return Create_NativeProbeOutput(options);
		}
		if (type == typeof(NativeUiCapabilitySupport))
		{
			return Create_NativeUiCapabilitySupport(options);
		}
		if (type == typeof(Microsoft.Mxc.Sdk.V1.NetworkAction))
		{
			return Create_NetworkAction(options);
		}
		if (type == typeof(Microsoft.Mxc.Sdk.V1.NetworkAction?))
		{
			return Create_NullableNetworkAction(options);
		}
		if (type == typeof(NetworkEgressPolicy))
		{
			return Create_NetworkEgressPolicy(options);
		}
		if (type == typeof(NetworkIngressPolicy))
		{
			return Create_NetworkIngressPolicy(options);
		}
		if (type == typeof(NetworkPeerPolicy))
		{
			return Create_NetworkPeerPolicy(options);
		}
		if (type == typeof(NetworkPolicy))
		{
			return Create_NetworkPolicy(options);
		}
		if (type == typeof(NetworkPortPolicy))
		{
			return Create_NetworkPortPolicy(options);
		}
		if (type == typeof(Microsoft.Mxc.Sdk.V1.NetworkProtocol))
		{
			return Create_NetworkProtocol(options);
		}
		if (type == typeof(Microsoft.Mxc.Sdk.V1.NetworkProtocol?))
		{
			return Create_NullableNetworkProtocol(options);
		}
		if (type == typeof(NetworkRulePolicy))
		{
			return Create_NetworkRulePolicy(options);
		}
		if (type == typeof(NetworkRuntimeConfig))
		{
			return Create_NetworkRuntimeConfig(options);
		}
		if (type == typeof(ProcessContainerFilesystemPolicy))
		{
			return Create_ProcessContainerFilesystemPolicy(options);
		}
		if (type == typeof(ProcessContainerNetworkPolicy))
		{
			return Create_ProcessContainerNetworkPolicy(options);
		}
		if (type == typeof(ProcessContainerSystemSettings))
		{
			return Create_ProcessContainerSystemSettings(options);
		}
		if (type == typeof(Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation))
		{
			return Create_ProcessContainerUiIsolation(options);
		}
		if (type == typeof(ProcessContainerUiPolicy))
		{
			return Create_ProcessContainerUiPolicy(options);
		}
		if (type == typeof(ProcessNetworkPolicy))
		{
			return Create_ProcessNetworkPolicy(options);
		}
		if (type == typeof(ProvisionMetadata))
		{
			return Create_ProvisionMetadata(options);
		}
		if (type == typeof(ProvisionOptions))
		{
			return Create_ProvisionOptions(options);
		}
		if (type == typeof(ProvisionRequest))
		{
			return Create_ProvisionRequest(options);
		}
		if (type == typeof(ProvisionResult))
		{
			return Create_ProvisionResult(options);
		}
		if (type == typeof(RunInContainerOptions))
		{
			return Create_RunInContainerOptions(options);
		}
		if (type == typeof(RunOptions))
		{
			return Create_RunOptions(options);
		}
		if (type == typeof(SpawnInContainerOptions))
		{
			return Create_SpawnInContainerOptions(options);
		}
		if (type == typeof(SpawnInContainerWithPtyOptions))
		{
			return Create_SpawnInContainerWithPtyOptions(options);
		}
		if (type == typeof(SpawnOptions))
		{
			return Create_SpawnOptions(options);
		}
		if (type == typeof(SpawnWithPtyOptions))
		{
			return Create_SpawnWithPtyOptions(options);
		}
		if (type == typeof(StartOptions))
		{
			return Create_StartOptions(options);
		}
		if (type == typeof(StopOptions))
		{
			return Create_StopOptions(options);
		}
		if (type == typeof(TelemetryConfig))
		{
			return Create_TelemetryConfig(options);
		}
		if (type == typeof(UiPolicy))
		{
			return Create_UiPolicy(options);
		}
		if (type == typeof(ValidationResult))
		{
			return Create_ValidationResult(options);
		}
		if (type == typeof(WslcPortMapping))
		{
			return Create_WslcPortMapping(options);
		}
		if (type == typeof(Microsoft.Mxc.Sdk.V1.WslcProvisionRequest))
		{
			return Create_WslcProvisionRequest(options);
		}
		if (type == typeof(Dictionary<string, string>))
		{
			return Create_DictionaryStringString(options);
		}
		if (type == typeof(List<NetworkPeer>))
		{
			return Create_ListNetworkPeer(options);
		}
		if (type == typeof(List<NetworkPort>))
		{
			return Create_ListNetworkPort(options);
		}
		if (type == typeof(List<NetworkRule>))
		{
			return Create_ListNetworkRule(options);
		}
		if (type == typeof(List<PortMapping>))
		{
			return Create_ListPortMapping(options);
		}
		if (type == typeof(List<NetworkPeerPolicy>))
		{
			return Create_ListNetworkPeerPolicy(options);
		}
		if (type == typeof(List<NetworkPortPolicy>))
		{
			return Create_ListNetworkPortPolicy(options);
		}
		if (type == typeof(List<NetworkRulePolicy>))
		{
			return Create_ListNetworkRulePolicy(options);
		}
		if (type == typeof(List<WslcPortMapping>))
		{
			return Create_ListWslcPortMapping(options);
		}
		if (type == typeof(List<string>))
		{
			return Create_ListString(options);
		}
		if (type == typeof(int))
		{
			return Create_Int32(options);
		}
		if (type == typeof(object))
		{
			return Create_Object(options);
		}
		if (type == typeof(string))
		{
			return Create_String(options);
		}
		if (type == typeof(string[]))
		{
			return Create_StringArray(options);
		}
		if (type == typeof(uint))
		{
			return Create_UInt32(options);
		}
		if (type == typeof(uint?))
		{
			return Create_NullableUInt32(options);
		}
		if (type == typeof(ulong))
		{
			return Create_UInt64(options);
		}
		if (type == typeof(ulong?))
		{
			return Create_NullableUInt64(options);
		}
		if (type == typeof(ushort))
		{
			return Create_UInt16(options);
		}
		if (type == typeof(ushort?))
		{
			return Create_NullableUInt16(options);
		}
		return null;
	}
}
