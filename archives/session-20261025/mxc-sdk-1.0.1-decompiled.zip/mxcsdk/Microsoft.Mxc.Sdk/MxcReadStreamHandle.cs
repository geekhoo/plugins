using System;
using System.Runtime.InteropServices;
using Microsoft.Mxc.Sdk.Native;

namespace Microsoft.Mxc.Sdk;

internal sealed class MxcReadStreamHandle : SafeHandle
{
	public override bool IsInvalid => handle == IntPtr.Zero;

	internal unsafe MxcReadStream* Ptr => (MxcReadStream*)handle;

	private MxcReadStreamHandle()
		: base(IntPtr.Zero, ownsHandle: true)
	{
	}

	internal unsafe static MxcReadStreamHandle FromRaw(MxcReadStream* ptr)
	{
		MxcReadStreamHandle mxcReadStreamHandle = new MxcReadStreamHandle();
		mxcReadStreamHandle.SetHandle((nint)ptr);
		return mxcReadStreamHandle;
	}

	protected unsafe override bool ReleaseHandle()
	{
		NativeMethods.mxc_read_stream_free((MxcReadStream*)handle);
		return true;
	}
}
