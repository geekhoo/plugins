using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using System.Text.Json.Serialization.Metadata;
using Microsoft.Mxc.Sdk.V1;

namespace Microsoft.Mxc.Sdk;

internal static class MxcJson
{
	internal static readonly JsonSerializerOptions Options = CreateOptions();

	internal static readonly JsonSerializerOptions ProbeOptions = CreateProbeOptions();

	private static JsonSerializerOptions CreateOptions()
	{
		JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions(MxcJsonContext.Default.Options);
		AddEnumConverters(jsonSerializerOptions);
		AddNetworkSectionConverters(jsonSerializerOptions);
		return jsonSerializerOptions;
	}

	private static JsonSerializerOptions CreateProbeOptions()
	{
		JsonSerializerOptions jsonSerializerOptions = CreateOptions();
		jsonSerializerOptions.UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow;
		return jsonSerializerOptions;
	}

	private static void AddEnumConverters(JsonSerializerOptions options)
	{
		options.Converters.Add(new CamelCaseJsonStringEnumConverter<CaptureDenialsMode>());
		options.Converters.Add(new CamelCaseJsonStringEnumConverter<NetworkAction>());
		options.Converters.Add(new CamelCaseJsonStringEnumConverter<NetworkProtocol>());
		options.Converters.Add(new CamelCaseJsonStringEnumConverter<ClipboardPolicy>());
		options.Converters.Add(new CamelCaseJsonStringEnumConverter<ProcessContainerUiIsolation>());
		options.Converters.Add(new CamelCaseJsonStringEnumConverter<ProcessContainerSystemSettings>());
	}

	private static void AddNetworkSectionConverters(JsonSerializerOptions options)
	{
		options.TypeInfoResolver = options.TypeInfoResolver.WithAddedModifier((JsonTypeInfo typeInfo) =>
		{
			foreach (JsonPropertyInfo property in typeInfo.Properties)
			{
				if (property.PropertyType == typeof(NetworkEgressPolicy))
				{
					property.CustomConverter = new NonNullNetworkSectionJsonConverter<NetworkEgressPolicy>();
				}
				else if (property.PropertyType == typeof(NetworkIngressPolicy))
				{
					property.CustomConverter = new NonNullNetworkSectionJsonConverter<NetworkIngressPolicy>();
				}
			}
		});
	}

	internal static JsonTypeInfo<T> TypeInfo<T>(JsonSerializerOptions options)
	{
		return (JsonTypeInfo<T>)options.GetTypeInfo(typeof(T));
	}

	internal static string Serialize<T>(T value, JsonSerializerOptions options)
	{
		return JsonSerializer.Serialize(value, TypeInfo<T>(options));
	}

	internal static JsonNode? SerializeToNode<T>(T value, JsonSerializerOptions options)
	{
		return JsonSerializer.SerializeToNode(value, TypeInfo<T>(options));
	}

	internal static T? Deserialize<T>(string json, JsonSerializerOptions options)
	{
		return JsonSerializer.Deserialize(json, TypeInfo<T>(options));
	}

	internal static T? Deserialize<T>(string json)
	{
		return Deserialize<T>(json, Options);
	}
}
