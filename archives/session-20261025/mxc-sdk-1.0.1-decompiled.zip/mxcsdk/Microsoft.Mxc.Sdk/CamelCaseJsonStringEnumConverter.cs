using System;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk;

internal sealed class CamelCaseJsonStringEnumConverter<TEnum> : JsonStringEnumConverter<TEnum> where TEnum : struct, Enum
{
	public CamelCaseJsonStringEnumConverter()
		: base(JsonNamingPolicy.CamelCase, true)
	{
	}
}
