namespace Microsoft.Mxc.Sdk.Native;

internal struct MxcWriteStream
{
}
