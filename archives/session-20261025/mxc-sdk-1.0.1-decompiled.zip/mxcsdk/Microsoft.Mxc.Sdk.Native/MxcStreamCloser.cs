namespace Microsoft.Mxc.Sdk.Native;

internal struct MxcStreamCloser
{
}
