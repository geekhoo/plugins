using System.Runtime.InteropServices;
using Microsoft.Mxc.Sdk.V1;

namespace Microsoft.Mxc.Sdk.Native;

internal static class NativeError
{
	internal unsafe static MxcException ToException(int status, MxcErrorDetail detail, string fallbackMessage)
	{
		return new MxcException((ErrorCode)status, ToStringOrNull(detail.message_utf8) ?? fallbackMessage, ToStringOrNull(detail.operation_utf8), ToStringOrNull(detail.native_code_utf8), ToStringOrNull(detail.remediation_utf8));
	}

	internal unsafe static string? ToStringOrNull(byte* p)
	{
		if (p != null)
		{
			return Marshal.PtrToStringUTF8((nint)p);
		}
		return null;
	}
}
