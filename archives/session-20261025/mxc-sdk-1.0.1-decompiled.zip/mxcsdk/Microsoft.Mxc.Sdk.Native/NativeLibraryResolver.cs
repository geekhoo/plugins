using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;

namespace Microsoft.Mxc.Sdk.Native;

internal static class NativeLibraryResolver
{
	private const string LibraryName = "mxc_ffi";

	private static int _initialized;

	internal static void Initialize()
	{
		if (Interlocked.Exchange(ref _initialized, 1) != 0)
		{
			return;
		}
		try
		{
			NativeLibrary.SetDllImportResolver(typeof(NativeLibraryResolver).Assembly, Resolve);
		}
		catch (Exception ex)
		{
			try
			{
				Console.Error.WriteLine($"mxc: could not register the native library resolver ({ex.GetType().Name}: {ex.Message}). " + "Falling back to the default loader.");
			}
			catch
			{
			}
		}
	}

	private static nint Resolve(string libraryName, Assembly assembly, DllImportSearchPath? searchPath)
	{
		if (!string.Equals(libraryName, "mxc_ffi", StringComparison.Ordinal))
		{
			return IntPtr.Zero;
		}
		foreach (string item in CandidatePaths())
		{
			if (File.Exists(item) && NativeLibrary.TryLoad(item, out var handle))
			{
				return handle;
			}
		}
		return IntPtr.Zero;
	}

	private static IEnumerable<string> CandidatePaths()
	{
		string file = NativeFileName();
		string environmentVariable = Environment.GetEnvironmentVariable("MXC_FFI_DIR");
		if (!string.IsNullOrEmpty(environmentVariable))
		{
			yield return Path.Combine(environmentVariable, file);
		}
		string baseDir = AppContext.BaseDirectory;
		yield return Path.Combine(baseDir, file);
		yield return Path.Combine(new string[5]
		{
			baseDir,
			"runtimes",
			RuntimeInformation.RuntimeIdentifier,
			"native",
			file
		});
		DirectoryInfo directoryInfo = new DirectoryInfo(baseDir);
		int num = 0;
		while (directoryInfo != null && num++ < 8)
		{
			if (File.Exists(Path.Combine(directoryInfo.FullName, ".git")) || File.Exists(Path.Combine(directoryInfo.FullName, "src", "Cargo.toml")))
			{
				yield return Path.Combine(new string[5] { directoryInfo.FullName, "src", "target", "release", file });
				break;
			}
			directoryInfo = directoryInfo.Parent;
		}
	}

	private static string NativeFileName()
	{
		if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
		{
			return "mxc_ffi.dll";
		}
		if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
		{
			return "libmxc_ffi.dylib";
		}
		return "libmxc_ffi.so";
	}
}
