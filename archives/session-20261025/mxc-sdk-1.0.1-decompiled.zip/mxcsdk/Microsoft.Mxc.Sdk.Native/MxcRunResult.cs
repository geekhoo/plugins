namespace Microsoft.Mxc.Sdk.Native;

internal struct MxcRunResult
{
	public int status;

	public int exit_code;

	public int timed_out;

	public unsafe byte* stdout_utf8;

	public unsafe byte* stderr_utf8;

	public MxcErrorDetail error;

	public unsafe byte* output_metadata_json_utf8;

	public unsafe byte* warnings_json_utf8;
}
