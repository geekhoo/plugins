namespace Microsoft.Mxc.Sdk.Native;

internal struct MxcNativeStdio
{
	public nint stdin_handle;

	public nint stdout_handle;

	public nint stderr_handle;
}
