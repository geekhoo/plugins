using System.Runtime.InteropServices;

namespace Microsoft.Mxc.Sdk.Native;

internal static class NativeMethods
{
	private const string __DllName = "mxc_ffi";

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_run_json(byte* request_json_utf8, int experimental, MxcRunResult* @out);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern void mxc_run_result_free(MxcRunResult* r);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern void mxc_string_free(byte* s);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern byte* mxc_available_backends_json();

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern byte* mxc_platform_support_json();

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern byte* mxc_probe_request_json(byte* request_json_utf8);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_probe_request_json_with_error(byte* request_json_utf8, byte** out_json_utf8, MxcErrorDetail* out_error);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern byte* mxc_version();

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_telemetry_get_consent(byte** out_utf8);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_telemetry_request_consent(byte* locale_utf8, delegate* unmanaged[Cdecl]<byte*, void*, int> presenter, void* context, byte** out_utf8);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_telemetry_withdraw_consent(byte** out_utf8);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_telemetry_get_consent_status(byte** out_utf8);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_telemetry_needs_consent_prompt(int* out_needs_prompt);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_telemetry_get_policy(byte** out_utf8);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern void mxc_error_detail_free(MxcErrorDetail* detail);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_spawn_pty_json(byte* request_json_utf8, int experimental, ushort rows, ushort cols, MxcSandbox** out_handle, MxcErrorDetail* out_error);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_sandbox_pty_resize(MxcSandbox* handle, ushort rows, ushort cols);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_spawn_json(byte* request_json_utf8, int experimental, MxcSandbox** out_handle, MxcErrorDetail* out_error);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern MxcWriteStream* mxc_sandbox_take_stdin(MxcSandbox* handle);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern MxcReadStream* mxc_sandbox_take_stdout(MxcSandbox* handle);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern MxcReadStream* mxc_sandbox_take_stderr(MxcSandbox* handle);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_sandbox_take_native_stdio(MxcSandbox* handle, MxcNativeStdio* out_stdio);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal static extern void mxc_native_pipe_close(nint handle);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern MxcStreamCloser* mxc_sandbox_stdout_closer(MxcSandbox* handle);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern MxcStreamCloser* mxc_sandbox_stderr_closer(MxcSandbox* handle);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_stream_read(MxcReadStream* stream, byte* buf, nuint cap, nuint* out_read);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_stream_write(MxcWriteStream* stream, byte* buf, nuint len, nuint* out_written);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_stream_flush(MxcWriteStream* stream);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_stream_closer_close(MxcStreamCloser* closer);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern uint mxc_sandbox_id(MxcSandbox* handle);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_sandbox_output_metadata_json(MxcSandbox* handle, byte** out_json_utf8);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_sandbox_warnings_json(MxcSandbox* handle, byte** out_json_utf8);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_sandbox_try_wait(MxcSandbox* handle, int* out_exit, int* out_running, int* out_timed_out);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_sandbox_wait(MxcSandbox* handle, int* out_exit, int* out_timed_out);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_sandbox_kill(MxcSandbox* handle);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_sandbox_kill_for_timeout(MxcSandbox* handle);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern void mxc_sandbox_free(MxcSandbox* handle);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern void mxc_read_stream_free(MxcReadStream* stream);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern void mxc_write_stream_free(MxcWriteStream* stream);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern void mxc_stream_closer_free(MxcStreamCloser* closer);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_run_state_aware_json(byte* request_json_utf8, int dry_run, int experimental, MxcStateAwareResult* @out);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern void mxc_state_aware_result_free(MxcStateAwareResult* r);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_exec_state_aware_json(byte* request_json_utf8, int experimental, MxcSandbox** out_handle, MxcErrorDetail* out_error);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_run_state_aware_exec_json(byte* request_json_utf8, int experimental, MxcRunResult* @out);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_state_aware_exec_pty(byte* request_json_utf8, int experimental, ushort rows, ushort cols, MxcSandbox** out_handle, MxcErrorDetail* out_error);

	[DllImport("mxc_ffi", CallingConvention = CallingConvention.Cdecl, ExactSpelling = true)]
	internal unsafe static extern int mxc_exec_state_aware_attached_json(byte* request_json_utf8, int experimental, MxcExecOutcome* out_outcome, MxcErrorDetail* out_error);
}
