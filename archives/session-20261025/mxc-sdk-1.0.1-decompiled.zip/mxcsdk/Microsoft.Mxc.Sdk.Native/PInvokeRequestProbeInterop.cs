using System;

namespace Microsoft.Mxc.Sdk.Native;

internal sealed class PInvokeRequestProbeInterop : IRequestProbeInterop
{
	internal static PInvokeRequestProbeInterop Instance { get; } = new PInvokeRequestProbeInterop();

	public bool IsSupportedOnCurrentPlatform => OperatingSystem.IsWindows();

	private PInvokeRequestProbeInterop()
	{
	}

	public unsafe int Probe(byte* requestJsonUtf8, byte** outputJsonUtf8, MxcErrorDetail* error)
	{
		return NativeMethods.mxc_probe_request_json_with_error(requestJsonUtf8, outputJsonUtf8, error);
	}

	public unsafe void FreeString(byte* value)
	{
		NativeMethods.mxc_string_free(value);
	}

	public unsafe void FreeError(MxcErrorDetail* error)
	{
		NativeMethods.mxc_error_detail_free(error);
	}
}
