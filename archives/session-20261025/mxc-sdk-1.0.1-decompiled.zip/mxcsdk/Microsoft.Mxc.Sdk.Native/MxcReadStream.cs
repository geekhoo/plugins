namespace Microsoft.Mxc.Sdk.Native;

internal struct MxcReadStream
{
}
