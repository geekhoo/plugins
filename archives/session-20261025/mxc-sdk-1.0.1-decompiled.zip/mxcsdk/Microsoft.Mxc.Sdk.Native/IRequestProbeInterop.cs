namespace Microsoft.Mxc.Sdk.Native;

internal interface IRequestProbeInterop
{
	bool IsSupportedOnCurrentPlatform { get; }

	unsafe int Probe(byte* requestJsonUtf8, byte** outputJsonUtf8, MxcErrorDetail* error);

	unsafe void FreeString(byte* value);

	unsafe void FreeError(MxcErrorDetail* error);
}
