namespace Microsoft.Mxc.Sdk.Native;

internal struct MxcStateAwareResult
{
	public int status;

	public unsafe byte* response_json_utf8;

	public MxcErrorDetail error;
}
