namespace Microsoft.Mxc.Sdk.Native;

internal struct MxcErrorDetail
{
	public unsafe byte* message_utf8;

	public unsafe byte* operation_utf8;

	public unsafe byte* native_code_utf8;

	public unsafe byte* remediation_utf8;
}
