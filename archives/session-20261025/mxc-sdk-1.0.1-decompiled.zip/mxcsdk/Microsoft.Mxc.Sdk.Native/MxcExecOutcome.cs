namespace Microsoft.Mxc.Sdk.Native;

internal struct MxcExecOutcome
{
	public int timed_out;

	public int exit_code;
}
