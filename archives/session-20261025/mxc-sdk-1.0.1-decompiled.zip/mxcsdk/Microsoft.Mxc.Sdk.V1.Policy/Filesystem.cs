using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Microsoft.Mxc.Sdk.V1.Policy;

public static class Filesystem
{
	private static readonly (string Name, bool IsPathList)[] KnownEnvironmentVariables = new (string, bool)[19]
	{
		("PYTHONPATH", true),
		("PYTHONHOME", false),
		("VCINSTALLDIR", false),
		("VSINSTALLDIR", false),
		("PSModulePath", true),
		("VCPKG_ROOT", false),
		("GOPATH", false),
		("GOROOT", false),
		("CARGO_HOME", false),
		("RUSTUP_HOME", false),
		("JAVA_HOME", false),
		("NVM_HOME", false),
		("NVM_SYMLINK", false),
		("NODE_PATH", true),
		("DOTNET_ROOT", false),
		("CONDA_PREFIX", false),
		("LD_LIBRARY_PATH", true),
		("VIRTUAL_ENV", false),
		("PYENV_ROOT", false)
	};

	public static FilesystemPolicyResult GetAvailableToolsPolicy(IReadOnlyDictionary<string, string?>? environment = null)
	{
		IReadOnlyDictionary<string, string> environment2 = environment ?? SnapshotEnvironment();
		IEnumerable<string> enumerable = SplitPathList(GetEnvironmentValue(environment2, "PATH") ?? GetEnvironmentValue(environment2, "Path") ?? string.Empty);
		List<string> list = new List<string>(enumerable);
		(string, bool)[] knownEnvironmentVariables = KnownEnvironmentVariables;
		for (int i = 0; i < knownEnvironmentVariables.Length; i++)
		{
			(string, bool) tuple = knownEnvironmentVariables[i];
			string item = tuple.Item1;
			bool item2 = tuple.Item2;
			string environmentValue = GetEnvironmentValue(environment2, item);
			if (environmentValue != null)
			{
				if (item2)
				{
					list.AddRange(SplitPathList(environmentValue));
				}
				else if (!string.IsNullOrWhiteSpace(environmentValue))
				{
					list.Add(environmentValue.Trim());
				}
			}
		}
		List<string> paths = (from path in DeduplicatePaths(list).Where(Directory.Exists)
			where !IsSystemCriticalPath(path)
			select path).ToList();
		List<string> list2 = new List<string>();
		AddPowerShellPolicy(enumerable, environment2, list2);
		return new FilesystemPolicyResult
		{
			ReadonlyPaths = DeduplicatePaths(paths),
			ReadwritePaths = DeduplicatePaths(list2)
		};
	}

	public static FilesystemPolicyResult GetUserProfilePolicy(IReadOnlyDictionary<string, string?>? environment = null)
	{
		IReadOnlyDictionary<string, string> environment2 = environment ?? SnapshotEnvironment();
		List<string> list = new List<string>();
		if (OperatingSystem.IsWindows())
		{
			string environmentValue = GetEnvironmentValue(environment2, "LOCALAPPDATA");
			if (!string.IsNullOrEmpty(environmentValue) && Directory.Exists(environmentValue))
			{
				string path = Path.Combine(environmentValue, "Programs");
				try
				{
					list.AddRange(Directory.EnumerateDirectories(path));
				}
				catch (DirectoryNotFoundException)
				{
				}
				catch (UnauthorizedAccessException)
				{
				}
				catch (IOException)
				{
				}
			}
		}
		else
		{
			string environmentValue2 = GetEnvironmentValue(environment2, "HOME");
			if (!string.IsNullOrEmpty(environmentValue2))
			{
				string[] array = new string[2]
				{
					Path.Combine(environmentValue2, ".local", "bin"),
					Path.Combine(environmentValue2, ".local", "lib")
				};
				foreach (string text in array)
				{
					if (Directory.Exists(text))
					{
						list.Add(text);
					}
				}
			}
		}
		return new FilesystemPolicyResult
		{
			ReadonlyPaths = list
		};
	}

	public static FilesystemPolicyResult GetTemporaryFilesPolicy(IReadOnlyDictionary<string, string?>? environment = null)
	{
		IReadOnlyDictionary<string, string> environment2 = environment ?? SnapshotEnvironment();
		string text = (OperatingSystem.IsWindows() ? (GetEnvironmentValue(environment2, "TEMP") ?? GetEnvironmentValue(environment2, "TMP")) : (GetEnvironmentValue(environment2, "TMPDIR") ?? "/tmp"));
		if (!string.IsNullOrEmpty(text) && Directory.Exists(text))
		{
			return new FilesystemPolicyResult
			{
				ReadwritePaths = new string[1] { text }
			};
		}
		return new FilesystemPolicyResult();
	}

	private static IReadOnlyDictionary<string, string?> SnapshotEnvironment()
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>(OperatingSystem.IsWindows() ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal);
		foreach (DictionaryEntry environmentVariable in Environment.GetEnvironmentVariables())
		{
			if (environmentVariable.Key is string key)
			{
				dictionary[key] = environmentVariable.Value as string;
			}
		}
		return dictionary;
	}

	private static string? GetEnvironmentValue(IReadOnlyDictionary<string, string?> environment, string name)
	{
		if (environment.TryGetValue(name, out string value))
		{
			return value;
		}
		if (!OperatingSystem.IsWindows())
		{
			return null;
		}
		foreach (KeyValuePair<string, string> item in environment)
		{
			if (string.Equals(item.Key, name, StringComparison.OrdinalIgnoreCase))
			{
				return item.Value;
			}
		}
		return null;
	}

	private static IEnumerable<string> SplitPathList(string value)
	{
		return value.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
	}

	private static IReadOnlyList<string> DeduplicatePaths(IEnumerable<string> paths)
	{
		HashSet<string> hashSet = new HashSet<string>(OperatingSystem.IsWindows() ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal);
		List<string> list = new List<string>();
		foreach (string path in paths)
		{
			string fullPath;
			try
			{
				fullPath = Path.GetFullPath(path);
			}
			catch (Exception ex) when ((ex is ArgumentException || ex is NotSupportedException || ex is PathTooLongException) ? true : false)
			{
				continue;
			}
			if (hashSet.Add(fullPath))
			{
				list.Add(fullPath);
			}
		}
		return list;
	}

	private static bool IsSystemCriticalPath(string path)
	{
		string normalized = Path.GetFullPath(path);
		if (OperatingSystem.IsWindows())
		{
			string fullPath = Path.GetFullPath(Environment.GetEnvironmentVariable("WINDIR") ?? Environment.GetEnvironmentVariable("windir") ?? "C:\\Windows");
			return IsSameOrDescendant(normalized, fullPath, StringComparison.OrdinalIgnoreCase);
		}
		return new string[8] { "/bin", "/sbin", "/usr/bin", "/usr/sbin", "/boot", "/proc", "/sys", "/dev" }.Any((string critical) => IsSameOrDescendant(normalized, critical, StringComparison.Ordinal));
	}

	private static bool IsSameOrDescendant(string candidate, string parent, StringComparison comparison)
	{
		string text = Path.TrimEndingDirectorySeparator(parent);
		if (!string.Equals(Path.TrimEndingDirectorySeparator(candidate), text, comparison))
		{
			return candidate.StartsWith(text + Path.DirectorySeparatorChar, comparison);
		}
		return true;
	}

	private static void AddPowerShellPolicy(IEnumerable<string> pathDirectories, IReadOnlyDictionary<string, string?> environment, ICollection<string> readwritePaths)
	{
		if (OperatingSystem.IsWindows() && pathDirectories.Any((string path) => File.Exists(Path.Combine(path, "pwsh.exe"))))
		{
			string environmentValue = GetEnvironmentValue(environment, "USERPROFILE");
			if (!string.IsNullOrEmpty(environmentValue))
			{
				readwritePaths.Add(Path.Combine(new string[7] { environmentValue, "AppData", "Roaming", "Microsoft", "Windows", "PowerShell", "PSReadLine" }));
			}
		}
	}
}
