using System;
using System.Collections.Generic;

namespace Microsoft.Mxc.Sdk.V1.Policy;

public sealed class FilesystemPolicyResult
{
	public IReadOnlyList<string> ReadonlyPaths { get; init; } = Array.Empty<string>();

	public IReadOnlyList<string> ReadwritePaths { get; init; } = Array.Empty<string>();
}
