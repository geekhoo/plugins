using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class IsolationSessionNetworkEgress
{
	[JsonPropertyName("default")]
	public string Default { get; set; } = string.Empty;
}
