using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class NetworkPeer
{
	[JsonPropertyName("cidr")]
	public string Cidr { get; set; } = string.Empty;

	[JsonPropertyName("except")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public List<string>? Except { get; set; }
}
