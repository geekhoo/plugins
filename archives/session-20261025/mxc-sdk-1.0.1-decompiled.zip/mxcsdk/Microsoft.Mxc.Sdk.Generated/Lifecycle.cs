using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class Lifecycle
{
	[JsonPropertyName("destroyOnExit")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? DestroyOnExit { get; set; }

	[JsonPropertyName("preservePolicy")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? PreservePolicy { get; set; }
}
