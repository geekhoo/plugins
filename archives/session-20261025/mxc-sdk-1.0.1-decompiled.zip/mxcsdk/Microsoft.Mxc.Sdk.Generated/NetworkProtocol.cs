namespace Microsoft.Mxc.Sdk.Generated;

internal static class NetworkProtocol
{
	public const string Tcp = "tcp";

	public const string Udp = "udp";

	public const string Icmp = "icmp";

	public const string Any = "any";
}
