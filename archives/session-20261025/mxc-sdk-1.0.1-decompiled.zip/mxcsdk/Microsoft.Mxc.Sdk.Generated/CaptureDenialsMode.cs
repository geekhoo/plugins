namespace Microsoft.Mxc.Sdk.Generated;

internal static class CaptureDenialsMode
{
	public const string Block = "block";

	public const string Allow = "allow";
}
