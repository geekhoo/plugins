namespace Microsoft.Mxc.Sdk.Generated;

internal static class Version
{
	public const string _100 = "1.0.0";
}
