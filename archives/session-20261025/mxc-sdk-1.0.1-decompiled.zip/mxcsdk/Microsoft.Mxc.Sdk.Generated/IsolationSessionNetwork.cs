using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class IsolationSessionNetwork
{
	[JsonPropertyName("egress")]
	public IsolationSessionNetworkEgress Egress { get; set; } = new IsolationSessionNetworkEgress();

	[JsonPropertyName("ingress")]
	public IsolationSessionNetworkIngress Ingress { get; set; } = new IsolationSessionNetworkIngress();
}
