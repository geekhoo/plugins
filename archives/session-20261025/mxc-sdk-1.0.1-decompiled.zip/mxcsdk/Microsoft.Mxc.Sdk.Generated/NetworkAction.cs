namespace Microsoft.Mxc.Sdk.Generated;

internal static class NetworkAction
{
	public const string Allow = "allow";

	public const string Deny = "deny";
}
