namespace Microsoft.Mxc.Sdk.Generated;

internal static class StopPhase
{
	public const string Stop = "stop";
}
