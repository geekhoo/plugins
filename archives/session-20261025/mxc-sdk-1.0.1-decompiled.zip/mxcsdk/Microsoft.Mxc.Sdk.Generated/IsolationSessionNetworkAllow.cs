namespace Microsoft.Mxc.Sdk.Generated;

internal static class IsolationSessionNetworkAllow
{
	public const string Allow = "allow";
}
