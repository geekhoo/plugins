using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class ExecRequest
{
	[JsonPropertyName("$schema")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? Schema { get; set; }

	[JsonPropertyName("_comment")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public object? Comment { get; set; }

	[JsonPropertyName("network")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Network? Network { get; set; }

	[JsonPropertyName("phase")]
	public string Phase { get; set; } = string.Empty;

	[JsonPropertyName("process")]
	public Process Process { get; set; } = new Process();

	[JsonPropertyName("runtimeConfig")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public RuntimeConfig? RuntimeConfig { get; set; }

	[JsonPropertyName("sandboxId")]
	public string SandboxId { get; set; } = string.Empty;

	[JsonPropertyName("telemetry")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Telemetry? Telemetry { get; set; }

	[JsonPropertyName("version")]
	public string Version { get; set; } = string.Empty;
}
