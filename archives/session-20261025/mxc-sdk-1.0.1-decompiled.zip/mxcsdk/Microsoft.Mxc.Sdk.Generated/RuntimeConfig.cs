using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class RuntimeConfig
{
	[JsonPropertyName("networkProxy")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? NetworkProxy { get; set; }
}
