using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class StateAwareWslc
{
	[JsonPropertyName("provision")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public WslcProvision? Provision { get; set; }
}
