using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class PortMapping
{
	[JsonPropertyName("containerPort")]
	public ushort ContainerPort { get; set; }

	[JsonPropertyName("protocol")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? Protocol { get; set; }

	[JsonPropertyName("windowsPort")]
	public ushort WindowsPort { get; set; }
}
