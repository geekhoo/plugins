using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class NetworkEgress
{
	[JsonPropertyName("allow")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public List<NetworkRule>? Allow { get; set; }

	[JsonPropertyName("default")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? Default { get; set; }

	[JsonPropertyName("deny")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public List<NetworkRule>? Deny { get; set; }
}
