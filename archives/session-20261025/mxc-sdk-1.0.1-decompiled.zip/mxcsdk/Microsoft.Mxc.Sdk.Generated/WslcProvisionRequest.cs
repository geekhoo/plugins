using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class WslcProvisionRequest
{
	[JsonPropertyName("$schema")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? Schema { get; set; }

	[JsonPropertyName("_comment")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public object? Comment { get; set; }

	[JsonPropertyName("containment")]
	public string Containment { get; set; } = string.Empty;

	[JsonPropertyName("filesystem")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Filesystem? Filesystem { get; set; }

	[JsonPropertyName("network")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Network? Network { get; set; }

	[JsonPropertyName("phase")]
	public string Phase { get; set; } = string.Empty;

	[JsonPropertyName("telemetry")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Telemetry? Telemetry { get; set; }

	[JsonPropertyName("version")]
	public string Version { get; set; } = string.Empty;

	[JsonPropertyName("wslc")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public StateAwareWslc? Wslc { get; set; }
}
