using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class NetworkRule
{
	[JsonPropertyName("ports")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public List<NetworkPort>? Ports { get; set; }

	[JsonPropertyName("to")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public List<NetworkPeer>? To { get; set; }
}
