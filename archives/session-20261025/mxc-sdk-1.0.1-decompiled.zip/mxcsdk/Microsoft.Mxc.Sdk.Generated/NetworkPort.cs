using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class NetworkPort
{
	[JsonPropertyName("endPort")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public ushort? EndPort { get; set; }

	[JsonPropertyName("port")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public ushort? Port { get; set; }

	[JsonPropertyName("protocol")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? Protocol { get; set; }
}
