using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class IsolationSessionNetworkIngress
{
	[JsonPropertyName("default")]
	public string Default { get; set; } = string.Empty;

	[JsonPropertyName("hostLoopback")]
	public string HostLoopback { get; set; } = string.Empty;
}
