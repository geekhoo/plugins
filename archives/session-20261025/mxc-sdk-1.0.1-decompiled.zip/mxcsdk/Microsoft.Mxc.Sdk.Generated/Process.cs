using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class Process
{
	[JsonPropertyName("commandLine")]
	public string CommandLine { get; set; } = string.Empty;

	[JsonPropertyName("cwd")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? Cwd { get; set; }

	[JsonPropertyName("env")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public List<string>? Env { get; set; }

	[JsonPropertyName("inheritDefaultEnv")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? InheritDefaultEnv { get; set; }

	[JsonPropertyName("timeout")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public uint? Timeout { get; set; }
}
