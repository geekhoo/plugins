using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class Network
{
	[JsonPropertyName("egress")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public NetworkEgress? Egress { get; set; }

	[JsonPropertyName("ingress")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public NetworkIngress? Ingress { get; set; }
}
