namespace Microsoft.Mxc.Sdk.Generated;

internal static class WslcContainment
{
	public const string Wslc = "wslc";
}
