using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class Filesystem
{
	[JsonPropertyName("deniedPaths")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public List<string>? DeniedPaths { get; set; }

	[JsonPropertyName("readonlyPaths")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public List<string>? ReadonlyPaths { get; set; }

	[JsonPropertyName("readwritePaths")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public List<string>? ReadwritePaths { get; set; }
}
