using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class StateAwareIsolationSession
{
	[JsonPropertyName("provision")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public IsolationSessionProvision? Provision { get; set; }
}
