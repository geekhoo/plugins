using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class ProcessContainer
{
	[JsonPropertyName("capabilities")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public List<string>? Capabilities { get; set; }

	[JsonPropertyName("captureDenials")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public CaptureDenials? CaptureDenials { get; set; }

	[JsonPropertyName("filesystem")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public ProcessContainerFilesystem? Filesystem { get; set; }

	[JsonPropertyName("learningMode")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? LearningMode { get; set; }

	[JsonPropertyName("leastPrivilege")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? LeastPrivilege { get; set; }

	[JsonPropertyName("network")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public ProcessContainerNetwork? Network { get; set; }

	[JsonPropertyName("ui")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public ProcessContainerUi? Ui { get; set; }
}
