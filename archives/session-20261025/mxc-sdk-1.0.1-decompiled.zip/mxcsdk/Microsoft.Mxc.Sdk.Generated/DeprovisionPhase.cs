namespace Microsoft.Mxc.Sdk.Generated;

internal static class DeprovisionPhase
{
	public const string Deprovision = "deprovision";
}
