namespace Microsoft.Mxc.Sdk.Generated;

internal static class ProcessContainerUiIsolation
{
	public const string Container = "container";

	public const string Desktop = "desktop";

	public const string Handles = "handles";

	public const string Atoms = "atoms";
}
