using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class Fallback
{
	[JsonPropertyName("allowDaclMutation")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? AllowDaclMutation { get; set; }
}
