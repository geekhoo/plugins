using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class OneShotWslc
{
	[JsonPropertyName("cpuCount")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public uint? CpuCount { get; set; }

	[JsonPropertyName("gpu")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? Gpu { get; set; }

	[JsonPropertyName("image")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? Image { get; set; }

	[JsonPropertyName("imageTarPath")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? ImageTarPath { get; set; }

	[JsonPropertyName("memoryMb")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public ulong? MemoryMb { get; set; }

	[JsonPropertyName("portMappings")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public List<PortMapping>? PortMappings { get; set; }

	[JsonPropertyName("storagePath")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? StoragePath { get; set; }

	[JsonPropertyName("targetOs")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? TargetOs { get; set; }
}
