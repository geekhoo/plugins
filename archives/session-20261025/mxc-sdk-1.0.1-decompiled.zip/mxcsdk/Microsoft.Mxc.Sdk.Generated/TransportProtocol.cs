namespace Microsoft.Mxc.Sdk.Generated;

internal static class TransportProtocol
{
	public const string Tcp = "tcp";
}
