using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class ProcessContainerUi
{
	[JsonPropertyName("desktopSystemControl")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? DesktopSystemControl { get; set; }

	[JsonPropertyName("ime")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? Ime { get; set; }

	[JsonPropertyName("isolation")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? Isolation { get; set; }

	[JsonPropertyName("systemSettings")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? SystemSettings { get; set; }
}
