namespace Microsoft.Mxc.Sdk.Generated;

internal static class StartPhase
{
	public const string Start = "start";
}
