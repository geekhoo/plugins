using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class Lxc
{
	[JsonPropertyName("distribution")]
	public string Distribution { get; set; } = string.Empty;

	[JsonPropertyName("release")]
	public string Release { get; set; } = string.Empty;
}
