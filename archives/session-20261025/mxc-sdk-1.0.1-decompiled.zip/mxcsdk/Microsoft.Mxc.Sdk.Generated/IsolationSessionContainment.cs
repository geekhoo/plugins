namespace Microsoft.Mxc.Sdk.Generated;

internal static class IsolationSessionContainment
{
	public const string IsolationSession = "isolation_session";
}
