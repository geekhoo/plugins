using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class NetworkIngress
{
	[JsonPropertyName("default")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? Default { get; set; }

	[JsonPropertyName("hostLoopback")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? HostLoopback { get; set; }
}
