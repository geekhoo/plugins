using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class IsolationSessionProvisionRequest
{
	[JsonPropertyName("$schema")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? Schema { get; set; }

	[JsonPropertyName("_comment")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public object? Comment { get; set; }

	[JsonPropertyName("containment")]
	public string Containment { get; set; } = string.Empty;

	[JsonPropertyName("isolationSession")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public StateAwareIsolationSession? IsolationSession { get; set; }

	[JsonPropertyName("network")]
	public IsolationSessionNetwork Network { get; set; } = new IsolationSessionNetwork();

	[JsonPropertyName("phase")]
	public string Phase { get; set; } = string.Empty;

	[JsonPropertyName("telemetry")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Telemetry? Telemetry { get; set; }

	[JsonPropertyName("version")]
	public string Version { get; set; } = string.Empty;
}
