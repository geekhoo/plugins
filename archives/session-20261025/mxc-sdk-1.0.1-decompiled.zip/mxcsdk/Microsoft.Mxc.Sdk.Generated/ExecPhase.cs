namespace Microsoft.Mxc.Sdk.Generated;

internal static class ExecPhase
{
	public const string Exec = "exec";
}
