using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class ProcessContainerNetwork
{
	[JsonPropertyName("allowedProxyPeer")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? AllowedProxyPeer { get; set; }
}
