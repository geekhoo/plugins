namespace Microsoft.Mxc.Sdk.Generated;

internal static class ProvisionPhase
{
	public const string Provision = "provision";
}
