using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class Telemetry
{
	[JsonPropertyName("enabled")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? Enabled { get; set; }
}
