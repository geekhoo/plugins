using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class ProcessContainerFilesystem
{
	[JsonPropertyName("enumeratePaths")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public List<string>? EnumeratePaths { get; set; }
}
