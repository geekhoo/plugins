using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class OneShotRequest
{
	[JsonPropertyName("$schema")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? Schema { get; set; }

	[JsonPropertyName("_comment")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public object? Comment { get; set; }

	[JsonPropertyName("containerId")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? ContainerId { get; set; }

	[JsonPropertyName("containment")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? Containment { get; set; }

	[JsonPropertyName("fallback")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Fallback? Fallback { get; set; }

	[JsonPropertyName("filesystem")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Filesystem? Filesystem { get; set; }

	[JsonPropertyName("lifecycle")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Lifecycle? Lifecycle { get; set; }

	[JsonPropertyName("lxc")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Lxc? Lxc { get; set; }

	[JsonPropertyName("network")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Network? Network { get; set; }

	[JsonPropertyName("process")]
	public Process Process { get; set; } = new Process();

	[JsonPropertyName("processContainer")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public ProcessContainer? ProcessContainer { get; set; }

	[JsonPropertyName("runtimeConfig")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public RuntimeConfig? RuntimeConfig { get; set; }

	[JsonPropertyName("seatbelt")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Seatbelt? Seatbelt { get; set; }

	[JsonPropertyName("telemetry")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Telemetry? Telemetry { get; set; }

	[JsonPropertyName("ui")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public Ui? Ui { get; set; }

	[JsonPropertyName("version")]
	public string Version { get; set; } = string.Empty;

	[JsonPropertyName("wslc")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public OneShotWslc? Wslc { get; set; }
}
