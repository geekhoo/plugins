namespace Microsoft.Mxc.Sdk.Generated;

internal static class UiClipboard
{
	public const string None = "none";

	public const string Read = "read";

	public const string Write = "write";

	public const string All = "all";
}
