namespace Microsoft.Mxc.Sdk.Generated;

internal static class OneShotContainment
{
	public const string Process = "process";

	public const string Processcontainer = "processcontainer";

	public const string Lxc = "lxc";

	public const string Bubblewrap = "bubblewrap";

	public const string Seatbelt = "seatbelt";

	public const string IsolationSession = "isolation_session";

	public const string Wslc = "wslc";
}
