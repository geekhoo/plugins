using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.Generated;

internal sealed class Seatbelt
{
	[JsonPropertyName("extraMachLookups")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public List<string>? ExtraMachLookups { get; set; }

	[JsonPropertyName("guiAccess")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? GuiAccess { get; set; }

	[JsonPropertyName("keychainAccess")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? KeychainAccess { get; set; }

	[JsonPropertyName("nestedPty")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? NestedPty { get; set; }

	[JsonPropertyName("profileOverride")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? ProfileOverride { get; set; }
}
