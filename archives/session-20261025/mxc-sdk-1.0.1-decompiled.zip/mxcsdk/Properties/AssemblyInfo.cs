using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyMetadata("IsTrimmable", "True")]
[assembly: AssemblyCompany("Microsoft.Mxc.Sdk")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyDescription("C# SDK for MXC (Microsoft eXecution Container), binding the native mxc_ffi library.")]
[assembly: AssemblyFileVersion("1.0.1.0")]
[assembly: AssemblyInformationalVersion("1.0.1+fda29ac63bc306b7f97f3b86b4b63d44f7f40cf2")]
[assembly: AssemblyProduct("Microsoft.Mxc.Sdk")]
[assembly: AssemblyTitle("Microsoft.Mxc.Sdk")]
[assembly: InternalsVisibleTo("Microsoft.Mxc.Sdk.Tests")]
[assembly: InternalsVisibleTo("Microsoft.Mxc.Sdk.AotSmokeTest")]
[assembly: AssemblyVersion("1.0.1.0")]
