namespace Microsoft.Mxc.Sdk.V1;

public sealed class SpawnOptions
{
	public TelemetryConfig? Telemetry { get; set; }
}
