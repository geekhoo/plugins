using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class NetworkPeerPolicy
{
	[JsonPropertyName("cidr")]
	public string Cidr { get; }

	[JsonPropertyName("except")]
	public List<string>? Except { get; set; }

	public NetworkPeerPolicy(string cidr)
	{
		ArgumentException.ThrowIfNullOrWhiteSpace(cidr, "cidr");
		Cidr = cidr;
	}
}
