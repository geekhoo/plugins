using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

[JsonPolymorphic(TypeDiscriminatorPropertyName = "kind")]
[JsonDerivedType(typeof(IsolationSessionProvisionMetadata), "isolationSession")]
public abstract class ProvisionMetadata
{
	private protected ProvisionMetadata()
	{
	}
}
