using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class ContainerRequest
{
	[JsonPropertyName("command")]
	public string Command { get; }

	[JsonPropertyName("filesystem")]
	public FilesystemPolicy? Filesystem { get; set; }

	[JsonPropertyName("network")]
	public NetworkPolicy? Network { get; set; }

	[JsonPropertyName("ui")]
	public UiPolicy? Ui { get; set; }

	[JsonPropertyName("timeoutMs")]
	public uint? TimeoutMs { get; set; }

	[JsonPropertyName("containment")]
	public Containment Containment { get; set; } = new Containment.Process();

	[JsonPropertyName("containerName")]
	public string? ContainerName { get; set; }

	[JsonPropertyName("workingDirectory")]
	public string? WorkingDirectory { get; set; }

	[JsonPropertyName("environment")]
	public Dictionary<string, string>? Environment { get; set; }

	[JsonPropertyName("inheritDefaultEnv")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
	public bool InheritDefaultEnvironment { get; set; }

	public ContainerRequest(string command)
	{
		ArgumentNullException.ThrowIfNull(command, "command");
		Command = command;
	}
}
