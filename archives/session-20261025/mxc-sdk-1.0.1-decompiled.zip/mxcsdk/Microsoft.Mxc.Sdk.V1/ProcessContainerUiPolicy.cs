using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class ProcessContainerUiPolicy
{
	[JsonPropertyName("isolation")]
	public ProcessContainerUiIsolation Isolation { get; set; } = ProcessContainerUiIsolation.Container;

	[JsonPropertyName("desktopSystemControl")]
	public bool DesktopSystemControl { get; set; }

	[JsonPropertyName("systemSettings")]
	public ProcessContainerSystemSettings SystemSettings { get; set; } = ProcessContainerSystemSettings.None;

	[JsonPropertyName("ime")]
	public bool Ime { get; set; }
}
