using System;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class LifecycleResult
{
	public string[] Warnings { get; set; } = Array.Empty<string>();
}
