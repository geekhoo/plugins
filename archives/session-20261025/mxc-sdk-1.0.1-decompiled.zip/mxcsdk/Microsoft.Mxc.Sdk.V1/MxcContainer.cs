using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Mxc.Sdk.Native;

namespace Microsoft.Mxc.Sdk.V1;

public static class MxcContainer
{
	[CompilerGenerated]
	private static IRequestProbeInterop RequestProbeInterop__BackingField;

	internal static IRequestProbeInterop RequestProbeInterop
	{
		[CompilerGenerated]
		get
		{
			return RequestProbeInterop__BackingField;
		}
		[CompilerGenerated]
		set
		{
			RequestProbeInterop__BackingField = value;
		}
	}

	static MxcContainer()
	{
		RequestProbeInterop__BackingField = PInvokeRequestProbeInterop.Instance;
		NativeLibraryResolver.Initialize();
	}

	public static ProbeOutput Probe(ContainerRequest? request = null)
	{
		string configJson = ((request == null) ? null : SerializeRequest(request));
		if (!RequestProbeInterop.IsSupportedOnCurrentPlatform)
		{
			throw new MxcException(ErrorCode.UnsupportedContainment, "the request-aware probe is available only for Windows ProcessContainer");
		}
		return ParseProbeOutput(ProbeNative(configJson));
	}

	private unsafe static string ProbeNative(string? configJson)
	{
		if (configJson == null)
		{
			return InvokeNativeProbe(null);
		}
		fixed (byte* requestPtr = ToNullTerminatedUtf8(configJson))
		{
			return InvokeNativeProbe(requestPtr);
		}
	}

	private unsafe static string InvokeNativeProbe(byte* requestPtr)
	{
		byte* ptr = null;
		MxcErrorDetail detail = default;
		bool flag = false;
		try
		{
			int num = RequestProbeInterop.Probe(requestPtr, &ptr, &detail);
			flag = true;
			if (num != 0)
			{
				throw NativeError.ToException(num, detail, "native request probe failed");
			}
			if (ptr == null)
			{
				throw new MxcException(ErrorCode.BackendError, "native request probe returned no output");
			}
			return Marshal.PtrToStringUTF8((nint)ptr) ?? throw new MxcException(ErrorCode.BackendError, "native request probe returned invalid JSON");
		}
		finally
		{
			if (flag)
			{
				if (ptr != null)
				{
					RequestProbeInterop.FreeString(ptr);
				}
				RequestProbeInterop.FreeError(&detail);
			}
		}
	}

	internal static ProbeOutput ParseProbeOutput(string json)
	{
		NativeProbeOutput nativeProbeOutput = MxcJson.Deserialize<NativeProbeOutput>(json, MxcJson.ProbeOptions) ?? throw new JsonException("native request probe returned null JSON.");
		string[] source = nativeProbeOutput.Warnings ?? throw new JsonException("native request probe returned null warnings.");
		if (source.Any((string warning) => warning == null))
		{
			throw new JsonException("native request probe returned a non-string warning.");
		}
		NativeProbeFacts nativeProbeFacts = nativeProbeOutput.Probes ?? throw new JsonException("native request probe omitted probes.");
		NativeUiCapabilitySupport nativeUiCapabilitySupport = nativeProbeFacts.UiCapabilities ?? throw new JsonException("native request probe omitted UI capabilities.");
		IsolationTier? tier;
		if (!nativeProbeOutput.HasTier)
		{
			if (!nativeProbeOutput.HasError)
			{
				throw new JsonException("native request probe omitted both tier and error.");
			}
			if (nativeProbeOutput.Error == null)
			{
				throw new JsonException("native request probe returned a null error.");
			}
			if (nativeProbeOutput.HasNeedsDaclAugmentation)
			{
				throw new JsonException("native request probe returned DACL augmentation with an error.");
			}
			tier = null;
		}
		else
		{
			if (nativeProbeOutput.Tier == null)
			{
				throw new JsonException("native request probe returned a null tier.");
			}
			if (nativeProbeOutput.HasError)
			{
				throw new JsonException("native request probe returned both tier and error.");
			}
			if (!nativeProbeOutput.HasNeedsDaclAugmentation || !nativeProbeOutput.NeedsDaclAugmentation.HasValue)
			{
				throw new JsonException("native request probe omitted DACL augmentation for a selected tier.");
			}
			tier = ParseProbeIsolationTier(nativeProbeOutput.Tier);
		}
		return new ProbeOutput
		{
			Tier = tier,
			NeedsDaclAugmentation = nativeProbeOutput.NeedsDaclAugmentation,
			Warnings = source.Select((string warning) => warning).ToArray(),
			Error = nativeProbeOutput.Error,
			Probes = new ProbeFacts
			{
				BaseContainerApiPresent = nativeProbeFacts.BaseContainerApiPresent,
				NativeCaptureAvailable = nativeProbeFacts.NativeCaptureAvailable,
				GuardedCaptureAvailable = nativeProbeFacts.GuardedCaptureAvailable,
				BfscfgPresent = nativeProbeFacts.BfscfgPresent,
				BfsCompiledIn = nativeProbeFacts.BfsCompiledIn,
				BaseContainerSupportsDenyPaths = nativeProbeFacts.BaseContainerSupportsDenyPaths,
				BaseContainerSupportsEnumeratePaths = nativeProbeFacts.BaseContainerSupportsEnumeratePaths,
				BaseContainerSupportsIngressHostLoopbackAllow = nativeProbeFacts.BaseContainerSupportsIngressHostLoopbackAllow,
				BaseContainerSupportsIdentitylessLoopbackProxy = nativeProbeFacts.BaseContainerSupportsIdentitylessLoopbackProxy,
				IsolationSessionAvailable = nativeProbeFacts.IsolationSessionAvailable,
				HyperlightAvailable = nativeProbeFacts.HyperlightAvailable,
				UiCapabilities = new UiCapabilitySupport
				{
					CanBlockClipboardRead = nativeUiCapabilitySupport.CanBlockClipboardRead,
					CanBlockClipboardWrite = nativeUiCapabilitySupport.CanBlockClipboardWrite,
					CanBlockInputInjection = nativeUiCapabilitySupport.CanBlockInputInjection,
					CanBlockInputMethodChanges = nativeUiCapabilitySupport.CanBlockInputMethodChanges,
					CanBlockExternalUiObjects = nativeUiCapabilitySupport.CanBlockExternalUiObjects,
					CanBlockGlobalUiNamespace = nativeUiCapabilitySupport.CanBlockGlobalUiNamespace,
					CanBlockDesktopSwitching = nativeUiCapabilitySupport.CanBlockDesktopSwitching,
					CanBlockLogoffOrShutdown = nativeUiCapabilitySupport.CanBlockLogoffOrShutdown,
					CanBlockSystemParameterChanges = nativeUiCapabilitySupport.CanBlockSystemParameterChanges,
					CanBlockDisplaySettingsChanges = nativeUiCapabilitySupport.CanBlockDisplaySettingsChanges
				}
			}
		};
	}

	public unsafe static ExecutionResult Run(ContainerRequest request, RunOptions? options = null)
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		fixed (byte* request_json_utf = ToNullTerminatedUtf8(SerializeRequest(request, options?.Telemetry)))
		{
			MxcRunResult mxcRunResult = default;
			int num = NativeMethods.mxc_run_json(request_json_utf, 0, &mxcRunResult);
			try
			{
				if (num != 0)
				{
					throw NativeError.ToException(num, mxcRunResult.error, "unknown error");
				}
				return new ExecutionResult
				{
					ExitCode = mxcRunResult.exit_code,
					TimedOut = (mxcRunResult.timed_out != 0),
					Stdout = (PtrToString(mxcRunResult.stdout_utf8) ?? string.Empty),
					Stderr = (PtrToString(mxcRunResult.stderr_utf8) ?? string.Empty),
					OutputMetadata = DeserializeOutputMetadata(PtrToString(mxcRunResult.output_metadata_json_utf8)),
					Warnings = DeserializeWarnings(PtrToString(mxcRunResult.warnings_json_utf8))
				};
			}
			finally
			{
				NativeMethods.mxc_run_result_free(&mxcRunResult);
			}
		}
	}

	public static Task<ExecutionResult> RunAsync(ContainerRequest request, RunOptions? options = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		return MxcLifecycle.RunBlockingOperationAsync(() => Run(request, options), (ExecutionResult _) =>
		{
		}, cancellationToken);
	}

	public unsafe static MxcProcess Spawn(ContainerRequest request, SpawnOptions? options = null)
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		fixed (byte* request_json_utf = ToNullTerminatedUtf8(SerializeRequest(request, options?.Telemetry)))
		{
			MxcSandbox* ptr = null;
			MxcErrorDetail detail = default;
			int num = NativeMethods.mxc_spawn_json(request_json_utf, 0, &ptr, &detail);
			if (num != 0)
			{
				try
				{
					throw NativeError.ToException(num, detail, "unknown error");
				}
				finally
				{
					NativeMethods.mxc_error_detail_free(&detail);
				}
			}
			return new MxcProcess(MxcSandboxHandle.FromRaw(ptr), request.TimeoutMs);
		}
	}

	public static Task<MxcProcess> SpawnAsync(ContainerRequest request, SpawnOptions? options = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		return MxcLifecycle.RunBlockingOperationAsync(() => Spawn(request, options), (MxcProcess lateProc) =>
		{
			lateProc.Dispose();
		}, cancellationToken);
	}

	public unsafe static MxcPtyProcess SpawnWithPty(ContainerRequest request, SpawnWithPtyOptions? options = null)
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		MxcPtySize mxcPtySize = MxcPtySize.ResolveInitial(options?.Size);
		mxcPtySize.Validate("options");
		fixed (byte* request_json_utf = ToNullTerminatedUtf8(SerializeRequest(request, options?.Telemetry)))
		{
			MxcSandbox* ptr = null;
			MxcErrorDetail detail = default;
			int num = NativeMethods.mxc_spawn_pty_json(request_json_utf, 0, mxcPtySize.Rows, mxcPtySize.Columns, &ptr, &detail);
			if (num != 0)
			{
				try
				{
					throw NativeError.ToException(num, detail, "spawning sandbox PTY failed");
				}
				finally
				{
					NativeMethods.mxc_error_detail_free(&detail);
				}
			}
			return new MxcPtyProcess(MxcSandboxHandle.FromRaw(ptr), request.TimeoutMs);
		}
	}

	private static byte[] ToNullTerminatedUtf8(string value)
	{
		int byteCount = Encoding.UTF8.GetByteCount(value);
		byte[] array = new byte[byteCount + 1];
		Encoding.UTF8.GetBytes(value, 0, value.Length, array, 0);
		array[byteCount] = 0;
		return array;
	}

	internal static string SerializeRequest(ContainerRequest request, TelemetryConfig? telemetry = null)
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		return ExactOneShotRequestWriter.Serialize(request, telemetry);
	}

	private static IsolationTier ParseProbeIsolationTier(string value)
	{
		return value switch
		{
			"base-container" => IsolationTier.BaseContainer, 
			"appcontainer-bfs" => IsolationTier.AppContainerBfs, 
			"appcontainer-dacl" => IsolationTier.AppContainerDacl, 
			_ => throw new JsonException("native request probe returned unknown tier '" + value + "'."), 
		};
	}

	private unsafe static string? PtrToString(byte* p)
	{
		if (p != null)
		{
			return Marshal.PtrToStringUTF8((nint)p);
		}
		return null;
	}

	private static ExecutionMetadata? DeserializeOutputMetadata(string? json)
	{
		if (!string.IsNullOrEmpty(json))
		{
			return MxcJson.Deserialize<ExecutionMetadata>(json);
		}
		return null;
	}

	private static IReadOnlyList<string> DeserializeWarnings(string? json)
	{
		string[] array;
		if (!string.IsNullOrEmpty(json))
		{
			array = MxcJson.Deserialize<string[]>(json);
			if (array == null)
			{
				return Array.Empty<string>();
			}
		}
		else
		{
			array = Array.Empty<string>();
		}
		return array;
	}
}
