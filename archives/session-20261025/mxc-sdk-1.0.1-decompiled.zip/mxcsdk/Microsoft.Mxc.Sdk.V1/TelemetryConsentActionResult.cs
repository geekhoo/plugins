namespace Microsoft.Mxc.Sdk.V1;

public enum TelemetryConsentActionResult
{
	Unknown,
	Granted,
	Denied,
	Dismissed,
	Withdrawn,
	AlreadyGranted,
	PolicyBlocked,
	NotApplicable
}
