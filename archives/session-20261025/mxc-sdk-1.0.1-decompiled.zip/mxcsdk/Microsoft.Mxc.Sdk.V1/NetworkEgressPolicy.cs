using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class NetworkEgressPolicy
{
	[JsonPropertyName("default")]
	public NetworkAction? Default { get; set; }

	[JsonPropertyName("allow")]
	public List<NetworkRulePolicy>? Allow { get; set; }

	[JsonPropertyName("deny")]
	public List<NetworkRulePolicy>? Deny { get; set; }
}
