using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class CaptureDenialsError
{
	[JsonPropertyName("message")]
	public string Message { get; init; } = string.Empty;

	[JsonPropertyName("etlPath")]
	public string EtlPath { get; init; } = string.Empty;
}
