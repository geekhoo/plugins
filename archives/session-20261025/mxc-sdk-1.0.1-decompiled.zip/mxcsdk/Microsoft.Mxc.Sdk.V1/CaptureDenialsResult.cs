using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class CaptureDenialsResult
{
	[JsonPropertyName("type")]
	public string Type { get; init; } = string.Empty;

	[JsonPropertyName("outputPath")]
	public string OutputPath { get; init; } = string.Empty;

	[JsonPropertyName("exitCode")]
	public int ExitCode { get; init; }

	[JsonPropertyName("totalDenials")]
	public ulong TotalDenials { get; init; }

	[JsonPropertyName("deniedResourcesTruncated")]
	public bool DeniedResourcesTruncated { get; init; }

	[JsonPropertyName("etlPath")]
	public string? EtlPath { get; init; }
}
