using System;
using System.IO;
using Microsoft.Mxc.Sdk.Native;

namespace Microsoft.Mxc.Sdk.V1;

internal sealed class MxcStdinStream : Stream
{
	private readonly MxcWriteStreamHandle _handle;

	private readonly object _ioLock = new object();

	public override bool CanRead => false;

	public override bool CanSeek => false;

	public override bool CanWrite => true;

	public override long Length
	{
		get
		{
			throw new NotSupportedException();
		}
	}

	public override long Position
	{
		get
		{
			throw new NotSupportedException();
		}
		set
		{
			throw new NotSupportedException();
		}
	}

	internal MxcStdinStream(MxcWriteStreamHandle handle)
	{
		_handle = handle;
	}

	public unsafe override void Write(byte[] buffer, int offset, int count)
	{
		ArgumentNullException.ThrowIfNull(buffer, "buffer");
		if (offset < 0)
		{
			throw new ArgumentOutOfRangeException("offset");
		}
		if (count < 0)
		{
			throw new ArgumentOutOfRangeException("count");
		}
		if (offset + count > buffer.Length)
		{
			throw new ArgumentException("offset + count exceeds the buffer length");
		}
		lock (_ioLock)
		{
			int num = 0;
			while (num < count)
			{
				bool success = false;
				try
				{
					_handle.DangerousAddRef(ref success);
					nuint num2 = 0u;
					fixed (byte* buf = &buffer[offset + num])
					{
						int num3 = NativeMethods.mxc_stream_write(_handle.Ptr, buf, (nuint)(count - num), &num2);
						if (num3 != 0)
						{
							throw new MxcException((ErrorCode)num3, "writing to the sandbox stream failed");
						}
					}
					if (num2 == 0)
					{
						throw new IOException("the sandbox stdin stream accepted no bytes (pipe closed?)");
					}
					num += (int)num2;
				}
				finally
				{
					if (success)
					{
						_handle.DangerousRelease();
					}
				}
			}
		}
	}

	public unsafe override void Flush()
	{
		lock (_ioLock)
		{
			bool success = false;
			try
			{
				_handle.DangerousAddRef(ref success);
				int num = NativeMethods.mxc_stream_flush(_handle.Ptr);
				if (num != 0)
				{
					throw new MxcException((ErrorCode)num, "flushing the sandbox stream failed");
				}
			}
			catch (ObjectDisposedException)
			{
			}
			finally
			{
				if (success)
				{
					_handle.DangerousRelease();
				}
			}
		}
	}

	public override int Read(byte[] buffer, int offset, int count)
	{
		throw new NotSupportedException();
	}

	public override long Seek(long offset, SeekOrigin origin)
	{
		throw new NotSupportedException();
	}

	public override void SetLength(long value)
	{
		throw new NotSupportedException();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing)
		{
			_handle.Dispose();
		}
		base.Dispose(disposing);
	}
}
