namespace Microsoft.Mxc.Sdk.V1;

public static class SchemaVersions
{
	public const string Minimum = "0.9.0-alpha";

	public const string MaximumSupported = "1.1.0-alpha";

	public const string LatestStable = "1.0.0";

	internal const string SdkContract = "1.0.0";

	internal const string StateAware = "1.0.0";

	internal static bool IsPublished(string version)
	{
		if (version == "0.9.0-alpha" || version == "1.0.0")
		{
			return true;
		}
		return false;
	}

	internal static bool IsSupported(string version)
	{
		if (!IsPublished(version))
		{
			return version == "1.1.0-alpha";
		}
		return true;
	}
}
