using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class FilesystemPolicy
{
	[JsonPropertyName("readwritePaths")]
	public List<string> ReadwritePaths { get; set; } = new List<string>();

	[JsonPropertyName("readonlyPaths")]
	public List<string> ReadonlyPaths { get; set; } = new List<string>();

	[JsonPropertyName("deniedPaths")]
	public List<string> DeniedPaths { get; set; } = new List<string>();

	[JsonPropertyName("clearPolicyOnExit")]
	public bool? ClearPolicyOnExit { get; set; }
}
