using System.Threading;
using System.Threading.Tasks;

namespace Microsoft.Mxc.Sdk.V1;

internal sealed class MxcContainerLifecycle : IContainerLifecycle
{
	public static MxcContainerLifecycle Default { get; } = new MxcContainerLifecycle();

	public ProvisionResult ProvisionContainer(ProvisionRequest request, ProvisionOptions? options = null)
	{
		return MxcLifecycle.ProvisionContainer(request, options);
	}

	public ValidationResult ValidateProvision(ProvisionRequest request, ProvisionOptions? options = null)
	{
		return MxcLifecycle.ValidateProvision(request, options);
	}

	public LifecycleResult StartContainer(ContainerId id, StartOptions? options = null)
	{
		return MxcLifecycle.StartContainer(id, options);
	}

	public ValidationResult ValidateStart(ContainerId id, StartOptions? options = null)
	{
		return MxcLifecycle.ValidateStart(id, options);
	}

	public IMxcProcess SpawnInContainer(ContainerId id, ExecutionRequest request, SpawnInContainerOptions? options = null)
	{
		return MxcLifecycle.SpawnInContainer(id, request, options);
	}

	public MxcPtyProcess SpawnInContainerWithPty(ContainerId id, ExecutionRequest request, SpawnInContainerWithPtyOptions? options = null)
	{
		return MxcLifecycle.SpawnInContainerWithPty(id, request, options);
	}

	public ValidationResult ValidateProcess(ContainerId id, ExecutionRequest request, SpawnInContainerOptions? options = null)
	{
		return MxcLifecycle.ValidateProcess(id, request, options);
	}

	public ExecutionResult RunInContainer(ContainerId id, ExecutionRequest request, RunInContainerOptions? options = null)
	{
		return MxcLifecycle.RunInContainer(id, request, options);
	}

	public Task<ExecutionResult> RunInContainerAsync(ContainerId id, ExecutionRequest request, RunInContainerOptions? options = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		return MxcLifecycle.RunInContainerAsync(id, request, options, cancellationToken);
	}

	public async Task<IMxcProcess> SpawnInContainerAsync(ContainerId id, ExecutionRequest request, SpawnInContainerOptions? options = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		return await MxcLifecycle.SpawnInContainerAsync(id, request, options, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
	}

	public LifecycleResult StopContainer(ContainerId id, StopOptions? options = null)
	{
		return MxcLifecycle.StopContainer(id, options);
	}

	public ValidationResult ValidateStop(ContainerId id, StopOptions? options = null)
	{
		return MxcLifecycle.ValidateStop(id, options);
	}

	public LifecycleResult DeprovisionContainer(ContainerId id, DeprovisionOptions? options = null)
	{
		return MxcLifecycle.DeprovisionContainer(id, options);
	}

	public ValidationResult ValidateDeprovision(ContainerId id, DeprovisionOptions? options = null)
	{
		return MxcLifecycle.ValidateDeprovision(id, options);
	}
}
