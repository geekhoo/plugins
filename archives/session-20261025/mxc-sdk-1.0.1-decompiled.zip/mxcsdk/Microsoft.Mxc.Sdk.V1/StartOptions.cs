using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

[JsonUnmappedMemberHandling(JsonUnmappedMemberHandling.Disallow)]
public sealed class StartOptions
{
	internal string? Version { get; set; }

	public TelemetryConfig? Telemetry { get; set; }
}
