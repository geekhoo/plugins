using System;
using System.Collections.Generic;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class AvailableBackend
{
	public required ContainmentBackend Backend { get; init; }

	public IsolationTier? Tier { get; init; }

	public IReadOnlyList<BackendCapability> Capabilities { get; init; } = Array.Empty<BackendCapability>();

	public IReadOnlyList<string> Warnings { get; init; } = Array.Empty<string>();
}
