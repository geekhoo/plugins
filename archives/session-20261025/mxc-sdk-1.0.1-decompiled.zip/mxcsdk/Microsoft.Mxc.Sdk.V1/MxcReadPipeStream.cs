using System;
using System.IO;
using Microsoft.Mxc.Sdk.Native;

namespace Microsoft.Mxc.Sdk.V1;

internal sealed class MxcReadPipeStream : Stream
{
	private readonly MxcReadStreamHandle _handle;

	private readonly object _ioLock = new object();

	public override bool CanRead => true;

	public override bool CanSeek => false;

	public override bool CanWrite => false;

	public override long Length
	{
		get
		{
			throw new NotSupportedException();
		}
	}

	public override long Position
	{
		get
		{
			throw new NotSupportedException();
		}
		set
		{
			throw new NotSupportedException();
		}
	}

	internal MxcReadPipeStream(MxcReadStreamHandle handle)
	{
		_handle = handle;
	}

	public unsafe override int Read(byte[] buffer, int offset, int count)
	{
		ArgumentNullException.ThrowIfNull(buffer, "buffer");
		if (offset < 0)
		{
			throw new ArgumentOutOfRangeException("offset");
		}
		if (count < 0)
		{
			throw new ArgumentOutOfRangeException("count");
		}
		if (offset + count > buffer.Length)
		{
			throw new ArgumentException("offset + count exceeds the buffer length");
		}
		if (count == 0)
		{
			return 0;
		}
		lock (_ioLock)
		{
			bool success = false;
			try
			{
				_handle.DangerousAddRef(ref success);
				nuint num = 0u;
				fixed (byte* buf = &buffer[offset])
				{
					int num2 = NativeMethods.mxc_stream_read(_handle.Ptr, buf, (nuint)count, &num);
					if (num2 != 0)
					{
						throw new MxcException((ErrorCode)num2, "reading from the sandbox stream failed");
					}
				}
				return (int)num;
			}
			finally
			{
				if (success)
				{
					_handle.DangerousRelease();
				}
			}
		}
	}

	public override void Flush()
	{
	}

	public override long Seek(long offset, SeekOrigin origin)
	{
		throw new NotSupportedException();
	}

	public override void SetLength(long value)
	{
		throw new NotSupportedException();
	}

	public override void Write(byte[] buffer, int offset, int count)
	{
		throw new NotSupportedException();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing)
		{
			_handle.Dispose();
		}
		base.Dispose(disposing);
	}
}
