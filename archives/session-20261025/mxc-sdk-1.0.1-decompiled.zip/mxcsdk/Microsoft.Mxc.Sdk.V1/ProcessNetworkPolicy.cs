namespace Microsoft.Mxc.Sdk.V1;

public sealed class ProcessNetworkPolicy
{
	public NetworkRuntimeConfig? RuntimeConfig { get; set; }
}
