namespace Microsoft.Mxc.Sdk.V1;

public enum NetworkAction
{
	Allow,
	Deny
}
