using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class NetworkIngressPolicy
{
	[JsonPropertyName("default")]
	public NetworkAction? Default { get; set; }

	[JsonPropertyName("hostLoopback")]
	public NetworkAction? HostLoopback { get; set; }
}
