using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class NetworkPortPolicy
{
	[JsonPropertyName("protocol")]
	public NetworkProtocol? Protocol { get; set; }

	[JsonPropertyName("port")]
	public ushort? Port { get; set; }

	[JsonPropertyName("endPort")]
	public ushort? EndPort { get; set; }
}
