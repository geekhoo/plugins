using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Mxc.Sdk.Native;

namespace Microsoft.Mxc.Sdk.V1;

public class MxcProcess : IMxcProcess, IDisposable
{
	private enum ReadStreamState
	{
		Untaken,
		CallerOwned,
		Draining
	}

	private static readonly TimeSpan MinPollInterval = TimeSpan.FromMilliseconds(1.0);

	private static readonly TimeSpan MaxPollInterval = TimeSpan.FromMilliseconds(50.0);

	private readonly object _controlLock = new object();

	private readonly MxcSandboxHandle _handle;

	private bool _disposed;

	private MxcStdinStream? _stdin;

	private MxcReadPipeStream? _stdout;

	private MxcReadPipeStream? _stderr;

	private bool _stdinTaken;

	private ReadStreamState _stdoutState;

	private ReadStreamState _stderrState;

	private readonly List<Task> _drainTasks = new List<Task>();

	private readonly uint? _timeoutMs;

	private readonly long _startTimestamp = Stopwatch.GetTimestamp();

	public unsafe uint Id
	{
		get
		{
			lock (_controlLock)
			{
				ThrowIfDisposed();
				return NativeMethods.mxc_sandbox_id(_handle.Ptr);
			}
		}
	}

	public unsafe Stream? StandardInput
	{
		get
		{
			lock (_controlLock)
			{
				ThrowIfDisposed();
				if (!_stdinTaken)
				{
					_stdinTaken = true;
					MxcWriteStream* ptr = NativeMethods.mxc_sandbox_take_stdin(_handle.Ptr);
					_stdin = ((ptr == null) ? null : new MxcStdinStream(MxcWriteStreamHandle.FromRaw(ptr)));
				}
				return _stdin;
			}
		}
	}

	public Stream? StandardOutput => TakeReadStream(ref _stdoutState, ref _stdout, stdout: true);

	public Stream? StandardError => TakeReadStream(ref _stderrState, ref _stderr, stdout: false);

	public MxcStreamCloser? StandardOutputCloser => GetReadCloser(stdout: true);

	public MxcStreamCloser? StandardErrorCloser => GetReadCloser(stdout: false);

	IMxcStreamCloser? IMxcProcess.StandardOutputCloser => StandardOutputCloser;

	IMxcStreamCloser? IMxcProcess.StandardErrorCloser => StandardErrorCloser;

	public unsafe IReadOnlyList<string> Warnings
	{
		get
		{
			lock (_controlLock)
			{
				ThrowIfDisposed();
				byte* ptr = null;
				int num = NativeMethods.mxc_sandbox_warnings_json(_handle.Ptr, &ptr);
				if (num != 0)
				{
					throw new MxcException((ErrorCode)num, "retrieving sandbox security warnings failed");
				}
				if (ptr == null)
				{
					return Array.Empty<string>();
				}
				try
				{
					string text = Marshal.PtrToStringUTF8((nint)ptr);
					return string.IsNullOrEmpty(text) ? Array.Empty<string>() : (MxcJson.Deserialize<string[]>(text) ?? Array.Empty<string>());
				}
				finally
				{
					NativeMethods.mxc_string_free(ptr);
				}
			}
		}
	}

	public unsafe ExecutionMetadata? OutputMetadata
	{
		get
		{
			lock (_controlLock)
			{
				ThrowIfDisposed();
				byte* ptr = null;
				int num = NativeMethods.mxc_sandbox_output_metadata_json(_handle.Ptr, &ptr);
				if (num != 0)
				{
					throw new MxcException((ErrorCode)num, "retrieving sandbox output metadata failed");
				}
				if (ptr == null)
				{
					return null;
				}
				try
				{
					string text = Marshal.PtrToStringUTF8((nint)ptr);
					return string.IsNullOrEmpty(text) ? null : MxcJson.Deserialize<ExecutionMetadata>(text);
				}
				finally
				{
					NativeMethods.mxc_string_free(ptr);
				}
			}
		}
	}

	internal MxcProcess(MxcSandboxHandle handle, uint? timeoutMs = null)
	{
		_handle = handle;
		_timeoutMs = NormalizeTimeout(timeoutMs);
	}

	internal static uint? NormalizeTimeout(uint? timeoutMs)
	{
		if (!timeoutMs.HasValue || timeoutMs.GetValueOrDefault() != 0)
		{
			return timeoutMs;
		}
		return null;
	}

	private unsafe Stream? TakeReadStream(ref ReadStreamState state, ref MxcReadPipeStream? slot, bool stdout)
	{
		lock (_controlLock)
		{
			ThrowIfDisposed();
			switch (state)
			{
			case ReadStreamState.Untaken:
			{
				state = ReadStreamState.CallerOwned;
				MxcReadStream* ptr = (stdout ? NativeMethods.mxc_sandbox_take_stdout(_handle.Ptr) : NativeMethods.mxc_sandbox_take_stderr(_handle.Ptr));
				slot = ((ptr == null) ? null : new MxcReadPipeStream(MxcReadStreamHandle.FromRaw(ptr)));
				return slot;
			}
			case ReadStreamState.CallerOwned:
				return slot;
			default:
				throw new InvalidOperationException("this standard stream is being drained internally by a wait; take StandardOutput/StandardError before calling Wait/WaitAsync");
			}
		}
	}

	private unsafe MxcStreamCloser? GetReadCloser(bool stdout)
	{
		lock (_controlLock)
		{
			ThrowIfDisposed();
			ReadStreamState readStreamState = (stdout ? _stdoutState : _stderrState);
			MxcReadPipeStream mxcReadPipeStream = (stdout ? _stdout : _stderr);
			if (readStreamState != ReadStreamState.CallerOwned)
			{
				throw new InvalidOperationException("take the standard stream before requesting its closer");
			}
			if (mxcReadPipeStream == null)
			{
				return null;
			}
			Microsoft.Mxc.Sdk.Native.MxcStreamCloser* ptr = (stdout ? NativeMethods.mxc_sandbox_stdout_closer(_handle.Ptr) : NativeMethods.mxc_sandbox_stderr_closer(_handle.Ptr));
			return (ptr == null) ? null : new MxcStreamCloser(MxcStreamCloserHandle.FromRaw(ptr));
		}
	}

	public WaitResult Wait()
	{
		return WaitCore(CancellationToken.None);
	}

	public Task<WaitResult> WaitAsync(CancellationToken cancellationToken = default(CancellationToken))
	{
		return Task.Run(() => WaitCore(cancellationToken), cancellationToken);
	}

	public bool TryGetExitCode(out int exitCode)
	{
		bool timedOut;
		return TryGetTerminalStatus(out exitCode, out timedOut);
	}

	private unsafe bool TryGetTerminalStatus(out int exitCode, out bool timedOut)
	{
		lock (_controlLock)
		{
			ThrowIfDisposed();
			int num = 1;
			int num2 = 0;
			int num3 = 0;
			int num4 = NativeMethods.mxc_sandbox_try_wait(_handle.Ptr, &num2, &num, &num3);
			if (num4 != 0)
			{
				throw new MxcException((ErrorCode)num4, "querying the sandbox process status failed");
			}
			exitCode = num2;
			timedOut = num3 != 0;
			return num == 0;
		}
	}

	private WaitResult WaitCore(CancellationToken cancellationToken)
	{
		EnsureDrainUntaken();
		TimeSpan timeSpan = MinPollInterval;
		while (true)
		{
			cancellationToken.ThrowIfCancellationRequested();
			if (TryGetTerminalStatus(out var _, out var _))
			{
				return WaitBlocking();
			}
			uint? timeoutMs = _timeoutMs;
			if (timeoutMs.HasValue)
			{
				uint valueOrDefault = timeoutMs.GetValueOrDefault();
				if (Stopwatch.GetElapsedTime(_startTimestamp).TotalMilliseconds >= (double)valueOrDefault)
				{
					break;
				}
			}
			cancellationToken.WaitHandle.WaitOne(timeSpan);
			TimeSpan timeSpan2 = timeSpan + timeSpan;
			timeSpan = ((timeSpan2 > MaxPollInterval) ? MaxPollInterval : timeSpan2);
		}
		return WaitAfterDeadline();
	}

	private WaitResult WaitAfterDeadline()
	{
		if (TryGetTerminalStatus(out var _, out var _))
		{
			return WaitBlocking();
		}
		Kill();
		WaitResult waitResult = WaitBlocking();
		return new WaitResult
		{
			ExitCode = waitResult.ExitCode,
			TimedOut = true
		};
	}

	private unsafe WaitResult WaitBlocking()
	{
		EnsureDrainUntaken();
		lock (_controlLock)
		{
			ThrowIfDisposed();
			int exitCode = 0;
			int num = 0;
			int num2 = NativeMethods.mxc_sandbox_wait(_handle.Ptr, &exitCode, &num);
			if (num2 != 0)
			{
				throw new MxcException((ErrorCode)num2, "waiting on the sandbox failed");
			}
			return new WaitResult
			{
				ExitCode = exitCode,
				TimedOut = (num != 0)
			};
		}
	}

	public async Task<(WaitResult Result, byte[] Stdout, byte[] Stderr)> WaitForExitWithOutputAsync(CancellationToken cancellationToken = default(CancellationToken))
	{
		Stream outStream = StandardOutput;
		Stream errStream = StandardError;
		using (MxcStreamCloser outCloser = ((outStream == null) ? null : StandardOutputCloser))
		{
			using MxcStreamCloser errCloser = ((errStream == null) ? null : StandardErrorCloser);
			Task<byte[]> stdoutTask = ReadAll(outStream);
			Task<byte[]> stderrTask = ReadAll(errStream);
			try
			{
				return (Result: await WaitAsync(cancellationToken).ConfigureAwait(continueOnCapturedContext: false), Stdout: await stdoutTask.ConfigureAwait(continueOnCapturedContext: false), Stderr: await stderrTask.ConfigureAwait(continueOnCapturedContext: false));
			}
			catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
			{
				if (!(CloseQuietly(outCloser, outStream != null) & CloseQuietly(errCloser, errStream != null)))
				{
					KillQuietly();
				}
				await Task.WhenAll(new Task[2]
				{
					SwallowAsync(stdoutTask),
					SwallowAsync(stderrTask)
				}).ConfigureAwait(continueOnCapturedContext: false);
				outStream?.Dispose();
				errStream?.Dispose();
				throw;
			}
			catch
			{
				KillQuietly();
				await Task.WhenAll(new Task[2]
				{
					SwallowAsync(stdoutTask),
					SwallowAsync(stderrTask)
				}).ConfigureAwait(continueOnCapturedContext: false);
				throw;
			}
		}
		IL_0475:
		throw null;
		Task<byte[]> ReadAll(Stream? s)
		{
			if (s != null)
			{
				return ReadToEndAsync(s, cancellationToken);
			}
			return Task.FromResult(Array.Empty<byte>());
		}
	}

	private static bool CloseQuietly(MxcStreamCloser? closer, bool required)
	{
		if (closer == null)
		{
			return !required;
		}
		try
		{
			closer.Close();
			return true;
		}
		catch (ObjectDisposedException)
		{
			return false;
		}
		catch (MxcException)
		{
			return false;
		}
	}

	private void KillQuietly()
	{
		try
		{
			Kill();
		}
		catch (ObjectDisposedException)
		{
		}
		catch (MxcException)
		{
		}
	}

	private static async Task SwallowAsync(Task task)
	{
		try
		{
			await task.ConfigureAwait(continueOnCapturedContext: false);
		}
		catch
		{
		}
	}

	private static async Task<byte[]> ReadToEndAsync(Stream s, CancellationToken ct)
	{
		using MemoryStream ms = new MemoryStream();
		await s.CopyToAsync(ms, ct).ConfigureAwait(continueOnCapturedContext: false);
		return ms.ToArray();
	}

	public unsafe void Kill()
	{
		lock (_controlLock)
		{
			ThrowIfDisposed();
			int num = NativeMethods.mxc_sandbox_kill(_handle.Ptr);
			if (num != 0)
			{
				throw new MxcException((ErrorCode)num, "killing the sandbox failed");
			}
		}
	}

	protected unsafe void ResizePty(MxcPtySize size)
	{
		lock (_controlLock)
		{
			ThrowIfDisposed();
			int num = NativeMethods.mxc_sandbox_pty_resize(_handle.Ptr, size.Rows, size.Columns);
			if (num != 0)
			{
				throw new MxcException((ErrorCode)num, "resizing sandbox PTY failed");
			}
		}
	}

	private void EnsureDrainUntaken()
	{
		lock (_controlLock)
		{
			ThrowIfDisposed();
			DrainIfUntaken(ref _stdoutState, ref _stdout, stdout: true);
			DrainIfUntaken(ref _stderrState, ref _stderr, stdout: false);
		}
	}

	private unsafe void DrainIfUntaken(ref ReadStreamState state, ref MxcReadPipeStream? slot, bool stdout)
	{
		if (state != ReadStreamState.Untaken)
		{
			return;
		}
		MxcReadStream* ptr = (stdout ? NativeMethods.mxc_sandbox_take_stdout(_handle.Ptr) : NativeMethods.mxc_sandbox_take_stderr(_handle.Ptr));
		if (ptr == null)
		{
			state = ReadStreamState.CallerOwned;
			return;
		}
		slot = new MxcReadPipeStream(MxcReadStreamHandle.FromRaw(ptr));
		state = ReadStreamState.Draining;
		MxcReadPipeStream stream = slot;
		_drainTasks.Add(Task.Run(() =>
		{
			try
			{
				stream.CopyTo(Stream.Null);
			}
			catch
			{
			}
		}));
	}

	private void ThrowIfDisposed()
	{
		if (_disposed)
		{
			throw new ObjectDisposedException("MxcProcess");
		}
	}

	public void Dispose()
	{
		List<Task> list;
		lock (_controlLock)
		{
			if (_disposed)
			{
				return;
			}
			_disposed = true;
			list = new List<Task>(_drainTasks);
		}
		_handle.Dispose();
		try
		{
			Task.WaitAll(list.ToArray());
		}
		catch
		{
		}
		_stdin?.Dispose();
		_stdout?.Dispose();
		_stderr?.Dispose();
	}
}
