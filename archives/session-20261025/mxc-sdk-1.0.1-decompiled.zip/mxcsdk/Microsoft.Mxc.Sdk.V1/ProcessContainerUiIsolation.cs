namespace Microsoft.Mxc.Sdk.V1;

public enum ProcessContainerUiIsolation
{
	Desktop,
	Handles,
	Atoms,
	Container
}
