namespace Microsoft.Mxc.Sdk.V1;

public enum IsolationTier
{
	Unknown,
	BaseContainer,
	AppContainerBfs,
	AppContainerDacl
}
