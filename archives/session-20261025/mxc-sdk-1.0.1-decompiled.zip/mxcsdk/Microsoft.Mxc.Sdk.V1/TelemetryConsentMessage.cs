namespace Microsoft.Mxc.Sdk.V1;

public sealed record TelemetryConsentMessage(string Id, string Text);
