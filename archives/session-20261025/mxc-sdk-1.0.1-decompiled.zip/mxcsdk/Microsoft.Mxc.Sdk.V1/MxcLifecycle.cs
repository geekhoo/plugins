using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Mxc.Sdk.Native;

namespace Microsoft.Mxc.Sdk.V1;

public static class MxcLifecycle
{
	public const string SdkContractVersion = "1.0.0";

	public const string IsolationSessionContainment = "isolation_session";

	public const string WslcContainment = "wslc";

	private const int ExperimentalOptIn = 1;

	private const int NoExperimentalOptIn = 0;

	static MxcLifecycle()
	{
		NativeLibraryResolver.Initialize();
	}

	public static ProvisionResult ProvisionContainer(ProvisionRequest request, ProvisionOptions? options = null)
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		LifecycleContainmentKind containment = request.Containment;
		JsonObject result = RunEnvelopePhase(BuildProvisionEnvelope(containment, request, options?.Telemetry), dryRun: false) ?? throw new MxcException(ErrorCode.BackendError, "provision response carried no result object");
		return ParseProvisionResult(containment, result);
	}

	internal static ProvisionResult ParseProvisionResult(LifecycleContainmentKind containment, JsonObject result)
	{
		if (!(result["sandboxId"] is JsonValue jsonValue) || !jsonValue.TryGetValue<string>(out string value) || value == null)
		{
			throw new MxcException(ErrorCode.BackendError, "provision response carried no sandboxId");
		}
		string text = result["metadata"]?.ToJsonString();
		ProvisionMetadata metadata = null;
		if (text != null)
		{
			if (containment != LifecycleContainmentKind.IsolationSession)
			{
				throw new MxcException(ErrorCode.BackendError, $"provision response carried unsupported metadata for {containment}");
			}
			IsolationSessionProvisionMetadata isolationSessionProvisionMetadata;
			try
			{
				isolationSessionProvisionMetadata = MxcJson.Deserialize<IsolationSessionProvisionMetadata>(text);
			}
			catch (JsonException ex)
			{
				throw new MxcException(ErrorCode.BackendError, "provision response carried malformed IsolationSession metadata: " + ex.Message);
			}
			if (isolationSessionProvisionMetadata == null || isolationSessionProvisionMetadata.AgentUserName == null || isolationSessionProvisionMetadata.AgentUserSid == null || isolationSessionProvisionMetadata.EphemeralWorkspacePath == null)
			{
				throw new MxcException(ErrorCode.BackendError, "provision response carried incomplete IsolationSession metadata");
			}
			metadata = isolationSessionProvisionMetadata;
		}
		return new ProvisionResult
		{
			ContainerId = new ContainerId(value),
			Metadata = metadata,
			Warnings = ParseLifecycleResult(result).Warnings
		};
	}

	public static ValidationResult ValidateProvision(ProvisionRequest request, ProvisionOptions? options = null)
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		return ParseValidationResult(RunEnvelopePhase(BuildProvisionEnvelope(request.Containment, request, options?.Telemetry), dryRun: true));
	}

	internal static JsonObject BuildProvisionEnvelope(LifecycleContainmentKind containment, ProvisionRequest? options, TelemetryConfig? telemetry = null)
	{
		ValidateProvisionOptions(containment, options);
		string text = ContainmentKey(containment);
		JsonObject jsonObject = NewEnvelope("provision");
		jsonObject["containment"] = text;
		if (!(options is IsolationSessionProvisionRequest isolationSessionProvisionRequest))
		{
			if (options is WslcProvisionRequest wslcProvisionRequest)
			{
				SetCrossCuttingPolicies(jsonObject, wslcProvisionRequest.Filesystem, wslcProvisionRequest.Network);
				SetOptionalBackendConfig(jsonObject, text, "provision", "image", wslcProvisionRequest.Image);
				SetOptionalBackendConfig(jsonObject, text, "provision", "imageTarPath", wslcProvisionRequest.ImageTarPath);
			}
		}
		else
		{
			SetCrossCuttingPolicies(jsonObject, null, isolationSessionProvisionRequest.Network);
			SetOptionalBackendConfig(jsonObject, text, "provision", "appId", isolationSessionProvisionRequest.AppId);
		}
		ApplyTelemetry(jsonObject, telemetry ?? options?.Telemetry);
		return jsonObject;
	}

	public static LifecycleResult StartContainer(ContainerId id, StartOptions? options = null)
	{
		return ParseLifecycleResult(RunEnvelopePhase(BuildStartEnvelope(id, options), dryRun: false));
	}

	public static ValidationResult ValidateStart(ContainerId id, StartOptions? options = null)
	{
		return ParseValidationResult(RunEnvelopePhase(BuildStartEnvelope(id, options), dryRun: true));
	}

	internal static JsonObject BuildStartEnvelope(ContainerId id, StartOptions? options = null)
	{
		JsonObject jsonObject = BuildIdEnvelope("start", id);
		ApplyTelemetry(jsonObject, options?.Telemetry);
		return jsonObject;
	}

	public unsafe static MxcProcess SpawnInContainer(ContainerId id, ExecutionRequest request, SpawnInContainerOptions? options = null)
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		fixed (byte* request_json_utf = ToNullTerminatedUtf8(BuildExecEnvelope(id, request, options?.Telemetry).ToJsonString()))
		{
			MxcSandbox* ptr = null;
			MxcErrorDetail detail = default;
			int num = NativeMethods.mxc_exec_state_aware_json(request_json_utf, 0, &ptr, &detail);
			if (num != 0)
			{
				try
				{
					throw NativeError.ToException(num, detail, "unknown error");
				}
				finally
				{
					NativeMethods.mxc_error_detail_free(&detail);
				}
			}
			return new MxcProcess(MxcSandboxHandle.FromRaw(ptr), MxcProcess.NormalizeTimeout(request.TimeoutMs));
		}
	}

	public static Task<MxcProcess> SpawnInContainerAsync(ContainerId id, ExecutionRequest request, SpawnInContainerOptions? options = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		return RunBlockingOperationAsync(() => SpawnInContainer(id, request, options), (MxcProcess lateProc) =>
		{
			lateProc.Dispose();
		}, cancellationToken);
	}

	public unsafe static MxcPtyProcess SpawnInContainerWithPty(ContainerId id, ExecutionRequest request, SpawnInContainerWithPtyOptions? options = null)
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		MxcPtySize mxcPtySize = MxcPtySize.ResolveInitial(options?.Size);
		mxcPtySize.Validate("options");
		fixed (byte* request_json_utf = ToNullTerminatedUtf8(BuildExecEnvelope(id, request, options?.Telemetry).ToJsonString()))
		{
			MxcSandbox* ptr = null;
			MxcErrorDetail detail = default;
			int num = NativeMethods.mxc_state_aware_exec_pty(request_json_utf, 0, mxcPtySize.Rows, mxcPtySize.Columns, &ptr, &detail);
			if (num != 0)
			{
				try
				{
					throw NativeError.ToException(num, detail, "spawning process with PTY failed");
				}
				finally
				{
					NativeMethods.mxc_error_detail_free(&detail);
				}
			}
			return new MxcPtyProcess(MxcSandboxHandle.FromRaw(ptr), MxcProcess.NormalizeTimeout(request.TimeoutMs));
		}
	}

	public static ValidationResult ValidateProcess(ContainerId id, ExecutionRequest request, SpawnInContainerOptions? options = null)
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		return ParseValidationResult(RunEnvelopePhase(BuildExecEnvelope(id, request, options?.Telemetry), dryRun: true));
	}

	internal static JsonObject BuildExecEnvelope(ContainerId id, ExecutionRequest request, TelemetryConfig? telemetry = null)
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		ValidateExecOptions(id, request);
		JsonObject jsonObject = BuildIdEnvelope("exec", id);
		JsonObject jsonObject2 = new JsonObject { ["commandLine"] = request.Command };
		string workingDirectory = request.WorkingDirectory;
		if (workingDirectory != null)
		{
			jsonObject2["cwd"] = workingDirectory;
		}
		Dictionary<string, string> environment = request.Environment;
		if (environment != null)
		{
			jsonObject2["env"] = SerializeToNode(ExactOneShotRequestWriter.Environment(environment));
		}
		bool? inheritDefaultEnvironment = request.InheritDefaultEnvironment;
		if (inheritDefaultEnvironment.HasValue)
		{
			bool valueOrDefault = inheritDefaultEnvironment == true;
			jsonObject2["inheritDefaultEnv"] = valueOrDefault;
		}
		uint? timeoutMs = request.TimeoutMs;
		if (timeoutMs.HasValue)
		{
			uint valueOrDefault2 = timeoutMs.GetValueOrDefault();
			jsonObject2["timeout"] = valueOrDefault2;
		}
		jsonObject["process"] = jsonObject2;
		NetworkRuntimeConfig networkRuntimeConfig = request.Network?.RuntimeConfig;
		if (networkRuntimeConfig != null)
		{
			jsonObject["runtimeConfig"] = SerializeToNode(networkRuntimeConfig);
		}
		ApplyTelemetry(jsonObject, telemetry ?? request.Telemetry);
		return jsonObject;
	}

	public static async Task<ExecutionResult> RunInContainerAsync(ContainerId id, ExecutionRequest request, RunInContainerOptions? options = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		MxcProcess proc = await SpawnInContainerAsync(id, request, new SpawnInContainerOptions
		{
			Telemetry = options?.Telemetry
		}, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		try
		{
			var (waitResult, bytes, bytes2) = await proc.WaitForExitWithOutputAsync(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
			return new ExecutionResult
			{
				ExitCode = waitResult.ExitCode,
				TimedOut = waitResult.TimedOut,
				Stdout = Encoding.UTF8.GetString(bytes),
				Stderr = Encoding.UTF8.GetString(bytes2),
				OutputMetadata = proc.OutputMetadata,
				Warnings = proc.Warnings
			};
		}
		finally
		{
			proc.Dispose();
		}
	}

	public static ExecutionResult RunInContainer(ContainerId id, ExecutionRequest request, RunInContainerOptions? options = null)
	{
		return RunInContainerAsync(id, request, options).GetAwaiter().GetResult();
	}

	private unsafe static WaitResult ExecuteInContainerAttached(ContainerId id, ExecutionRequest request)
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		fixed (byte* request_json_utf = ToNullTerminatedUtf8(BuildExecEnvelope(id, request).ToJsonString()))
		{
			MxcExecOutcome mxcExecOutcome = default;
			MxcErrorDetail detail = default;
			int num = NativeMethods.mxc_exec_state_aware_attached_json(request_json_utf, ExperimentalOptInFor(id), &mxcExecOutcome, &detail);
			try
			{
				if (num != 0)
				{
					throw NativeError.ToException(num, detail, "unknown error");
				}
				return new WaitResult
				{
					ExitCode = mxcExecOutcome.exit_code,
					TimedOut = (mxcExecOutcome.timed_out != 0)
				};
			}
			finally
			{
				NativeMethods.mxc_error_detail_free(&detail);
			}
		}
	}

	internal static async Task<T> RunBlockingOperationAsync<T>(Func<T> operation, Action<T> disposeLateResult, CancellationToken cancellationToken)
	{
		cancellationToken.ThrowIfCancellationRequested();
		Task<T> task = Task.Run(operation, cancellationToken);
		try
		{
			return await task.WaitAsync(cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		}
		catch (OperationCanceledException)
		{
			task.ContinueWith((Task<T> t) =>
			{
				if (t.Status == TaskStatus.RanToCompletion)
				{
					try
					{
						disposeLateResult(t.Result);
						return;
					}
					catch
					{
						return;
					}
				}
				if (t.IsFaulted)
				{
					_ = t.Exception;
				}
			}, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
			throw;
		}
	}

	public static LifecycleResult StopContainer(ContainerId id, StopOptions? options = null)
	{
		return ParseLifecycleResult(RunEnvelopePhase(BuildStopEnvelope(id, options), dryRun: false));
	}

	public static ValidationResult ValidateStop(ContainerId id, StopOptions? options = null)
	{
		return ParseValidationResult(RunEnvelopePhase(BuildStopEnvelope(id, options), dryRun: true));
	}

	internal static JsonObject BuildStopEnvelope(ContainerId id, StopOptions? options = null)
	{
		JsonObject jsonObject = BuildIdEnvelope("stop", id);
		ApplyTelemetry(jsonObject, options?.Telemetry);
		return jsonObject;
	}

	public static LifecycleResult DeprovisionContainer(ContainerId id, DeprovisionOptions? options = null)
	{
		return ParseLifecycleResult(RunEnvelopePhase(BuildDeprovisionEnvelope(id, options), dryRun: false));
	}

	public static ValidationResult ValidateDeprovision(ContainerId id, DeprovisionOptions? options = null)
	{
		return ParseValidationResult(RunEnvelopePhase(BuildDeprovisionEnvelope(id, options), dryRun: true));
	}

	internal static ValidationResult ParseValidationResult(JsonObject? result)
	{
		return new ValidationResult
		{
			Warnings = ParseWarnings(result, "validation")
		};
	}

	internal static LifecycleResult ParseLifecycleResult(JsonObject? result)
	{
		return new LifecycleResult
		{
			Warnings = ParseWarnings(result, "lifecycle")
		};
	}

	private static string[] ParseWarnings(JsonObject? result, string operation)
	{
		if (result == null)
		{
			throw new MxcException(ErrorCode.BackendError, operation + " response carried no result object");
		}
		ValidationResult validationResult;
		try
		{
			validationResult = MxcJson.Deserialize<ValidationResult>(result.ToJsonString());
		}
		catch (JsonException ex)
		{
			throw new MxcException(ErrorCode.BackendError, operation + " response carried malformed warnings: " + ex.Message);
		}
		if (validationResult?.Warnings == null || validationResult.Warnings.Any((string warning) => warning == null))
		{
			throw new MxcException(ErrorCode.BackendError, operation + " response carried malformed warnings");
		}
		return validationResult.Warnings;
	}

	internal static JsonObject BuildDeprovisionEnvelope(ContainerId id, DeprovisionOptions? options = null)
	{
		JsonObject jsonObject = BuildIdEnvelope("deprovision", id);
		ApplyTelemetry(jsonObject, options?.Telemetry);
		return jsonObject;
	}

	private static JsonObject BuildIdEnvelope(string phase, ContainerId id)
	{
		ContainmentForId(id);
		JsonObject jsonObject = NewEnvelope(phase);
		jsonObject["sandboxId"] = id.Value;
		return jsonObject;
	}

	private static JsonObject NewEnvelope(string phase)
	{
		return new JsonObject
		{
			["version"] = "1.0.0",
			["phase"] = phase
		};
	}

	private static void ApplyTelemetry(JsonObject envelope, TelemetryConfig? telemetry)
	{
		if (telemetry != null)
		{
			envelope["telemetry"] = SerializeToNode(telemetry);
		}
	}

	private static string ContainmentKey(LifecycleContainmentKind containment)
	{
		return containment switch
		{
			LifecycleContainmentKind.IsolationSession => "isolation_session", 
			LifecycleContainmentKind.Wslc => "wslc", 
			_ => throw new MxcException(ErrorCode.UnsupportedContainment, $"unknown state-aware containment '{containment}'"), 
		};
	}

	private static void ValidateProvisionOptions(LifecycleContainmentKind containment, ProvisionRequest? options)
	{
		bool flag;
		if (containment == LifecycleContainmentKind.IsolationSession)
		{
			if (options != null)
			{
				if (!(options is IsolationSessionProvisionRequest))
				{
					goto IL_0031;
				}
				flag = true;
			}
			else
			{
				flag = false;
			}
		}
		else if (options != null)
		{
			if (containment != LifecycleContainmentKind.Wslc || !(options is WslcProvisionRequest))
			{
				goto IL_0031;
			}
			flag = true;
		}
		else
		{
			flag = true;
		}
		goto IL_0033;
		IL_0183:
		if (options is WslcProvisionRequest wslcProvisionRequest)
		{
			NetworkPolicy network = wslcProvisionRequest.Network;
			if (network != null)
			{
				ValidateDirectionalNetwork(network);
			}
		}
		return;
		IL_0031:
		flag = false;
		goto IL_0033;
		IL_0033:
		if (!flag)
		{
			throw new ArgumentException((options == null) ? $"{containment} requires backend-specific provision options" : $"{options.GetType().Name} cannot configure {containment}", "options");
		}
		if (options is IsolationSessionProvisionRequest isolationSessionProvisionRequest)
		{
			ValidateDirectionalNetwork(isolationSessionProvisionRequest.Network);
			NetworkEgressPolicy? egress = isolationSessionProvisionRequest.Network.Egress;
			if (egress != null && egress.Default == NetworkAction.Allow && isolationSessionProvisionRequest.Network.Egress.Allow == null && isolationSessionProvisionRequest.Network.Egress.Deny == null)
			{
				NetworkIngressPolicy? ingress = isolationSessionProvisionRequest.Network.Ingress;
				if (ingress != null && ingress.Default == NetworkAction.Allow && isolationSessionProvisionRequest.Network.Ingress.HostLoopback == NetworkAction.Allow)
				{
					goto IL_0183;
				}
			}
			throw new ArgumentException("IsolationSession requires directional egress, ingress, and host-loopback defaults set to Allow, with no rules.", "options");
		}
		goto IL_0183;
	}

	private static void ValidateExecOptions(ContainerId id, ExecutionRequest? options)
	{
		LifecycleContainmentKind lifecycleContainmentKind = ContainmentForId(id);
		NetworkRuntimeConfig? networkRuntimeConfig = options?.Network?.RuntimeConfig;
		if (networkRuntimeConfig != null && lifecycleContainmentKind != LifecycleContainmentKind.Wslc)
		{
			throw new ArgumentException("network.runtimeConfig requires a wslc: container id", "options");
		}
		string text = networkRuntimeConfig?.NetworkProxy;
		if (text != null && (string.IsNullOrWhiteSpace(text) || text.Trim() != text || !Uri.TryCreate(text, UriKind.Absolute, out Uri result) || (result.Scheme != Uri.UriSchemeHttp && result.Scheme != Uri.UriSchemeHttps)))
		{
			throw new ArgumentException("network.runtimeConfig.networkProxy must be an HTTP/S URL string.", "options");
		}
	}

	private static void ValidateDirectionalNetwork(NetworkPolicy network)
	{
		ArgumentNullException.ThrowIfNull(network, "network");
	}

	private static LifecycleContainmentKind ContainmentForId(ContainerId id)
	{
		string value = id.Value;
		int num = value?.IndexOf(':', StringComparison.Ordinal) ?? (-1);
		if (num <= 0)
		{
			throw new MxcException(ErrorCode.MalformedId, $"container id '{id}' is missing the '<prefix>:...' form");
		}
		return value.Substring(0, num) switch
		{
			"iso" => LifecycleContainmentKind.IsolationSession, 
			"wslc" => LifecycleContainmentKind.Wslc, 
			"wsb" => throw new MxcException(ErrorCode.UnsupportedContainment, "Windows Sandbox container ids with the 'wsb:' prefix require the raw exact 1.1.0-alpha state-aware executor route with explicit experimental authorization; stable MxcLifecycle accepts only 'iso:' and 'wslc:' ids."), 
			_ => throw new MxcException(ErrorCode.UnsupportedContainment, "no state-aware backend is registered for container id '" + id.Value + "'"), 
		};
	}

	private static void SetCrossCuttingPolicies(JsonObject envelope, FilesystemPolicy? filesystem, NetworkPolicy? network)
	{
		if (filesystem != null)
		{
			envelope["filesystem"] = SerializeToNode(filesystem);
		}
		if (network != null)
		{
			JsonObject jsonObject = SerializeToNode(network).AsObject();
			jsonObject.Remove("runtimeConfig");
			envelope["network"] = jsonObject;
			if (network.RuntimeConfig != null)
			{
				envelope["runtimeConfig"] = SerializeToNode(network.RuntimeConfig);
			}
		}
	}

	private static void SetOptionalBackendConfig(JsonObject envelope, string backend, string phase, string key, string? value)
	{
		if (value != null)
		{
			SetBackendConfig(envelope, backend, phase, key, value);
		}
	}

	private static void SetBackendConfig(JsonObject envelope, string backend, string phase, string key, JsonNode? value)
	{
		string text;
		if (!(backend == "isolation_session"))
		{
			if (!(backend == "wslc"))
			{
				throw new ArgumentException("Unsupported state-aware backend '" + backend + "'.", "backend");
			}
			text = "wslc";
		}
		else
		{
			text = "isolationSession";
		}
		string propertyName = text;
		JsonObject jsonObject = envelope[propertyName] as JsonObject;
		if (jsonObject == null)
		{
			jsonObject = (JsonObject)(envelope[propertyName] = new JsonObject());
		}
		JsonObject jsonObject2 = jsonObject[phase] as JsonObject;
		if (jsonObject2 == null)
		{
			jsonObject2 = (JsonObject)(jsonObject[phase] = new JsonObject());
		}
		jsonObject2[key] = value;
	}

	private unsafe static JsonObject? RunEnvelopePhase(JsonObject envelope, bool dryRun, bool experimental = false)
	{
		fixed (byte* request_json_utf = ToNullTerminatedUtf8(envelope.ToJsonString()))
		{
			MxcStateAwareResult mxcStateAwareResult = default;
			int num = NativeMethods.mxc_run_state_aware_json(request_json_utf, dryRun ? 1 : 0, experimental ? 1 : 0, &mxcStateAwareResult);
			try
			{
				if (num != 0)
				{
					throw NativeError.ToException(num, mxcStateAwareResult.error, "unknown error");
				}
				return (JsonNode.Parse(PtrToString(mxcStateAwareResult.response_json_utf8) ?? "{}") as JsonObject)?["result"] as JsonObject;
			}
			finally
			{
				NativeMethods.mxc_state_aware_result_free(&mxcStateAwareResult);
			}
		}
	}

	private static int ExperimentalOptInFor(ContainerId id)
	{
		ContainmentForId(id);
		return 0;
	}

	private static int ExperimentalOptInFor(JsonObject envelope)
	{
		if (envelope["containment"]?.GetValue<string>() != null)
		{
			return 0;
		}
		string text = envelope["sandboxId"]?.GetValue<string>();
		if (text != null)
		{
			return ExperimentalOptInFor(new ContainerId(text));
		}
		return 0;
	}

	private static JsonNode? SerializeToNode<T>(T value)
	{
		return MxcJson.SerializeToNode(value, MxcJson.Options);
	}

	private static byte[] ToNullTerminatedUtf8(string value)
	{
		int byteCount = Encoding.UTF8.GetByteCount(value);
		byte[] array = new byte[byteCount + 1];
		Encoding.UTF8.GetBytes(value, 0, value.Length, array, 0);
		array[byteCount] = 0;
		return array;
	}

	private unsafe static string? PtrToString(byte* p)
	{
		if (p != null)
		{
			return Marshal.PtrToStringUTF8((nint)p);
		}
		return null;
	}
}
