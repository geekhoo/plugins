using System;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

internal sealed class NativePlatformSupport
{
	[JsonPropertyName("isSupported")]
	public bool IsSupported { get; set; }

	[JsonPropertyName("reason")]
	public string? Reason { get; set; }

	[JsonPropertyName("availableMethods")]
	public string[] AvailableMethods { get; set; } = Array.Empty<string>();
}
