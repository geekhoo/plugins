using System;

namespace Microsoft.Mxc.Sdk.V1;

public readonly record struct MxcPtySize(ushort Rows, ushort Columns)
{
	public static MxcPtySize Default { get; } = new MxcPtySize(24, 80);

	internal static MxcPtySize ResolveInitial(MxcPtySize? requested)
	{
		return requested ?? Default;
	}

	internal void Validate(string paramName)
	{
		if (Rows == 0 || Columns == 0 || Rows > 32767 || Columns > 32767)
		{
			throw new ArgumentOutOfRangeException(paramName, "PTY rows and columns must be between 1 and 32767.");
		}
	}
}
