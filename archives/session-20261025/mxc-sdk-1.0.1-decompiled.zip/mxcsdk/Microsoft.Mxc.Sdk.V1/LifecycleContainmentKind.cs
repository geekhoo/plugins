namespace Microsoft.Mxc.Sdk.V1;

public enum LifecycleContainmentKind
{
	IsolationSession,
	Wslc
}
