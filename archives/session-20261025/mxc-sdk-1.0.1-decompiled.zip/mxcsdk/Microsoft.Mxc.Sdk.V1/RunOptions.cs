namespace Microsoft.Mxc.Sdk.V1;

public sealed class RunOptions
{
	public TelemetryConfig? Telemetry { get; set; }
}
