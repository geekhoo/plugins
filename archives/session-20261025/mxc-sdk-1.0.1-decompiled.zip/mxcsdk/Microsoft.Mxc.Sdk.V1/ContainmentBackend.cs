namespace Microsoft.Mxc.Sdk.V1;

public enum ContainmentBackend
{
	Unknown,
	ProcessContainer,
	WindowsSandbox,
	Lxc,
	Wslc,
	Seatbelt,
	IsolationSession,
	Bubblewrap,
	Hyperlight
}
