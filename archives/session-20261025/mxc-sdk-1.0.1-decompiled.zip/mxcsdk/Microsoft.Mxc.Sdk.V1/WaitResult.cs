namespace Microsoft.Mxc.Sdk.V1;

public readonly struct WaitResult
{
	public int ExitCode { get; init; }

	public bool TimedOut { get; init; }
}
