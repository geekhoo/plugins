using System;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class ProvisionResult
{
	public ContainerId ContainerId { get; init; }

	public ProvisionMetadata? Metadata { get; init; }

	public string[] Warnings { get; set; } = Array.Empty<string>();
}
