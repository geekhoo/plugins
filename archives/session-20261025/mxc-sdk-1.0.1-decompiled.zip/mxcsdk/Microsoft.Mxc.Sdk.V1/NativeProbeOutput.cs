using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

internal sealed class NativeProbeOutput
{
	private string? tier;

	private bool? needsDaclAugmentation;

	private string? error;

	internal bool HasTier { get; private set; }

	internal bool HasNeedsDaclAugmentation { get; private set; }

	internal bool HasError { get; private set; }

	[JsonPropertyName("tier")]
	public string? Tier
	{
		get
		{
			return tier;
		}
		set
		{
			tier = value;
			HasTier = true;
		}
	}

	[JsonPropertyName("needsDaclAugmentation")]
	public bool? NeedsDaclAugmentation
	{
		get
		{
			return needsDaclAugmentation;
		}
		set
		{
			needsDaclAugmentation = value;
			HasNeedsDaclAugmentation = true;
		}
	}

	[JsonRequired]
	[JsonPropertyName("warnings")]
	public string?[]? Warnings { get; set; }

	[JsonRequired]
	[JsonPropertyName("probes")]
	public NativeProbeFacts? Probes { get; set; }

	[JsonPropertyName("error")]
	public string? Error
	{
		get
		{
			return error;
		}
		set
		{
			error = value;
			HasError = true;
		}
	}
}
