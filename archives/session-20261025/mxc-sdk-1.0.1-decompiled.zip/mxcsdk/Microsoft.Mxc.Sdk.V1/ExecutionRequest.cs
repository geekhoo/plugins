using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

[JsonUnmappedMemberHandling(JsonUnmappedMemberHandling.Disallow)]
public sealed class ExecutionRequest
{
	internal string? Version { get; set; }

	public TelemetryConfig? Telemetry { get; set; }

	public string Command { get; }

	public string? WorkingDirectory { get; set; }

	public Dictionary<string, string>? Environment { get; set; }

	public bool? InheritDefaultEnvironment { get; set; }

	public uint? TimeoutMs { get; set; }

	public ProcessNetworkPolicy? Network { get; set; }

	public ExecutionRequest(string command)
	{
		ArgumentNullException.ThrowIfNull(command, "command");
		Command = command;
	}
}
