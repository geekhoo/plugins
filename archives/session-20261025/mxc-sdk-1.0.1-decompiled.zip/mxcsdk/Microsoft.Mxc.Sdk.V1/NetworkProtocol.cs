namespace Microsoft.Mxc.Sdk.V1;

public enum NetworkProtocol
{
	Tcp,
	Udp,
	Icmp,
	Any
}
