using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace Microsoft.Mxc.Sdk.V1;

public interface IMxcProcess : IDisposable
{
	uint Id { get; }

	Stream? StandardInput { get; }

	Stream? StandardOutput { get; }

	Stream? StandardError { get; }

	IMxcStreamCloser? StandardOutputCloser { get; }

	IMxcStreamCloser? StandardErrorCloser { get; }

	IReadOnlyList<string> Warnings { get; }

	ExecutionMetadata? OutputMetadata { get; }

	WaitResult Wait();

	Task<WaitResult> WaitAsync(CancellationToken cancellationToken = default(CancellationToken));

	bool TryGetExitCode(out int exitCode);

	Task<(WaitResult Result, byte[] Stdout, byte[] Stderr)> WaitForExitWithOutputAsync(CancellationToken cancellationToken = default(CancellationToken));

	void Kill();
}
