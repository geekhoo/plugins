using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Microsoft.Mxc.Sdk.Generated;

namespace Microsoft.Mxc.Sdk.V1;

internal static class ExactOneShotRequestWriter
{
	internal static readonly JsonSerializerOptions JsonOptions = MxcJson.Options;

	internal static string Serialize(ContainerRequest request, TelemetryConfig? telemetry = null)
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		return MxcJson.Serialize(ToWire(request, telemetry), JsonOptions);
	}

	internal static OneShotRequest ToWire(ContainerRequest request, TelemetryConfig? telemetry = null)
	{
		ArgumentNullException.ThrowIfNull(request, "request");
		OneShotRequest oneShotRequest = new OneShotRequest
		{
			Version = "1.0.0",
			ContainerId = ((request.ContainerName == null) ? MintContainerId() : request.ContainerName),
			Containment = Containment(request.Containment)
		};
		Lifecycle lifecycle = new Lifecycle
		{
			DestroyOnExit = true
		};
		FilesystemPolicy? filesystem = request.Filesystem;
		lifecycle.PreservePolicy = filesystem != null && filesystem.ClearPolicyOnExit == false;
		oneShotRequest.Lifecycle = lifecycle;
		oneShotRequest.Process = Process(request);
		oneShotRequest.Filesystem = Filesystem(request.Filesystem);
		oneShotRequest.Network = Network(request.Network);
		oneShotRequest.RuntimeConfig = RuntimeConfig(request.Network?.RuntimeConfig);
		oneShotRequest.Ui = Ui(request.Ui);
		oneShotRequest.Telemetry = ((telemetry == null) ? null : new Telemetry
		{
			Enabled = telemetry.Enabled
		});
		OneShotRequest oneShotRequest2 = oneShotRequest;
		Containment containment = request.Containment;
		if (!(containment is Containment.Process) && !(containment is Containment.Bubblewrap) && !(containment is Containment.IsolationSession))
		{
			if (!(containment is Containment.ProcessContainer containment2))
			{
				if (!(containment is Containment.Lxc lxc))
				{
					if (!(containment is Containment.Seatbelt containment3))
					{
						if (!(containment is Containment.Wslc containment4))
						{
							throw new ArgumentException("unsupported containment type '" + request.Containment.GetType().Name + "'", "request");
						}
						oneShotRequest2.Wslc = Wslc(containment4);
					}
					else
					{
						oneShotRequest2.Seatbelt = Seatbelt(containment3);
					}
				}
				else
				{
					oneShotRequest2.Lxc = new Lxc
					{
						Distribution = lxc.Distribution,
						Release = lxc.Release
					};
				}
			}
			else
			{
				oneShotRequest2.ProcessContainer = ProcessContainer(containment2);
			}
		}
		return oneShotRequest2;
	}

	private static string MintContainerId()
	{
		return $"dotnet-{Guid.NewGuid():N}";
	}

	private static Process Process(ContainerRequest request)
	{
		Process process = new Process
		{
			CommandLine = request.Command,
			Cwd = request.WorkingDirectory,
			Env = Environment(request.Environment),
			Timeout = request.TimeoutMs.GetValueOrDefault()
		};
		if (request.Environment != null && request.InheritDefaultEnvironment)
		{
			process.InheritDefaultEnv = true;
		}
		return process;
	}

	internal static List<string>? Environment(Dictionary<string, string>? environment)
	{
		return environment?.Select((KeyValuePair<string, string> pair) =>
		{
			if (string.IsNullOrEmpty(pair.Key) || pair.Key.Contains('=', StringComparison.Ordinal))
			{
				throw new ArgumentException("Environment keys must be nonempty and must not contain '='.", "request");
			}
			return pair.Key + "=" + pair.Value;
		}).ToList();
	}

	private static Filesystem Filesystem(FilesystemPolicy? policy)
	{
		return new Filesystem
		{
			ReadwritePaths = ((policy?.ReadwritePaths == null) ? new List<string>() : new List<string>(policy.ReadwritePaths)),
			ReadonlyPaths = ((policy?.ReadonlyPaths == null) ? new List<string>() : new List<string>(policy.ReadonlyPaths)),
			DeniedPaths = ((policy?.DeniedPaths == null) ? new List<string>() : new List<string>(policy.DeniedPaths))
		};
	}

	private static Network? Network(NetworkPolicy? policy)
	{
		if (policy?.Egress == null && policy?.Ingress == null)
		{
			return null;
		}
		return new Network
		{
			Egress = NetworkEgress(policy.Egress),
			Ingress = NetworkIngress(policy.Ingress)
		};
	}

	private static NetworkEgress? NetworkEgress(NetworkEgressPolicy? policy)
	{
		if (policy == null)
		{
			return null;
		}
		NetworkEgress networkEgress = new NetworkEgress();
		NetworkAction? networkAction = policy.Default;
		object obj;
		if (networkAction.HasValue)
		{
			NetworkAction valueOrDefault = networkAction.GetValueOrDefault();
			obj = NetworkAction(valueOrDefault, "network.egress.default");
		}
		else
		{
			obj = null;
		}
		networkEgress.Default = (string?)obj;
		networkEgress.Allow = NetworkRules(policy.Allow);
		networkEgress.Deny = NetworkRules(policy.Deny);
		return networkEgress;
	}

	private static NetworkIngress? NetworkIngress(NetworkIngressPolicy? policy)
	{
		if (policy == null)
		{
			return null;
		}
		NetworkIngress networkIngress = new NetworkIngress();
		NetworkAction? networkAction = policy.Default;
		object obj;
		if (networkAction.HasValue)
		{
			NetworkAction valueOrDefault = networkAction.GetValueOrDefault();
			obj = NetworkAction(valueOrDefault, "network.ingress.default");
		}
		else
		{
			obj = null;
		}
		networkIngress.Default = (string?)obj;
		networkAction = policy.HostLoopback;
		object hostLoopback;
		if (networkAction.HasValue)
		{
			NetworkAction valueOrDefault2 = networkAction.GetValueOrDefault();
			hostLoopback = NetworkAction(valueOrDefault2, "network.ingress.hostLoopback");
		}
		else
		{
			hostLoopback = null;
		}
		networkIngress.HostLoopback = (string?)hostLoopback;
		return networkIngress;
	}

	private static List<NetworkRule>? NetworkRules(List<NetworkRulePolicy>? rules)
	{
		return rules?.Select(NetworkRule).ToList();
	}

	private static NetworkRule NetworkRule(NetworkRulePolicy rule)
	{
		return new NetworkRule
		{
			To = rule.To?.Select((NetworkPeerPolicy peer) => new NetworkPeer
			{
				Cidr = peer.Cidr,
				Except = ((peer.Except == null) ? null : new List<string>(peer.Except))
			}).ToList(),
			Ports = rule.Ports?.Select(NetworkPort).ToList()
		};
	}

	private static NetworkPort NetworkPort(NetworkPortPolicy port)
	{
		NetworkPort networkPort = new NetworkPort();
		NetworkProtocol? protocol = port.Protocol;
		object protocol2;
		if (protocol.HasValue)
		{
			NetworkProtocol valueOrDefault = protocol.GetValueOrDefault();
			protocol2 = NetworkProtocol(valueOrDefault, "network.egress.*.ports.protocol");
		}
		else
		{
			protocol2 = null;
		}
		networkPort.Protocol = (string?)protocol2;
		networkPort.Port = port.Port;
		networkPort.EndPort = port.EndPort;
		return networkPort;
	}

	private static RuntimeConfig? RuntimeConfig(NetworkRuntimeConfig? runtime)
	{
		if (runtime != null)
		{
			return new RuntimeConfig
			{
				NetworkProxy = runtime.NetworkProxy
			};
		}
		return null;
	}

	private static Ui? Ui(UiPolicy? policy)
	{
		if (policy == null)
		{
			return null;
		}
		return new Ui
		{
			Disable = policy.Disable,
			Clipboard = Clipboard(policy.Clipboard, "ui.clipboard"),
			Injection = policy.AllowInputInjection
		};
	}

	private static ProcessContainer ProcessContainer(Containment.ProcessContainer containment)
	{
		ProcessContainer processContainer = new ProcessContainer
		{
			LeastPrivilege = false,
			Capabilities = ValidatedCapabilities(containment.Capabilities),
			CaptureDenials = CaptureDenials(containment.CaptureDenials),
			Filesystem = ((containment.Filesystem == null) ? null : new ProcessContainerFilesystem
			{
				EnumeratePaths = new List<string>(containment.Filesystem.EnumeratePaths)
			}),
			Network = ((containment.Network?.AllowedProxyPeer == null) ? null : new ProcessContainerNetwork
			{
				AllowedProxyPeer = containment.Network.AllowedProxyPeer
			}),
			Ui = ProcessContainerUi(containment.Ui)
		};
		if (containment.LearningMode)
		{
			processContainer.LearningMode = true;
		}
		return processContainer;
	}

	private static List<string> ValidatedCapabilities(IEnumerable<string> capabilities)
	{
		List<string> list = new List<string>();
		foreach (string capability in capabilities)
		{
			if (capability.Contains(',', StringComparison.Ordinal))
			{
				throw new ArgumentException("ProcessContainer capability must not contain a comma.", "request");
			}
			list.Add(capability);
		}
		return list;
	}

	private static CaptureDenials? CaptureDenials(CaptureDenialsPolicy? policy)
	{
		if (policy != null)
		{
			return new CaptureDenials
			{
				Mode = CaptureDenialsMode(policy.Mode, "captureDenials.mode"),
				OutputPath = policy.OutputPath,
				RetainEtl = (policy.RetainEtl ? new bool?(true) : ((bool?)null))
			};
		}
		return null;
	}

	private static ProcessContainerUi? ProcessContainerUi(ProcessContainerUiPolicy? policy)
	{
		if (policy == null || IsDefaultProcessContainerUi(policy))
		{
			return null;
		}
		return new ProcessContainerUi
		{
			Isolation = ProcessContainerUiIsolation(policy.Isolation, "processContainer.ui.isolation"),
			DesktopSystemControl = (policy.DesktopSystemControl ? new bool?(true) : ((bool?)null)),
			SystemSettings = ProcessContainerSystemSettings(policy.SystemSettings, "processContainer.ui.systemSettings"),
			Ime = (policy.Ime ? new bool?(true) : ((bool?)null))
		};
	}

	private static bool IsDefaultProcessContainerUi(ProcessContainerUiPolicy policy)
	{
		if (policy.Isolation == Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation.Container && !policy.DesktopSystemControl && policy.SystemSettings == Microsoft.Mxc.Sdk.V1.ProcessContainerSystemSettings.None)
		{
			return !policy.Ime;
		}
		return false;
	}

	private static Seatbelt Seatbelt(Containment.Seatbelt containment)
	{
		return new Seatbelt
		{
			ProfileOverride = containment.ProfileOverride,
			GuiAccess = (containment.GuiAccess ? new bool?(true) : ((bool?)null)),
			NestedPty = (containment.NestedPty ? ((bool?)null) : new bool?(false)),
			KeychainAccess = (containment.KeychainAccess ? new bool?(true) : ((bool?)null)),
			ExtraMachLookups = ((containment.ExtraMachLookups.Count == 0) ? null : new List<string>(containment.ExtraMachLookups))
		};
	}

	private static OneShotWslc Wslc(Containment.Wslc containment)
	{
		return new OneShotWslc
		{
			Image = containment.Image,
			ImageTarPath = containment.ImageTarPath,
			CpuCount = containment.CpuCount,
			MemoryMb = containment.MemoryMb,
			Gpu = containment.Gpu,
			StoragePath = containment.StoragePath,
			PortMappings = ((containment.PortMappings.Count == 0) ? null : containment.PortMappings.Select((WslcPortMapping mapping) => new PortMapping
			{
				WindowsPort = mapping.WindowsPort,
				ContainerPort = mapping.ContainerPort,
				Protocol = "tcp"
			}).ToList())
		};
	}

	private static string Containment(Containment containment)
	{
		if (!(containment is Containment.Process))
		{
			if (!(containment is Containment.ProcessContainer))
			{
				if (!(containment is Containment.Lxc))
				{
					if (!(containment is Containment.Bubblewrap))
					{
						if (!(containment is Containment.Seatbelt))
						{
							if (!(containment is Containment.IsolationSession))
							{
								if (containment is Containment.Wslc)
								{
									return "wslc";
								}
								throw new ArgumentException("unsupported containment type '" + containment.GetType().Name + "'", "request");
							}
							return "isolation_session";
						}
						return "seatbelt";
					}
					return "bubblewrap";
				}
				return "lxc";
			}
			return "processcontainer";
		}
		return "process";
	}

	private static string NetworkAction(NetworkAction value, string path)
	{
		return RequireDefined(value, path) switch
		{
			Microsoft.Mxc.Sdk.V1.NetworkAction.Allow => "allow", 
			Microsoft.Mxc.Sdk.V1.NetworkAction.Deny => "deny", 
			_ => throw UnreachableEnum(value, path), 
		};
	}

	private static string NetworkProtocol(NetworkProtocol value, string path)
	{
		return RequireDefined(value, path) switch
		{
			Microsoft.Mxc.Sdk.V1.NetworkProtocol.Tcp => "tcp", 
			Microsoft.Mxc.Sdk.V1.NetworkProtocol.Udp => "udp", 
			Microsoft.Mxc.Sdk.V1.NetworkProtocol.Icmp => "icmp", 
			Microsoft.Mxc.Sdk.V1.NetworkProtocol.Any => "any", 
			_ => throw UnreachableEnum(value, path), 
		};
	}

	private static string Clipboard(ClipboardPolicy value, string path)
	{
		return RequireDefined(value, path) switch
		{
			ClipboardPolicy.None => "none", 
			ClipboardPolicy.Read => "read", 
			ClipboardPolicy.Write => "write", 
			ClipboardPolicy.All => "all", 
			_ => throw UnreachableEnum(value, path), 
		};
	}

	private static string CaptureDenialsMode(CaptureDenialsMode value, string path)
	{
		return RequireDefined(value, path) switch
		{
			Microsoft.Mxc.Sdk.V1.CaptureDenialsMode.Block => "block", 
			Microsoft.Mxc.Sdk.V1.CaptureDenialsMode.Allow => "allow", 
			_ => throw UnreachableEnum(value, path), 
		};
	}

	private static string ProcessContainerUiIsolation(ProcessContainerUiIsolation value, string path)
	{
		return RequireDefined(value, path) switch
		{
			Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation.Container => "container", 
			Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation.Desktop => "desktop", 
			Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation.Handles => "handles", 
			Microsoft.Mxc.Sdk.V1.ProcessContainerUiIsolation.Atoms => "atoms", 
			_ => throw UnreachableEnum(value, path), 
		};
	}

	private static string ProcessContainerSystemSettings(ProcessContainerSystemSettings value, string path)
	{
		return RequireDefined(value, path) switch
		{
			Microsoft.Mxc.Sdk.V1.ProcessContainerSystemSettings.All => "all", 
			Microsoft.Mxc.Sdk.V1.ProcessContainerSystemSettings.Parameters => "parameters", 
			Microsoft.Mxc.Sdk.V1.ProcessContainerSystemSettings.Display => "display", 
			Microsoft.Mxc.Sdk.V1.ProcessContainerSystemSettings.None => "none", 
			_ => throw UnreachableEnum(value, path), 
		};
	}

	private static TEnum RequireDefined<TEnum>(TEnum value, string path) where TEnum : struct, Enum
	{
		if (!Enum.IsDefined(value))
		{
			throw new ArgumentOutOfRangeException(path, value, $"{typeof(TEnum).Name} value '{Convert.ToInt64(value)}' is not supported.");
		}
		return value;
	}

	private static ArgumentOutOfRangeException UnreachableEnum<TEnum>(TEnum value, string path) where TEnum : struct, Enum
	{
		return new ArgumentOutOfRangeException(path, value, $"{typeof(TEnum).Name} value '{Convert.ToInt64(value)}' is not supported.");
	}
}
