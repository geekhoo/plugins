using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class ProcessContainerNetworkPolicy
{
	[JsonPropertyName("allowedProxyPeer")]
	public string? AllowedProxyPeer { get; set; }
}
