using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

[JsonUnmappedMemberHandling(JsonUnmappedMemberHandling.Disallow)]
public sealed class WslcProvisionRequest : ProvisionRequest
{
	internal override LifecycleContainmentKind Containment => LifecycleContainmentKind.Wslc;

	public FilesystemPolicy? Filesystem { get; set; }

	public NetworkPolicy? Network { get; set; }

	public string? Image { get; set; }

	public string? ImageTarPath { get; set; }
}
