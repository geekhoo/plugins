namespace Microsoft.Mxc.Sdk.V1;

public sealed record TelemetryConsentOutcome(TelemetryConsentActionResult Result, TelemetryConsentState StoredState, TelemetryConsentState EffectiveState, TelemetryPolicyState Policy);
