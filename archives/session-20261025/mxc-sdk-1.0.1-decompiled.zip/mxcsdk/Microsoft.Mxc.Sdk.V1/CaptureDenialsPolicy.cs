using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class CaptureDenialsPolicy
{
	[JsonPropertyName("mode")]
	public CaptureDenialsMode Mode { get; set; }

	[JsonPropertyName("outputPath")]
	public string? OutputPath { get; set; }

	[JsonPropertyName("retainEtl")]
	public bool RetainEtl { get; set; }
}
