namespace Microsoft.Mxc.Sdk.V1;

public enum ErrorCode
{
	Success = 0,
	MalformedRequest = 1,
	UnsupportedContainment = 2,
	UnsupportedPhase = 3,
	BackendUnavailable = 4,
	MalformedId = 5,
	StaleId = 6,
	NotProvisioned = 7,
	NotStarted = 8,
	AlreadyStarted = 9,
	AlreadyStopped = 10,
	PolicyValidation = 11,
	BackendError = 12,
	NullArgument = 100,
	InvalidUtf8 = 101,
	Panic = 102,
	ConsentWriteFailed = 103
}
