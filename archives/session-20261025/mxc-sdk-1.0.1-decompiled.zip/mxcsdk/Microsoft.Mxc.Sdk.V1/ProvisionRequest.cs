using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

[JsonPolymorphic(TypeDiscriminatorPropertyName = "containment")]
[JsonDerivedType(typeof(IsolationSessionProvisionRequest), "isolation_session")]
[JsonDerivedType(typeof(WslcProvisionRequest), "wslc")]
public abstract class ProvisionRequest
{
	internal abstract LifecycleContainmentKind Containment { get; }

	internal string? Version { get; set; }

	public TelemetryConfig? Telemetry { get; set; }

	private protected ProvisionRequest()
	{
	}
}
