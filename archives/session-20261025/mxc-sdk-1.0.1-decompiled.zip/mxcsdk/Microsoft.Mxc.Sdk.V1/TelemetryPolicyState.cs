namespace Microsoft.Mxc.Sdk.V1;

public enum TelemetryPolicyState
{
	Blocked,
	Unrestricted,
	Allowed,
	NotApplicable
}
