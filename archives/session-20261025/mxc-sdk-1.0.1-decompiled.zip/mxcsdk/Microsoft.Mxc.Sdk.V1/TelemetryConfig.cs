using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class TelemetryConfig
{
	[JsonPropertyName("enabled")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public bool? Enabled { get; set; }
}
