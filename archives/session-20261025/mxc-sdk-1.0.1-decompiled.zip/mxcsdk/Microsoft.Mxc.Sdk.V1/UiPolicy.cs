using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class UiPolicy
{
	[JsonPropertyName("disable")]
	public bool Disable { get; set; } = true;

	[JsonPropertyName("clipboard")]
	public ClipboardPolicy Clipboard { get; set; }

	[JsonPropertyName("allowInputInjection")]
	public bool AllowInputInjection { get; set; }
}
