namespace Microsoft.Mxc.Sdk.V1;

public sealed class RunInContainerOptions
{
	public TelemetryConfig? Telemetry { get; set; }
}
