using System;

namespace Microsoft.Mxc.Sdk.V1;

public interface IMxcStreamCloser : IDisposable
{
	void Close();
}
