namespace Microsoft.Mxc.Sdk.V1;

public sealed class UiCapabilitySupport
{
	public bool CanBlockClipboardRead { get; init; }

	public bool CanBlockClipboardWrite { get; init; }

	public bool CanBlockInputInjection { get; init; }

	public bool CanBlockInputMethodChanges { get; init; }

	public bool CanBlockExternalUiObjects { get; init; }

	public bool CanBlockGlobalUiNamespace { get; init; }

	public bool CanBlockDesktopSwitching { get; init; }

	public bool CanBlockLogoffOrShutdown { get; init; }

	public bool CanBlockSystemParameterChanges { get; init; }

	public bool CanBlockDisplaySettingsChanges { get; init; }
}
