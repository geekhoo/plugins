using System;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class MxcException : Exception
{
	public ErrorCode Code { get; }

	public string? Operation { get; }

	public string? NativeCode { get; }

	public string? Remediation { get; }

	public MxcException(ErrorCode code, string message)
		: this(code, message, null, null, null)
	{
	}

	internal MxcException(ErrorCode code, string message, string? operation, string? nativeCode, string? remediation)
		: base(message)
	{
		Code = code;
		Operation = operation;
		NativeCode = nativeCode;
		Remediation = remediation;
	}

	internal MxcException(ErrorCode code, string message, Exception innerException)
		: base(message, innerException)
	{
		Code = code;
	}

	public override string ToString()
	{
		string text;
		if (Operation == null)
		{
			text = $"{Code}: {Message}";
		}
		else
		{
			text = ((NativeCode == null) ? $"{Code}: {Message} [{Operation}]" : $"{Code}: {Message} [{Operation} {NativeCode}]");
		}
		if (InnerException != null)
		{
			return $"{text} ---> {InnerException}";
		}
		return text;
	}
}
