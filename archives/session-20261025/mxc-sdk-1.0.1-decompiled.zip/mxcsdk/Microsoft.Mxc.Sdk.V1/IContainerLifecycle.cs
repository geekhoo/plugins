using System;
using System.Threading;
using System.Threading.Tasks;

namespace Microsoft.Mxc.Sdk.V1;

internal interface IContainerLifecycle
{
	ProvisionResult ProvisionContainer(ProvisionRequest request, ProvisionOptions? options = null);

	ValidationResult ValidateProvision(ProvisionRequest request, ProvisionOptions? options = null);

	LifecycleResult StartContainer(ContainerId id, StartOptions? options = null);

	ValidationResult ValidateStart(ContainerId id, StartOptions? options = null);

	IMxcProcess SpawnInContainer(ContainerId id, ExecutionRequest request, SpawnInContainerOptions? options = null);

	MxcPtyProcess SpawnInContainerWithPty(ContainerId id, ExecutionRequest request, SpawnInContainerWithPtyOptions? options = null)
	{
		throw new NotSupportedException("This lifecycle implementation does not support PTY processes.");
	}

	ValidationResult ValidateProcess(ContainerId id, ExecutionRequest request, SpawnInContainerOptions? options = null);

	ExecutionResult RunInContainer(ContainerId id, ExecutionRequest request, RunInContainerOptions? options = null);

	Task<ExecutionResult> RunInContainerAsync(ContainerId id, ExecutionRequest request, RunInContainerOptions? options = null, CancellationToken cancellationToken = default(CancellationToken));

	Task<IMxcProcess> SpawnInContainerAsync(ContainerId id, ExecutionRequest request, SpawnInContainerOptions? options = null, CancellationToken cancellationToken = default(CancellationToken));

	LifecycleResult StopContainer(ContainerId id, StopOptions? options = null);

	ValidationResult ValidateStop(ContainerId id, StopOptions? options = null);

	LifecycleResult DeprovisionContainer(ContainerId id, DeprovisionOptions? options = null);

	ValidationResult ValidateDeprovision(ContainerId id, DeprovisionOptions? options = null);
}
