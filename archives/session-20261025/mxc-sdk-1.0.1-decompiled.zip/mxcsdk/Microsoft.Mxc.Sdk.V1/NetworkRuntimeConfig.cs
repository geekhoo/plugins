using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class NetworkRuntimeConfig
{
	[JsonPropertyName("networkProxy")]
	public string? NetworkProxy { get; set; }
}
