namespace Microsoft.Mxc.Sdk.V1;

public enum ProcessContainerSystemSettings
{
	All,
	Parameters,
	Display,
	None
}
