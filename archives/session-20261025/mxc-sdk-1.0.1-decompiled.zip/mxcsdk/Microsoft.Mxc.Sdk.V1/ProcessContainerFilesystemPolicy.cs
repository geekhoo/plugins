using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class ProcessContainerFilesystemPolicy
{
	[JsonPropertyName("enumeratePaths")]
	public List<string> EnumeratePaths { get; set; } = new List<string>();
}
