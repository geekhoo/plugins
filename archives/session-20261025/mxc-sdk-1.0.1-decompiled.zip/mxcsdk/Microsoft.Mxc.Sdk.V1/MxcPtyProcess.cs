using System.IO;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class MxcPtyProcess : MxcProcess
{
	public Stream Input => StandardInput ?? throw MissingStream("input");

	public Stream Output => StandardOutput ?? throw MissingStream("output");

	internal MxcPtyProcess(MxcSandboxHandle handle, uint? timeoutMs)
		: base(handle, timeoutMs)
	{
	}

	public void Resize(MxcPtySize size)
	{
		size.Validate("size");
		ResizePty(size);
	}

	private static MxcException MissingStream(string name)
	{
		return new MxcException(ErrorCode.BackendError, "the selected backend did not expose PTY " + name);
	}
}
