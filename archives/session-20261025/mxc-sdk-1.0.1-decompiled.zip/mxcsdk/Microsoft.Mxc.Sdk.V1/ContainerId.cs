using System;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public readonly struct ContainerId : IEquatable<ContainerId>
{
	public string Value { get; }

	[JsonConstructor]
	public ContainerId(string value)
	{
		if (string.IsNullOrEmpty(value))
		{
			throw new ArgumentException("container id must be a non-empty string", "value");
		}
		Value = value;
	}

	public bool Equals(ContainerId other)
	{
		return string.Equals(Value, other.Value, StringComparison.Ordinal);
	}

	public override bool Equals(object? obj)
	{
		if (obj is ContainerId other)
		{
			return Equals(other);
		}
		return false;
	}

	public override int GetHashCode()
	{
		if (Value != null)
		{
			return Value.GetHashCode(StringComparison.Ordinal);
		}
		return 0;
	}

	public override string ToString()
	{
		return Value ?? string.Empty;
	}

	public static bool operator ==(ContainerId left, ContainerId right)
	{
		return left.Equals(right);
	}

	public static bool operator !=(ContainerId left, ContainerId right)
	{
		return !left.Equals(right);
	}
}
