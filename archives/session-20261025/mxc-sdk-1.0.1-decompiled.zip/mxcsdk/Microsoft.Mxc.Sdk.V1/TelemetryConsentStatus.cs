namespace Microsoft.Mxc.Sdk.V1;

public sealed record TelemetryConsentStatus(TelemetryConsentState StoredState, TelemetryConsentState EffectiveState, TelemetryPolicyState Policy);
