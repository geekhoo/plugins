namespace Microsoft.Mxc.Sdk.V1;

public enum TelemetryConsentState
{
	Undetermined,
	Granted,
	Denied,
	NotApplicable
}
