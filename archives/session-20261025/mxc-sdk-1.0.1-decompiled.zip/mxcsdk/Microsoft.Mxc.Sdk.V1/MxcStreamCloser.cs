using System;
using Microsoft.Mxc.Sdk.Native;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class MxcStreamCloser : IMxcStreamCloser, IDisposable
{
	private readonly MxcStreamCloserHandle _handle;

	internal MxcStreamCloser(MxcStreamCloserHandle handle)
	{
		_handle = handle;
	}

	public unsafe void Close()
	{
		bool success = false;
		try
		{
			_handle.DangerousAddRef(ref success);
			int num = NativeMethods.mxc_stream_closer_close(_handle.Ptr);
			if (num != 0)
			{
				throw new MxcException((ErrorCode)num, "closing the sandbox output stream failed");
			}
		}
		finally
		{
			if (success)
			{
				_handle.DangerousRelease();
			}
		}
	}

	public void Dispose()
	{
		_handle.Dispose();
	}
}
