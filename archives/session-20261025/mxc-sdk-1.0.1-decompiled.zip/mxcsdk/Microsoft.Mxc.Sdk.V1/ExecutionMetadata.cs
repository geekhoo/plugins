using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class ExecutionMetadata
{
	[JsonPropertyName("captureDenials")]
	public CaptureDenialsResult? CaptureDenials { get; init; }

	[JsonPropertyName("captureDenialsError")]
	public CaptureDenialsError? CaptureDenialsError { get; init; }
}
