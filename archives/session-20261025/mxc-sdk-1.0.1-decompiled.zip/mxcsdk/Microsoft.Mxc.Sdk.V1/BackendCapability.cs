namespace Microsoft.Mxc.Sdk.V1;

public enum BackendCapability
{
	Unknown,
	CaptureDenials,
	ProxyEnforcement,
	FilesystemDeniedPaths,
	IngressHostLoopbackAllow,
	FilesystemEnumeratePaths,
	IdentitylessLoopbackProxy
}
