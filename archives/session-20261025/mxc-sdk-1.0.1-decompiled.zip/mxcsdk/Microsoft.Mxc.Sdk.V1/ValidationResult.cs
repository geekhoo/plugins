using System;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class ValidationResult
{
	public string[] Warnings { get; set; } = Array.Empty<string>();
}
