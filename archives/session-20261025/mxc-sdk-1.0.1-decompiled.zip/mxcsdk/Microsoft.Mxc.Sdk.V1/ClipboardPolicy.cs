namespace Microsoft.Mxc.Sdk.V1;

public enum ClipboardPolicy
{
	None,
	Read,
	Write,
	All
}
