using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

internal sealed class NativeProbeFacts
{
	[JsonRequired]
	[JsonPropertyName("baseContainerApiPresent")]
	public bool BaseContainerApiPresent { get; init; }

	[JsonRequired]
	[JsonPropertyName("nativeCaptureAvailable")]
	public bool NativeCaptureAvailable { get; init; }

	[JsonRequired]
	[JsonPropertyName("guardedCaptureAvailable")]
	public bool GuardedCaptureAvailable { get; init; }

	[JsonRequired]
	[JsonPropertyName("bfscfgPresent")]
	public bool BfscfgPresent { get; init; }

	[JsonRequired]
	[JsonPropertyName("bfsCompiledIn")]
	public bool BfsCompiledIn { get; init; }

	[JsonRequired]
	[JsonPropertyName("baseContainerSupportsDenyPaths")]
	public bool BaseContainerSupportsDenyPaths { get; init; }

	[JsonRequired]
	[JsonPropertyName("baseContainerSupportsEnumeratePaths")]
	public bool BaseContainerSupportsEnumeratePaths { get; init; }

	[JsonRequired]
	[JsonPropertyName("baseContainerSupportsIngressHostLoopbackAllow")]
	public bool BaseContainerSupportsIngressHostLoopbackAllow { get; init; }

	[JsonRequired]
	[JsonPropertyName("baseContainerSupportsIdentitylessLoopbackProxy")]
	public bool BaseContainerSupportsIdentitylessLoopbackProxy { get; init; }

	[JsonRequired]
	[JsonPropertyName("isolationSessionAvailable")]
	public bool IsolationSessionAvailable { get; init; }

	[JsonRequired]
	[JsonPropertyName("hyperlightAvailable")]
	public bool HyperlightAvailable { get; init; }

	[JsonRequired]
	[JsonPropertyName("uiCapabilities")]
	public NativeUiCapabilitySupport? UiCapabilities { get; init; }
}
