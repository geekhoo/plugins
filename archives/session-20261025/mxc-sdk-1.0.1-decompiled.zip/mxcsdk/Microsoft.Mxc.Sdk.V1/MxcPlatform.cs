using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.Json;
using Microsoft.Mxc.Sdk.Native;

namespace Microsoft.Mxc.Sdk.V1;

public static class MxcPlatform
{
	public unsafe static string NativeVersion
	{
		get
		{
			byte* ptr = NativeMethods.mxc_version();
			string text;
			if (ptr != null)
			{
				text = Marshal.PtrToStringUTF8((nint)ptr);
				if (text == null)
				{
					return string.Empty;
				}
			}
			else
			{
				text = string.Empty;
			}
			return text;
		}
	}

	static MxcPlatform()
	{
		NativeLibraryResolver.Initialize();
	}

	public unsafe static IReadOnlyList<AvailableBackend> GetAvailableBackends()
	{
		return ParseAvailableBackends(ReadOwnedJson(NativeMethods.mxc_available_backends_json(), "probing available backends"));
	}

	internal static IReadOnlyList<AvailableBackend> ParseAvailableBackends(string json)
	{
		return (MxcJson.Deserialize<NativeAvailableBackend[]>(json) ?? throw new JsonException("Native backend discovery returned null JSON.")).Select(MapAvailableBackend).ToArray();
	}

	public unsafe static PlatformSupport GetPlatformSupport()
	{
		NativePlatformSupport nativePlatformSupport = MxcJson.Deserialize<NativePlatformSupport>(ReadOwnedJson(NativeMethods.mxc_platform_support_json(), "probing platform support")) ?? throw new JsonException("Native platform support returned null JSON.");
		return new PlatformSupport
		{
			IsSupported = nativePlatformSupport.IsSupported,
			Reason = nativePlatformSupport.Reason,
			AvailableMethods = nativePlatformSupport.AvailableMethods.Select(ParseBackend).ToArray()
		};
	}

	internal static ContainmentBackend ParseBackend(string value)
	{
		return value switch
		{
			"processcontainer" => ContainmentBackend.ProcessContainer, 
			"windows_sandbox" => ContainmentBackend.WindowsSandbox, 
			"lxc" => ContainmentBackend.Lxc, 
			"wslc" => ContainmentBackend.Wslc, 
			"seatbelt" => ContainmentBackend.Seatbelt, 
			"isolation_session" => ContainmentBackend.IsolationSession, 
			"bubblewrap" => ContainmentBackend.Bubblewrap, 
			"hyperlight" => ContainmentBackend.Hyperlight, 
			_ => ContainmentBackend.Unknown, 
		};
	}

	internal static IsolationTier ParseIsolationTier(string value)
	{
		return value switch
		{
			"base-container" => IsolationTier.BaseContainer, 
			"appcontainer-bfs" => IsolationTier.AppContainerBfs, 
			"appcontainer-dacl" => IsolationTier.AppContainerDacl, 
			_ => IsolationTier.Unknown, 
		};
	}

	internal static BackendCapability ParseBackendCapability(string value)
	{
		return value switch
		{
			"captureDenials" => BackendCapability.CaptureDenials, 
			"filesystemDeniedPaths" => BackendCapability.FilesystemDeniedPaths, 
			"filesystemEnumeratePaths" => BackendCapability.FilesystemEnumeratePaths, 
			"ingressHostLoopbackAllow" => BackendCapability.IngressHostLoopbackAllow, 
			"proxyEnforcement" => BackendCapability.ProxyEnforcement, 
			"identitylessLoopbackProxy" => BackendCapability.IdentitylessLoopbackProxy, 
			_ => BackendCapability.Unknown, 
		};
	}

	private static AvailableBackend MapAvailableBackend(NativeAvailableBackend backend)
	{
		return new AvailableBackend
		{
			Backend = ParseBackend(backend.Backend),
			Tier = ((backend.Tier == null) ? ((IsolationTier?)null) : new IsolationTier?(ParseIsolationTier(backend.Tier))),
			Capabilities = backend.Capabilities.Select(ParseBackendCapability).ToArray(),
			Warnings = backend.Warnings.ToArray()
		};
	}

	private unsafe static string ReadOwnedJson(byte* value, string operation)
	{
		if (value == null)
		{
			throw new MxcException(ErrorCode.BackendError, operation + " failed");
		}
		try
		{
			return Marshal.PtrToStringUTF8((nint)value) ?? throw new MxcException(ErrorCode.BackendError, operation + " returned invalid JSON");
		}
		finally
		{
			NativeMethods.mxc_string_free(value);
		}
	}
}
