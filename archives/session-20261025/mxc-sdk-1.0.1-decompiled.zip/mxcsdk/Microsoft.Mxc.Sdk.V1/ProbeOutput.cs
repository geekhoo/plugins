using System;
using System.Collections.Generic;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class ProbeOutput
{
	public IsolationTier? Tier { get; init; }

	public bool? NeedsDaclAugmentation { get; init; }

	public IReadOnlyList<string> Warnings { get; init; } = Array.Empty<string>();

	public required ProbeFacts Probes { get; init; }

	public string? Error { get; init; }
}
