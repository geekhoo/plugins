using System;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

internal sealed class NativeAvailableBackend
{
	[JsonPropertyName("backend")]
	public string Backend { get; set; } = string.Empty;

	[JsonPropertyName("tier")]
	public string? Tier { get; set; }

	[JsonPropertyName("capabilities")]
	public string[] Capabilities { get; set; } = Array.Empty<string>();

	[JsonPropertyName("warnings")]
	public string[] Warnings { get; set; } = Array.Empty<string>();
}
