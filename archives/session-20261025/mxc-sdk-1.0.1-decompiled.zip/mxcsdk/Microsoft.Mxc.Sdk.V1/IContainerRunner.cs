using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Microsoft.Mxc.Sdk.V1;

internal interface IContainerRunner
{
	string NativeVersion { get; }

	IReadOnlyList<AvailableBackend> GetAvailableBackends();

	PlatformSupport GetPlatformSupport();

	ExecutionResult Run(ContainerRequest request, RunOptions? options = null);

	Task<ExecutionResult> RunAsync(ContainerRequest request, RunOptions? options = null, CancellationToken cancellationToken = default(CancellationToken));

	IMxcProcess Spawn(ContainerRequest request, SpawnOptions? options = null);

	Task<IMxcProcess> SpawnAsync(ContainerRequest request, SpawnOptions? options = null, CancellationToken cancellationToken = default(CancellationToken));

	MxcPtyProcess SpawnWithPty(ContainerRequest request, SpawnWithPtyOptions? options = null);
}
