namespace Microsoft.Mxc.Sdk.V1;

public sealed class SpawnInContainerWithPtyOptions
{
	public TelemetryConfig? Telemetry { get; set; }

	public MxcPtySize? Size { get; set; }
}
