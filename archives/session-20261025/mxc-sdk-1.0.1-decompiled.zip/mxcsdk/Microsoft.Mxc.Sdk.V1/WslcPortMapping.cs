using System;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class WslcPortMapping
{
	[JsonPropertyName("windowsPort")]
	public ushort WindowsPort { get; }

	[JsonPropertyName("containerPort")]
	public ushort ContainerPort { get; }

	public WslcPortMapping(int windowsPort, int containerPort)
	{
		WindowsPort = ValidatePort(windowsPort, "windowsPort");
		ContainerPort = ValidatePort(containerPort, "containerPort");
	}

	private static ushort ValidatePort(int port, string parameterName)
	{
		if ((port < 1 || port > 65535) ? true : false)
		{
			throw new ArgumentOutOfRangeException(parameterName, port, $"Port must be between 1 and {ushort.MaxValue}.");
		}
		return (ushort)port;
	}
}
