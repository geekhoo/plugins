#define TRACE
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Mxc.Sdk.Native;

namespace Microsoft.Mxc.Sdk.V1;

public static class MxcTelemetry
{
	internal readonly record struct NativePayloadResult(int Status, string? Payload);

	internal readonly record struct NativeBooleanResult(int Status, bool Value);

	internal interface ITelemetryNativeApi
	{
		NativePayloadResult GetConsent();

		NativeBooleanResult NeedsConsentPrompt();

		NativePayloadResult GetPolicy();

		NativePayloadResult GetConsentStatus();

		NativePayloadResult WithdrawConsent();

		NativePayloadResult RequestConsent(string? locale, Func<string, int> presenter);
	}

	private sealed class PInvokeTelemetryNativeApi : ITelemetryNativeApi
	{
		public unsafe NativePayloadResult GetConsent()
		{
			byte* value = null;
			return Payload(NativeMethods.mxc_telemetry_get_consent(&value), value);
		}

		public unsafe NativeBooleanResult NeedsConsentPrompt()
		{
			int num = 0;
			return new NativeBooleanResult(NativeMethods.mxc_telemetry_needs_consent_prompt(&num), num != 0);
		}

		public unsafe NativePayloadResult GetPolicy()
		{
			byte* value = null;
			return Payload(NativeMethods.mxc_telemetry_get_policy(&value), value);
		}

		public unsafe NativePayloadResult GetConsentStatus()
		{
			byte* value = null;
			return Payload(NativeMethods.mxc_telemetry_get_consent_status(&value), value);
		}

		public unsafe NativePayloadResult WithdrawConsent()
		{
			byte* value = null;
			return Payload(NativeMethods.mxc_telemetry_withdraw_consent(&value), value);
		}

		public unsafe NativePayloadResult RequestConsent(string? locale, Func<string, int> presenter)
		{
			byte[] array = ((locale == null) ? null : ToNullTerminatedUtf8(locale));
			using PresenterCallback presenterCallback = new PresenterCallback(presenter);
			fixed (byte* locale_utf = array)
			{
				byte* value = null;
				return Payload(NativeMethods.mxc_telemetry_request_consent(locale_utf, (delegate* unmanaged[Cdecl]<byte*, void*, int>)(&PresentConsent), (void*)GCHandle.ToIntPtr(presenterCallback.Handle), &value), value);
			}
		}

		private unsafe static NativePayloadResult Payload(int status, byte* value)
		{
			try
			{
				return new NativePayloadResult(status, (value == null) ? null : Marshal.PtrToStringUTF8((nint)value));
			}
			finally
			{
				if (value != null)
				{
					NativeMethods.mxc_string_free(value);
				}
			}
		}
	}

	private sealed class PresenterCallback : IDisposable
	{
		private readonly Func<string, int> presenter;

		internal GCHandle Handle { get; }

		internal PresenterCallback(Func<string, int> presenter)
		{
			this.presenter = presenter;
			Handle = GCHandle.Alloc(this);
		}

		internal int Invoke(string prompt)
		{
			try
			{
				return presenter(prompt);
			}
			catch
			{
				return -1;
			}
		}

		public void Dispose()
		{
			Handle.Free();
		}
	}

	private sealed class NativeApiScope(ITelemetryNativeApi replacement) : IDisposable
	{
		private int disposed;

		public void Dispose()
		{
			if (Interlocked.Exchange(ref disposed, 1) == 0)
			{
				Interlocked.CompareExchange(ref nativeApi, DefaultNativeApi, replacement);
			}
		}
	}

	private sealed class FailureCategoryTrackerScope(FailureCategoryTracker replacement) : IDisposable
	{
		private int disposed;

		public void Dispose()
		{
			if (Interlocked.Exchange(ref disposed, 1) == 0)
			{
				Interlocked.CompareExchange(ref reportedFailures, DefaultFailureCategoryTracker, replacement);
			}
		}
	}

	private sealed class Scope(Action release) : IDisposable
	{
		private bool released;

		public void Dispose()
		{
			if (!released)
			{
				released = true;
				release();
			}
		}
	}

	internal sealed class FailureCategoryTracker(int capacity)
	{
		private readonly record struct FailureCategory(string Operation, string SafeResult, string Kind, int Code);

		private readonly HashSet<FailureCategory> categories = new HashSet<FailureCategory>();

		internal bool TryAdd(string operation, string safeResult, string kind, int code)
		{
			FailureCategory item = new FailureCategory(operation, safeResult, kind, code);
			lock (categories)
			{
				if (categories.Contains(item) || categories.Count >= capacity)
				{
					return false;
				}
				categories.Add(item);
				return true;
			}
		}

		internal void Remove(string operation, string safeResult, string kind, int code)
		{
			lock (categories)
			{
				categories.Remove(new FailureCategory(operation, safeResult, kind, code));
			}
		}
	}

	private sealed class PresenterContext
	{
		internal Exception? Error;

		internal required Func<TelemetryConsentPrompt, ValueTask<TelemetryConsentDecision>> Presenter { get; init; }

		internal required CancellationToken CancellationToken { get; init; }

		internal SynchronizationContext? SynchronizationContext { get; init; }
	}

	private enum ConsentOutcomeOperation
	{
		Request,
		Withdraw
	}

	private static readonly ITelemetryNativeApi DefaultNativeApi;

	private static readonly FailureCategoryTracker DefaultFailureCategoryTracker;

	private static ITelemetryNativeApi nativeApi;

	private static FailureCategoryTracker reportedFailures;

	private static bool? windowsHostOverride;

	private static bool IsWindowsHost => windowsHostOverride ?? OperatingSystem.IsWindows();

	internal static IDisposable OverrideNativeApiForTesting(ITelemetryNativeApi replacement)
	{
		ArgumentNullException.ThrowIfNull(replacement, "replacement");
		if (Interlocked.CompareExchange(ref nativeApi, replacement, DefaultNativeApi) != DefaultNativeApi)
		{
			throw new InvalidOperationException("A telemetry native API test override is already active.");
		}
		return new NativeApiScope(replacement);
	}

	internal static IDisposable OverrideFailureCategoryTrackerForTesting(FailureCategoryTracker replacement)
	{
		ArgumentNullException.ThrowIfNull(replacement, "replacement");
		if (Interlocked.CompareExchange(ref reportedFailures, replacement, DefaultFailureCategoryTracker) != DefaultFailureCategoryTracker)
		{
			throw new InvalidOperationException("A failure category tracker test override is already active.");
		}
		return new FailureCategoryTrackerScope(replacement);
	}

	internal static IDisposable OverrideWindowsHostForTesting(bool isWindows)
	{
		bool? previous = windowsHostOverride;
		windowsHostOverride = isWindows;
		return new Scope(() =>
		{
			windowsHostOverride = previous;
		});
	}

	static MxcTelemetry()
	{
		DefaultNativeApi = new PInvokeTelemetryNativeApi();
		DefaultFailureCategoryTracker = new FailureCategoryTracker(64);
		nativeApi = DefaultNativeApi;
		reportedFailures = DefaultFailureCategoryTracker;
		NativeLibraryResolver.Initialize();
	}

	public static TelemetryConsentState GetConsent()
	{
		if (!IsWindowsHost)
		{
			return TelemetryConsentState.NotApplicable;
		}
		try
		{
			NativePayloadResult consent = nativeApi.GetConsent();
			EnsureSuccess(consent.Status, "failed to read telemetry consent state");
			return ParseConsentState(consent.Payload, "GetConsent");
		}
		catch (Exception exception)
		{
			ReportFailClosed("GetConsent", "Undetermined", exception);
			return TelemetryConsentState.Undetermined;
		}
	}

	internal static bool IsNativeLoadFailure(Exception ex)
	{
		if (ex is DllNotFoundException || ex is EntryPointNotFoundException || ex is TypeInitializationException || ex is BadImageFormatException)
		{
			return true;
		}
		return false;
	}

	internal static void ReportFailClosed(string operation, string safeResult, Exception exception)
	{
		string kind = exception.GetType().FullName ?? exception.GetType().Name;
		ReportFailClosedCore(operation, safeResult, kind, exception.HResult, null, null);
	}

	internal static void ReportFailClosed(string operation, string safeResult, ErrorCode errorCode)
	{
		ReportFailClosedCore(operation, safeResult, "ErrorCode", (int)errorCode, errorCode, null);
	}

	private static void ReportFailClosedCategory(string operation, string safeResult, string category)
	{
		ReportFailClosedCore(operation, safeResult, category, 0, null, category);
	}

	private static void ReportFailClosedCore(string operation, string safeResult, string kind, int code, ErrorCode? errorCode, string? safeDescription)
	{
		bool flag = false;
		try
		{
			if (!reportedFailures.TryAdd(operation, safeResult, kind, code))
			{
				return;
			}
			flag = true;
			string text = safeDescription;
			if (text == null)
			{
				if (errorCode.HasValue)
				{
					ErrorCode valueOrDefault = errorCode.GetValueOrDefault();
					text = $"{valueOrDefault} ({code})";
				}
				else
				{
					text = $"{kind} (HRESULT 0x{code:X8})";
				}
			}
			string text2 = text;
			Trace.TraceError("mxc: {0} failed and is reporting '{1}' to stay fail-closed: {2}", operation, safeResult, text2);
		}
		catch
		{
			if (flag)
			{
				reportedFailures.Remove(operation, safeResult, kind, code);
			}
		}
	}

	public static bool NeedsConsentPrompt()
	{
		if (!IsWindowsHost)
		{
			return false;
		}
		try
		{
			NativeBooleanResult nativeBooleanResult = nativeApi.NeedsConsentPrompt();
			if (nativeBooleanResult.Status != 0)
			{
				ReportFailClosed("NeedsConsentPrompt", "false", (ErrorCode)nativeBooleanResult.Status);
				return false;
			}
			return nativeBooleanResult.Value;
		}
		catch (Exception exception)
		{
			ReportFailClosed("NeedsConsentPrompt", "false", exception);
			return false;
		}
	}

	public static TelemetryPolicyState GetPolicy()
	{
		if (!IsWindowsHost)
		{
			return TelemetryPolicyState.NotApplicable;
		}
		try
		{
			NativePayloadResult policy = nativeApi.GetPolicy();
			if (policy.Status != 0)
			{
				ReportFailClosed("GetPolicy", "Blocked", (ErrorCode)policy.Status);
				return TelemetryPolicyState.Blocked;
			}
			return ParsePolicyState(policy.Payload, "GetPolicy");
		}
		catch (Exception exception)
		{
			ReportFailClosed("GetPolicy", "Blocked", exception);
			return TelemetryPolicyState.Blocked;
		}
	}

	public static TelemetryConsentOutcome RequestConsent(Func<TelemetryConsentPrompt, TelemetryConsentDecision> presenter, string? locale = null)
	{
		ArgumentNullException.ThrowIfNull(presenter, "presenter");
		ValidateLocale(locale);
		if (!IsWindowsHost)
		{
			return NotApplicableOutcome();
		}
		return RequestConsentCore((TelemetryConsentPrompt prompt) => ValueTask.FromResult(presenter(prompt)), locale, CancellationToken.None, null);
	}

	public static Task<TelemetryConsentOutcome> RequestConsentAsync(Func<TelemetryConsentPrompt, ValueTask<TelemetryConsentDecision>> presenter, string? locale = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		ArgumentNullException.ThrowIfNull(presenter, "presenter");
		ValidateLocale(locale);
		if (cancellationToken.IsCancellationRequested)
		{
			return Task.FromCanceled<TelemetryConsentOutcome>(cancellationToken);
		}
		if (!IsWindowsHost)
		{
			return Task.FromResult(NotApplicableOutcome());
		}
		SynchronizationContext synchronizationContext = SynchronizationContext.Current;
		return Task.Factory.StartNew(() => FinalizeAsyncOutcome(RequestConsentCore(presenter, locale, cancellationToken, synchronizationContext), cancellationToken), cancellationToken, TaskCreationOptions.LongRunning, TaskScheduler.Default);
	}

	internal static TelemetryConsentOutcome FinalizeAsyncOutcome(TelemetryConsentOutcome outcome, CancellationToken cancellationToken)
	{
		if (outcome.Result == TelemetryConsentActionResult.Dismissed)
		{
			cancellationToken.ThrowIfCancellationRequested();
		}
		return outcome;
	}

	public static TelemetryConsentStatus GetConsentStatus()
	{
		if (!IsWindowsHost)
		{
			return new TelemetryConsentStatus(TelemetryConsentState.NotApplicable, TelemetryConsentState.NotApplicable, TelemetryPolicyState.NotApplicable);
		}
		try
		{
			NativePayloadResult consentStatus = nativeApi.GetConsentStatus();
			EnsureSuccess(consentStatus.Status, "failed to read telemetry consent status");
			return ParseConsentStatus(consentStatus.Payload);
		}
		catch (Exception ex) when ((ex is JsonException || ex is KeyNotFoundException || ex is InvalidOperationException) ? true : false)
		{
			ReportFailClosed("GetConsentStatus", "Undetermined/Blocked", ex);
			return new TelemetryConsentStatus(TelemetryConsentState.Undetermined, TelemetryConsentState.Undetermined, TelemetryPolicyState.Blocked);
		}
		catch (MxcException exception)
		{
			ReportFailClosed("GetConsentStatus", "Undetermined/Blocked", exception);
			return new TelemetryConsentStatus(TelemetryConsentState.Undetermined, TelemetryConsentState.Undetermined, TelemetryPolicyState.Blocked);
		}
		catch (Exception exception2)
		{
			ReportFailClosed("GetConsentStatus", "Undetermined/Blocked", exception2);
			return new TelemetryConsentStatus(TelemetryConsentState.Undetermined, TelemetryConsentState.Undetermined, TelemetryPolicyState.Blocked);
		}
	}

	public static TelemetryConsentOutcome WithdrawConsent()
	{
		if (!IsWindowsHost)
		{
			return NotApplicableOutcome();
		}
		try
		{
			NativePayloadResult nativePayloadResult = nativeApi.WithdrawConsent();
			EnsureSuccess(nativePayloadResult.Status, "failed to withdraw telemetry consent");
			return ParseConsentOutcome(nativePayloadResult.Payload, ConsentOutcomeOperation.Withdraw);
		}
		catch (Exception ex) when (!(ex is MxcException))
		{
			throw new MxcException(ErrorCode.BackendError, "failed to withdraw telemetry consent", ex);
		}
	}

	private static TelemetryConsentOutcome RequestConsentCore(Func<TelemetryConsentPrompt, ValueTask<TelemetryConsentDecision>> presenter, string? locale, CancellationToken cancellationToken, SynchronizationContext? synchronizationContext)
	{
		try
		{
			cancellationToken.ThrowIfCancellationRequested();
			PresenterContext context = new PresenterContext
			{
				Presenter = presenter,
				CancellationToken = cancellationToken,
				SynchronizationContext = synchronizationContext
			};
			NativePayloadResult nativePayloadResult = nativeApi.RequestConsent(locale, (string promptJson) =>
			{
				try
				{
					TelemetryConsentPrompt prompt = ParseConsentPrompt(promptJson);
					return InvokePresenterWithCancellation(context.Presenter, prompt, context.SynchronizationContext, context.CancellationToken) switch
					{
						TelemetryConsentDecision.No => 0, 
						TelemetryConsentDecision.Yes => 1, 
						TelemetryConsentDecision.Dismissed => 2, 
						_ => -1, 
					};
				}
				catch (Exception value)
				{
					Interlocked.CompareExchange(ref context.Error, value, null);
					return -1;
				}
			});
			if (context.Error is OperationCanceledException && cancellationToken.IsCancellationRequested)
			{
				cancellationToken.ThrowIfCancellationRequested();
			}
			if (context.Error != null)
			{
				throw new MxcException(ErrorCode.BackendError, "telemetry consent presenter failed", context.Error);
			}
			EnsureSuccess(nativePayloadResult.Status, "failed to request telemetry consent");
			return ParseConsentOutcome(nativePayloadResult.Payload, ConsentOutcomeOperation.Request);
		}
		catch (Exception ex) when (!(ex is MxcException) && !(ex is OperationCanceledException))
		{
			throw new MxcException(ErrorCode.BackendError, "telemetry consent request failed", ex);
		}
	}

	private static TelemetryConsentDecision InvokePresenterWithCancellation(Func<TelemetryConsentPrompt, ValueTask<TelemetryConsentDecision>> presenter, TelemetryConsentPrompt prompt, SynchronizationContext? synchronizationContext, CancellationToken cancellationToken)
	{
		Task<TelemetryConsentDecision> task = null;
		try
		{
			task = InvokePresenterAsync(presenter, prompt, synchronizationContext, cancellationToken);
			return task.WaitAsync(cancellationToken).GetAwaiter().GetResult();
		}
		catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
		{
			if (task != null)
			{
				ObserveAbandonedPresenterFailure(task);
			}
			return TelemetryConsentDecision.Dismissed;
		}
	}

	private static void ObserveAbandonedPresenterFailure(Task<TelemetryConsentDecision> presenterTask)
	{
		presenterTask.ContinueWith((Task<TelemetryConsentDecision> faulted) =>
		{
			AggregateException exception = faulted.Exception;
			if (exception != null)
			{
				ReportFailClosed("RequestConsentAsync presenter after cancellation", "canceled", exception.GetBaseException());
			}
		}, CancellationToken.None, TaskContinuationOptions.OnlyOnFaulted | TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
	}

	private static Task<TelemetryConsentDecision> InvokePresenterAsync(Func<TelemetryConsentPrompt, ValueTask<TelemetryConsentDecision>> presenter, TelemetryConsentPrompt prompt, SynchronizationContext? synchronizationContext, CancellationToken cancellationToken)
	{
		if (synchronizationContext == null)
		{
			cancellationToken.ThrowIfCancellationRequested();
			return presenter(prompt).AsTask();
		}
		TaskCompletionSource<TelemetryConsentDecision> completion = new TaskCompletionSource<TelemetryConsentDecision>(TaskCreationOptions.RunContinuationsAsynchronously);
		try
		{
			synchronizationContext.Post(async (object? _) =>
			{
				if (cancellationToken.IsCancellationRequested)
				{
					completion.TrySetCanceled(cancellationToken);
					return;
				}
				try
				{
					TaskCompletionSource<TelemetryConsentDecision> taskCompletionSource = completion;
					taskCompletionSource.SetResult(await presenter(prompt));
				}
				catch (Exception exception2)
				{
					completion.SetException(exception2);
				}
			}, null);
		}
		catch (Exception exception)
		{
			completion.SetException(exception);
		}
		return completion.Task;
	}

	[UnmanagedCallersOnly(CallConvs = new Type[] { typeof(CallConvCdecl) })]
	private unsafe static int PresentConsent(byte* promptJsonUtf8, void* contextPointer)
	{
		try
		{
			return ((PresenterCallback)GCHandle.FromIntPtr((nint)contextPointer).Target).Invoke(Marshal.PtrToStringUTF8((nint)promptJsonUtf8) ?? string.Empty);
		}
		catch
		{
			return -1;
		}
	}

	private static void EnsureSuccess(int status, string message)
	{
		if (status != 0)
		{
			throw new MxcException((ErrorCode)status, message);
		}
	}

	private static TelemetryConsentOutcome NotApplicableOutcome()
	{
		return new TelemetryConsentOutcome(TelemetryConsentActionResult.NotApplicable, TelemetryConsentState.NotApplicable, TelemetryConsentState.NotApplicable, TelemetryPolicyState.NotApplicable);
	}

	internal static TelemetryConsentPrompt ParseConsentPrompt(string? json)
	{
		using JsonDocument jsonDocument = JsonDocument.Parse(json ?? throw new JsonException("missing consent prompt"));
		JsonElement rootElement = jsonDocument.RootElement;
		return new TelemetryConsentPrompt(rootElement.GetProperty("resourceVersion").GetUInt32(), ParseRequiredString(rootElement, "locale", "locale"), ParseConsentMessage(rootElement.GetProperty("title"), "title"), ParseConsentMessage(rootElement.GetProperty("body"), "body"), ParseConsentMessage(rootElement.GetProperty("affirmativeLabel"), "affirmativeLabel"), ParseConsentMessage(rootElement.GetProperty("negativeLabel"), "negativeLabel"), ParseConsentMessage(rootElement.GetProperty("learnMoreLabel"), "learnMoreLabel"), ParseRequiredString(rootElement, "learnMoreUrl", "learnMoreUrl"));
	}

	private static TelemetryConsentMessage ParseConsentMessage(JsonElement value, string path)
	{
		return new TelemetryConsentMessage(ParseRequiredString(value, "id", path + ".id"), ParseRequiredString(value, "text", path + ".text"));
	}

	private static string ParseRequiredString(JsonElement parent, string propertyName, string path)
	{
		JsonElement property = parent.GetProperty(propertyName);
		if (property.ValueKind != JsonValueKind.String)
		{
			throw new JsonException("Telemetry consent prompt field '" + path + "' must be a string.");
		}
		return property.GetString();
	}

	private static TelemetryConsentStatus ParseConsentStatus(string? json)
	{
		using JsonDocument jsonDocument = JsonDocument.Parse(json ?? throw new JsonException("missing consent status"));
		JsonElement rootElement = jsonDocument.RootElement;
		if (!IsKnownConsentStatusReason(rootElement.GetProperty("reason"), "GetConsentStatus"))
		{
			return FailClosedStatus();
		}
		if (!TryParseConsentFields(rootElement, "GetConsentStatus", out var storedState, out var effectiveState, out var policy))
		{
			return FailClosedStatus();
		}
		return new TelemetryConsentStatus(storedState, effectiveState, policy);
	}

	private static TelemetryConsentOutcome ParseConsentOutcome(string? json, ConsentOutcomeOperation operation)
	{
		using JsonDocument jsonDocument = JsonDocument.Parse(json ?? throw new JsonException("missing consent outcome"));
		JsonElement rootElement = jsonDocument.RootElement;
		TelemetryConsentActionResult result = ParseConsentActionResult(rootElement.GetProperty("result").GetString());
		string operation2 = $"{operation}Consent";
		if (!IsResultForOperation(result, operation) || !IsKnownConsentStatusReason(rootElement.GetProperty("reason"), operation2))
		{
			return FailClosedOutcome();
		}
		if (!TryParseConsentFields(rootElement, operation2, out var storedState, out var effectiveState, out var policy))
		{
			return FailClosedOutcome();
		}
		return new TelemetryConsentOutcome(result, storedState, effectiveState, policy);
	}

	private static bool IsResultForOperation(TelemetryConsentActionResult result, ConsentOutcomeOperation operation)
	{
		bool flag;
		switch (operation)
		{
		case ConsentOutcomeOperation.Request:
		{
			bool flag2 = (((uint)(result - 1) <= 2u || (uint)(result - 5) <= 2u) ? true : false);
			flag = flag2;
			break;
		}
		case ConsentOutcomeOperation.Withdraw:
		{
			bool flag2 = ((result == TelemetryConsentActionResult.Withdrawn || result == TelemetryConsentActionResult.NotApplicable) ? true : false);
			flag = flag2;
			break;
		}
		default:
			flag = false;
			break;
		}
		bool flag3 = flag;
		if (!flag3 && result != TelemetryConsentActionResult.Unknown)
		{
			ReportFailClosedCategory($"{operation}Consent", "Unknown", "native returned an invalid consent result");
		}
		return flag3;
	}

	private static TelemetryConsentStatus FailClosedStatus()
	{
		return new TelemetryConsentStatus(TelemetryConsentState.Undetermined, TelemetryConsentState.Undetermined, TelemetryPolicyState.Blocked);
	}

	private static TelemetryConsentOutcome FailClosedOutcome()
	{
		return new TelemetryConsentOutcome(TelemetryConsentActionResult.Unknown, TelemetryConsentState.Undetermined, TelemetryConsentState.Undetermined, TelemetryPolicyState.Blocked);
	}

	private static bool TryParseConsentFields(JsonElement root, string operation, out TelemetryConsentState storedState, out TelemetryConsentState effectiveState, out TelemetryPolicyState policy)
	{
		storedState = TelemetryConsentState.Undetermined;
		effectiveState = TelemetryConsentState.Undetermined;
		policy = TelemetryPolicyState.Blocked;
		string value = root.GetProperty("storedState").GetString();
		TelemetryConsentState? telemetryConsentState = ParseKnownConsentState(value);
		if (!telemetryConsentState.HasValue)
		{
			UnrecognizedConsentState(value, operation);
			return false;
		}
		string value2 = root.GetProperty("effectiveState").GetString();
		TelemetryConsentState? telemetryConsentState2 = ParseKnownConsentState(value2);
		if (!telemetryConsentState2.HasValue)
		{
			UnrecognizedConsentState(value2, operation);
			return false;
		}
		string value3 = root.GetProperty("policy").GetString();
		TelemetryPolicyState? telemetryPolicyState = ParseKnownPolicyState(value3);
		if (!telemetryPolicyState.HasValue)
		{
			UnrecognizedPolicyState(value3, operation);
			return false;
		}
		storedState = telemetryConsentState.Value;
		effectiveState = telemetryConsentState2.Value;
		policy = telemetryPolicyState.Value;
		return true;
	}

	private static TelemetryConsentActionResult ParseConsentActionResult(string? value)
	{
		return value switch
		{
			"granted" => TelemetryConsentActionResult.Granted, 
			"denied" => TelemetryConsentActionResult.Denied, 
			"dismissed" => TelemetryConsentActionResult.Dismissed, 
			"withdrawn" => TelemetryConsentActionResult.Withdrawn, 
			"alreadyGranted" => TelemetryConsentActionResult.AlreadyGranted, 
			"policyBlocked" => TelemetryConsentActionResult.PolicyBlocked, 
			"notApplicable" => TelemetryConsentActionResult.NotApplicable, 
			_ => UnrecognizedConsentActionResult(value), 
		};
	}

	private static TelemetryConsentActionResult UnrecognizedConsentActionResult(string? value)
	{
		ReportFailClosedCategory("ConsentOutcome", "Unknown", "native returned an unrecognized consent action result");
		return TelemetryConsentActionResult.Unknown;
	}

	private static bool IsKnownConsentStatusReason(JsonElement value, string operation)
	{
		if (value.ValueKind == JsonValueKind.Null)
		{
			return true;
		}
		string text = value.GetString();
		switch (text)
		{
		case "consent-schema-unsupported":
		case "prompt-version-unsupported":
		case "not-applicable":
		case "policy-blocked":
		case "no-record":
		case "store-unreadable":
		case "store-malformed":
		case "prompt-version-missing":
		case "presentation-unavailable":
			return true;
		default:
			return ReportUnrecognizedConsentStatusReason(text, operation);
		}
	}

	private static bool ReportUnrecognizedConsentStatusReason(string? value, string operation)
	{
		ReportFailClosedCategory(operation, "Unknown", "native returned an unrecognized consent status reason");
		return false;
	}

	private static TelemetryConsentState? ParseKnownConsentState(string? value)
	{
		return value switch
		{
			"granted" => (TelemetryConsentState?)TelemetryConsentState.Granted, 
			"denied" => TelemetryConsentState.Denied, 
			"undetermined" => TelemetryConsentState.Undetermined, 
			"not-applicable" => TelemetryConsentState.NotApplicable, 
			_ => null, 
		};
	}

	private static TelemetryConsentState ParseConsentState(string? value, string operation)
	{
		return ParseKnownConsentState(value) ?? UnrecognizedConsentState(value, operation);
	}

	private static TelemetryConsentState UnrecognizedConsentState(string? value, string operation)
	{
		ReportFailClosedCategory(operation, "Undetermined", "native returned an unrecognized consent state");
		return TelemetryConsentState.Undetermined;
	}

	private static TelemetryPolicyState? ParseKnownPolicyState(string? value)
	{
		return value switch
		{
			"unrestricted" => (TelemetryPolicyState?)TelemetryPolicyState.Unrestricted, 
			"allowed" => TelemetryPolicyState.Allowed, 
			"blocked" => TelemetryPolicyState.Blocked, 
			"not-applicable" => TelemetryPolicyState.NotApplicable, 
			_ => null, 
		};
	}

	private static TelemetryPolicyState ParsePolicyState(string? value, string operation)
	{
		return ParseKnownPolicyState(value) ?? UnrecognizedPolicyState(value, operation);
	}

	private static TelemetryPolicyState UnrecognizedPolicyState(string? value, string operation)
	{
		ReportFailClosedCategory(operation, "Blocked", "native returned an unrecognized policy state");
		return TelemetryPolicyState.Blocked;
	}

	private static void ValidateLocale(string? locale)
	{
		if (locale != null && locale.Contains('\0'))
		{
			throw new ArgumentException("Telemetry consent locale cannot contain embedded NUL characters.", "locale");
		}
	}

	private static byte[] ToNullTerminatedUtf8(string value)
	{
		return Encoding.UTF8.GetBytes(value + "\0");
	}
}
