namespace Microsoft.Mxc.Sdk.V1;

public enum CaptureDenialsMode
{
	Block,
	Allow
}
