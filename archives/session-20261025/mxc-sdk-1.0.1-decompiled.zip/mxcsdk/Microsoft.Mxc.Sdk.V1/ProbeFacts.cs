namespace Microsoft.Mxc.Sdk.V1;

public sealed class ProbeFacts
{
	public bool BaseContainerApiPresent { get; init; }

	public bool NativeCaptureAvailable { get; init; }

	public bool GuardedCaptureAvailable { get; init; }

	public bool BfscfgPresent { get; init; }

	public bool BfsCompiledIn { get; init; }

	public bool BaseContainerSupportsDenyPaths { get; init; }

	public bool BaseContainerSupportsEnumeratePaths { get; init; }

	public bool BaseContainerSupportsIngressHostLoopbackAllow { get; init; }

	public bool BaseContainerSupportsIdentitylessLoopbackProxy { get; init; }

	public bool IsolationSessionAvailable { get; init; }

	public bool HyperlightAvailable { get; init; }

	public required UiCapabilitySupport UiCapabilities { get; init; }
}
