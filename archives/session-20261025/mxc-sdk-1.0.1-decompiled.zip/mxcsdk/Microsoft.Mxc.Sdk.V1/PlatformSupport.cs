using System;
using System.Collections.Generic;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class PlatformSupport
{
	public bool IsSupported { get; init; }

	public string? Reason { get; init; }

	public IReadOnlyList<ContainmentBackend> AvailableMethods { get; init; } = Array.Empty<ContainmentBackend>();
}
