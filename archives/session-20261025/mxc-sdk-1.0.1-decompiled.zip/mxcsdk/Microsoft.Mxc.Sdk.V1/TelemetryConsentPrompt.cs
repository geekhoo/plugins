namespace Microsoft.Mxc.Sdk.V1;

public sealed record TelemetryConsentPrompt(uint ResourceVersion, string Locale, TelemetryConsentMessage Title, TelemetryConsentMessage Body, TelemetryConsentMessage AffirmativeLabel, TelemetryConsentMessage NegativeLabel, TelemetryConsentMessage LearnMoreLabel, string LearnMoreUrl);
