using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

internal sealed class NativeUiCapabilitySupport
{
	[JsonRequired]
	[JsonPropertyName("canBlockClipboardRead")]
	public bool CanBlockClipboardRead { get; init; }

	[JsonRequired]
	[JsonPropertyName("canBlockClipboardWrite")]
	public bool CanBlockClipboardWrite { get; init; }

	[JsonRequired]
	[JsonPropertyName("canBlockInputInjection")]
	public bool CanBlockInputInjection { get; init; }

	[JsonRequired]
	[JsonPropertyName("canBlockInputMethodChanges")]
	public bool CanBlockInputMethodChanges { get; init; }

	[JsonRequired]
	[JsonPropertyName("canBlockExternalUiObjects")]
	public bool CanBlockExternalUiObjects { get; init; }

	[JsonRequired]
	[JsonPropertyName("canBlockGlobalUiNamespace")]
	public bool CanBlockGlobalUiNamespace { get; init; }

	[JsonRequired]
	[JsonPropertyName("canBlockDesktopSwitching")]
	public bool CanBlockDesktopSwitching { get; init; }

	[JsonRequired]
	[JsonPropertyName("canBlockLogoffOrShutdown")]
	public bool CanBlockLogoffOrShutdown { get; init; }

	[JsonRequired]
	[JsonPropertyName("canBlockSystemParameterChanges")]
	public bool CanBlockSystemParameterChanges { get; init; }

	[JsonRequired]
	[JsonPropertyName("canBlockDisplaySettingsChanges")]
	public bool CanBlockDisplaySettingsChanges { get; init; }
}
