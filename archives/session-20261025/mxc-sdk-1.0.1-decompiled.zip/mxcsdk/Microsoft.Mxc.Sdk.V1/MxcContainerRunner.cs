using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Microsoft.Mxc.Sdk.V1;

internal sealed class MxcContainerRunner : IContainerRunner
{
	public static MxcContainerRunner Default { get; } = new MxcContainerRunner();

	public string NativeVersion => MxcPlatform.NativeVersion;

	public IReadOnlyList<AvailableBackend> GetAvailableBackends()
	{
		return MxcPlatform.GetAvailableBackends();
	}

	public PlatformSupport GetPlatformSupport()
	{
		return MxcPlatform.GetPlatformSupport();
	}

	public ExecutionResult Run(ContainerRequest request, RunOptions? options = null)
	{
		return MxcContainer.Run(request, options);
	}

	public Task<ExecutionResult> RunAsync(ContainerRequest request, RunOptions? options = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		return MxcContainer.RunAsync(request, options, cancellationToken);
	}

	public IMxcProcess Spawn(ContainerRequest request, SpawnOptions? options = null)
	{
		return MxcContainer.Spawn(request, options);
	}

	public async Task<IMxcProcess> SpawnAsync(ContainerRequest request, SpawnOptions? options = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		return await MxcContainer.SpawnAsync(request, options, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
	}

	public MxcPtyProcess SpawnWithPty(ContainerRequest request, SpawnWithPtyOptions? options = null)
	{
		return MxcContainer.SpawnWithPty(request, options);
	}
}
