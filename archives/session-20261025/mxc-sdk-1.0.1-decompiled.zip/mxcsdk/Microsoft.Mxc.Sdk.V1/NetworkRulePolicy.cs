using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class NetworkRulePolicy
{
	[JsonPropertyName("to")]
	public List<NetworkPeerPolicy>? To { get; set; }

	[JsonPropertyName("ports")]
	public List<NetworkPortPolicy>? Ports { get; set; }
}
