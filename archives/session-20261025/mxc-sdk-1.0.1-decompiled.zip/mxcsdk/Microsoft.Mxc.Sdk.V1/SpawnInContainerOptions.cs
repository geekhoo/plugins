namespace Microsoft.Mxc.Sdk.V1;

public sealed class SpawnInContainerOptions
{
	public TelemetryConfig? Telemetry { get; set; }
}
