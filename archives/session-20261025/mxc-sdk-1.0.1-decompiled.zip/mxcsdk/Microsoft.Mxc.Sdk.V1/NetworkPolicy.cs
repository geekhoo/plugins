using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

[JsonUnmappedMemberHandling(JsonUnmappedMemberHandling.Disallow)]
public sealed class NetworkPolicy
{
	[JsonPropertyName("egress")]
	public NetworkEgressPolicy? Egress { get; set; }

	[JsonPropertyName("ingress")]
	public NetworkIngressPolicy? Ingress { get; set; }

	[JsonPropertyName("runtimeConfig")]
	public NetworkRuntimeConfig? RuntimeConfig { get; set; }
}
