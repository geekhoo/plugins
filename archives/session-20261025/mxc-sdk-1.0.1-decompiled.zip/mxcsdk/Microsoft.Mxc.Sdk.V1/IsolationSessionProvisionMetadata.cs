using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class IsolationSessionProvisionMetadata : ProvisionMetadata
{
	[JsonPropertyName("agentUserName")]
	public required string AgentUserName { get; init; }

	[JsonPropertyName("agentUserSid")]
	public required string AgentUserSid { get; init; }

	[JsonPropertyName("ephemeralWorkspacePath")]
	public required string EphemeralWorkspacePath { get; init; }
}
