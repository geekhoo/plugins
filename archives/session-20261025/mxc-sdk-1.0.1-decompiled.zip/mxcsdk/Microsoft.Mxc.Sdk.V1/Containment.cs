using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

[JsonPolymorphic(TypeDiscriminatorPropertyName = "type")]
[JsonDerivedType(typeof(Process), "process")]
[JsonDerivedType(typeof(ProcessContainer), "processContainer")]
[JsonDerivedType(typeof(Seatbelt), "seatbelt")]
[JsonDerivedType(typeof(Lxc), "lxc")]
[JsonDerivedType(typeof(Bubblewrap), "bubblewrap")]
[JsonDerivedType(typeof(Wslc), "wslc")]
[JsonDerivedType(typeof(IsolationSession), "isolationSession")]
public abstract class Containment
{
	public sealed class Process : Containment
	{
	}

	public sealed class ProcessContainer : Containment
	{
		[JsonPropertyName("learningMode")]
		public bool LearningMode { get; set; }

		[JsonPropertyName("capabilities")]
		public List<string> Capabilities { get; set; } = new List<string>();

		[JsonPropertyName("captureDenials")]
		public CaptureDenialsPolicy? CaptureDenials { get; set; }

		[JsonPropertyName("ui")]
		public ProcessContainerUiPolicy? Ui { get; set; } = new ProcessContainerUiPolicy();

		[JsonPropertyName("filesystem")]
		public ProcessContainerFilesystemPolicy? Filesystem { get; set; }

		[JsonPropertyName("network")]
		public ProcessContainerNetworkPolicy? Network { get; set; }
	}

	public sealed class Seatbelt : Containment
	{
		[JsonPropertyName("profileOverride")]
		public string? ProfileOverride { get; set; }

		[JsonPropertyName("guiAccess")]
		public bool GuiAccess { get; set; }

		[JsonPropertyName("nestedPty")]
		public bool NestedPty { get; set; } = true;

		[JsonPropertyName("keychainAccess")]
		public bool KeychainAccess { get; set; }

		[JsonPropertyName("extraMachLookups")]
		public List<string> ExtraMachLookups { get; set; } = new List<string>();
	}

	public sealed class Lxc : Containment
	{
		[JsonPropertyName("distribution")]
		public string Distribution { get; set; } = "alpine";

		[JsonPropertyName("release")]
		public string Release { get; set; } = "3.23";
	}

	public sealed class Bubblewrap : Containment
	{
	}

	public sealed class Wslc : Containment
	{
		[JsonPropertyName("image")]
		public string Image { get; set; } = "alpine:latest";

		[JsonPropertyName("imageTarPath")]
		public string? ImageTarPath { get; set; }

		[JsonPropertyName("cpuCount")]
		public uint? CpuCount { get; set; }

		[JsonPropertyName("memoryMb")]
		public ulong? MemoryMb { get; set; }

		[JsonPropertyName("gpu")]
		public bool Gpu { get; set; }

		[JsonPropertyName("storagePath")]
		public string? StoragePath { get; set; }

		[JsonPropertyName("portMappings")]
		public List<WslcPortMapping> PortMappings { get; set; } = new List<WslcPortMapping>();
	}

	public sealed class IsolationSession : Containment
	{
	}

	private protected Containment()
	{
	}
}
