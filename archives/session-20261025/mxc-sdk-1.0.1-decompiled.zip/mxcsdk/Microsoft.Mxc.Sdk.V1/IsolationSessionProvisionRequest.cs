using System;
using System.Text.Json.Serialization;

namespace Microsoft.Mxc.Sdk.V1;

[JsonUnmappedMemberHandling(JsonUnmappedMemberHandling.Disallow)]
public sealed class IsolationSessionProvisionRequest : ProvisionRequest
{
	internal override LifecycleContainmentKind Containment => LifecycleContainmentKind.IsolationSession;

	public NetworkPolicy Network { get; set; }

	public string? AppId { get; set; }

	public IsolationSessionProvisionRequest(NetworkPolicy network)
	{
		Network = network ?? throw new ArgumentNullException("network");
	}
}
