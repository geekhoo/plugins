namespace Microsoft.Mxc.Sdk.V1;

public enum TelemetryConsentDecision
{
	No,
	Yes,
	Dismissed
}
