using System;
using System.Collections.Generic;

namespace Microsoft.Mxc.Sdk.V1;

public sealed class ExecutionResult
{
	public int ExitCode { get; init; }

	public bool TimedOut { get; init; }

	public string Stdout { get; init; } = string.Empty;

	public string Stderr { get; init; } = string.Empty;

	public ExecutionMetadata? OutputMetadata { get; init; }

	public IReadOnlyList<string> Warnings { get; init; } = Array.Empty<string>();
}
